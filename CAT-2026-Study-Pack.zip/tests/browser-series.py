"""Real-browser checks for independent papers, saved attempts and print views."""
import argparse
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent.parent
BASE='http://127.0.0.1:8000'
parser=argparse.ArgumentParser()
parser.add_argument('--papers',nargs='+',type=int,choices=range(1,11),default=list(range(1,11)))
parser.add_argument('--check-downloads',action='store_true')
args=parser.parse_args()

def no_overflow(page,label):
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),label

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1050})
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    for number in args.papers:
        label=f'{number:02}'
        page.goto(f'{BASE}/prediction.html?paper={label}',wait_until='networkidle')
        page.wait_for_function('(n)=>window.CATPaper?.number===n',arg=label)
        assert page.evaluate('CATPaper.bank.length')==68
        assert page.locator('#footerPaperPdf').get_attribute('href')==f'CAT-2026-Prediction-Paper-{label}.pdf'
        assert page.locator('#paperPicker').input_value()==label
        scores=page.evaluate('''() => {
          const bank=CATPaper.bank;
          const score=answers=>CATPaper.getSummary({answers}).reduce((s,x)=>s+x.score,0);
          return {correct:score(Object.fromEntries(bank.map(q=>[q.id,q.answer]))),
            wrong:score(Object.fromEntries(bank.map(q=>[q.id,q.type==='MCQ'?(q.answer+1)%4:String(Number(q.answer)+1337)]))),blank:score({})};
        }''')
        assert scores=={'correct':204,'wrong':-45,'blank':0},(label,scores)
        assert page.locator('[data-action="resume"]').count()==0
        page.locator('[data-action="practice"]').click()
        page.locator(f'[data-option="{number%4}"]').click()
        page.locator('[data-action="flag"]').click()
        page.reload(wait_until='networkidle')
        page.locator('[data-action="resume"]').click()
        page.locator('[data-index="0"]').click()
        assert page.locator(f'[data-option="{number%4}"]').get_attribute('aria-pressed')=='true'
        assert 'st-am' in page.locator('[data-index="0"]').get_attribute('class')
        no_overflow(page,label+' desktop')
        page.set_viewport_size({'width':390,'height':844})
        no_overflow(page,label+' mobile attempt')
        for section in range(3):
            page.locator(f'[data-section="{section}"]').click()
            no_overflow(page,(label,section))
        page.set_viewport_size({'width':1440,'height':1050})
        for view,solutions in [('paper',0),('solutions',68)]:
            page.goto(f'{BASE}/prediction.html?paper={label}&view={view}',wait_until='networkidle')
            assert page.locator('.print-question').count()==68
            assert page.locator('.print-question .solution').count()==solutions
            assert f'Paper {label}' in page.locator('.paper-cover h1').inner_text()
        print(f'Paper {label}: scoring, saved attempt, all sections and print editions passed.',flush=True)

    page.goto(BASE+'/papers.html',wait_until='networkidle')
    assert page.locator('.library-card').count()==10
    for number in args.papers:
        assert '1/68 answered' in page.locator(f'[data-paper="{number:02}"] .attempt-badge').inner_text().lower()
    page.locator('#paperFilter').select_option('active')
    assert page.locator('.library-card').count()==len(args.papers)
    page.locator('#paperFilter').select_option('not-started')
    assert page.locator('.library-card').count()==10-len(args.papers)
    page.locator('#paperFilter').select_option('all')
    page.screenshot(path=str(ROOT/'tests'/'papers-desktop.png'),full_page=True)
    page.set_viewport_size({'width':390,'height':844})
    no_overflow(page,'library mobile')
    page.screenshot(path=str(ROOT/'tests'/'papers-mobile.png'),full_page=True)

    # Shared IDs such as V01 must not cross paper-specific storage namespaces.
    for number in args.papers:
        label=f'{number:02}'
        page.goto(f'{BASE}/prediction.html?paper={label}',wait_until='networkidle')
        page.locator('[data-action="resume"]').click()
        page.locator('[data-section="0"]').click()
        assert page.locator(f'[data-option="{number%4}"]').get_attribute('aria-pressed')=='true'
    keys=page.evaluate('Object.keys(localStorage).filter(k=>k.startsWith("cat2026.prediction"))')
    assert len(keys)==len(args.papers),keys

    # Paper selection preserves other attempts; a new timed attempt replaces
    # only the selected paper after explicit confirmation.
    last=f'{args.papers[-1]:02}'
    page.clock.install()
    page.goto(f'{BASE}/prediction.html?paper={last}',wait_until='networkidle')
    page.locator('[data-action="exam"]').click()
    page.locator('#acceptConfirm').click()
    page.clock.fast_forward(40*60*1000+200)
    assert page.locator('[data-section="1"]').get_attribute('class')=='active'
    assert page.locator('[data-section="0"]').is_disabled()
    page.clock.fast_forward(80*60*1000+200)
    assert page.locator('.result-score').count()==1
    with page.expect_download() as result_info:
        page.locator('[data-action="export"]').click()
    exported=result_info.value
    assert exported.suggested_filename==f'CAT-2026-Paper{last}-result.json'
    payload=json.loads(Path(exported.path()).read_text())
    assert payload['paper']==f'CAT2026-P{last}-'+('v3' if int(last)<=5 else 'v2')
    page.goto(BASE+'/papers.html',wait_until='networkidle')
    assert page.locator(f'[data-paper="{last}"] .attempt-badge').inner_text().lower()=='completed'

    # A malformed or absent paper never silently substitutes another paper.
    for invalid in ['12','11','0','../../prediction-varc.js','abc']:
        page.goto(BASE+'/prediction.html?paper='+invalid,wait_until='networkidle')
        assert page.locator('h1').inner_text()=='Paper not found.'
        assert page.evaluate('typeof window.CATPaper')=='undefined'
    assert page.evaluate('Object.keys(localStorage).filter(k=>k.startsWith("cat2026.prediction")).length')==len(args.papers)
    if args.check_downloads:
        for number in args.papers:
            for kind in ['Paper','Solutions']:
                name=f'CAT-2026-Prediction-{kind}-{number:02}.pdf'
                response=page.request.get(BASE+'/'+name)
                assert response.status==200 and response.body().startswith(b'%PDF-'),name
        for name in ['CAT-2026-Ten-Papers-PDFs.zip','CAT-2026-Study-Pack.zip']:
            response=page.request.get(BASE+'/'+name)
            assert response.status==200 and response.body().startswith(b'PK'),name
    assert not errors,errors
    browser.close()
    print(json.dumps({'status':'passed','papers':len(args.papers),'questions':len(args.papers)*68,'independentStorage':True,'catalogFilters':True,'timedTransitions':True,'invalidPaperHandling':True,'mobileOverflow':False,'pageErrors':errors},indent=2))
