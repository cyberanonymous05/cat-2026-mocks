/* Generate portable research artifacts from the same data and pure engine as
   the website. No supplementary-provider row is passed to runStudy. */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const inputNames = ['history-data.js', 'topic-data.js', 'forecast-engine.js'];
const context = {window: {}};
const inputHashes = {};
vm.createContext(context);
for (const name of inputNames) {
  const content = fs.readFileSync(path.join(root, name), 'utf8');
  inputHashes[name] = crypto.createHash('sha256').update(content).digest('hex');
  vm.runInContext(content, context, {filename: name, timeout: 5000});
}
const H = context.window.CAT_HISTORY;
const E = context.window.CATForecastEngine;
assert.ok(H && E, 'Historical dataset and forecast engine must both load.');
E.validateRows(H.rows);
assert.ok(H.rows.every(row => new URL(row.source).hostname.endsWith('imsindia.com')),
  'The primary model must remain IMS-only.');
const plain = value => JSON.parse(JSON.stringify(value));
const primaryRows = plain(H.rows).map(row => ({...row, provider: H.provider}));
const raw = plain(E.runStudy(H.rows, 'raw'));
const broad = plain(E.runStudy(H.rows, 'broad'));
const tolerance = 1e-9;
const years = raw.years;
const omittedYears = [];
for (let year = years[0]; year <= years[years.length - 1]; year++) {
  if (!years.includes(year)) omittedYears.push(year);
}
const coverage = years.map(year => ({
  year,
  includedSlots: primaryRows.filter(row => row.year === year).map(row => row.slot).sort(),
  excludedOrUnrecoveredSlots: [1, 2, 3].filter(slot => !primaryRows.some(row => row.year === year && row.slot === slot))
}));
// Every row with a conflicting same-provider table is swapped at once for one combined sensitivity rerun.
const alternativeCandidates = H.rows.filter(row => row.alternativeQA);
let alternativeSources = {available: false, reason: 'No alternative same-provider classification is supplied.'};
if (alternativeCandidates.length) {
  const alternativeRows = H.rows.map(row => row.alternativeQA ? {
    ...row, qa: [...row.alternativeQA], source: row.alternativeSource
  } : {...row, qa: [...row.qa]});
  E.validateRows(alternativeRows);
  const alternativeRaw = plain(E.runStudy(alternativeRows, 'raw'));
  const alternativeBroad = plain(E.runStudy(alternativeRows, 'broad'));
  alternativeSources = {
    available: true,
    changes: alternativeCandidates.map(original => ({
      year: original.year, slot: original.slot,
      selectedQA: plain(original.qa), selectedSource: original.source,
      alternativeQA: plain(original.alternativeQA), alternativeSource: original.alternativeSource,
      note: original.note || 'Alternative classification supplied by the same provider.'
    })),
    raw: alternativeRaw,
    broad: alternativeBroad,
    broadStudyUnchanged: JSON.stringify(alternativeBroad) === JSON.stringify(broad),
    selectorMAEDifference: {
      raw: alternativeRaw.summary.selector.mae - raw.summary.selector.mae,
      broad: alternativeBroad.summary.selector.mae - broad.summary.selector.mae
    }
  };
}
// Diagnostics never feed the selector. They report what was tried, including what did not help.
const diagnostics = {
  trendExperiment: {raw: plain(E.trendExperiment(H.rows, 'raw')), broad: plain(E.trendExperiment(H.rows, 'broad'))},
  slotNoiseFloor: {raw: plain(E.withinYearNoise(H.rows, 'raw')), broad: plain(E.withinYearNoise(H.rows, 'broad'))},
  mostLikelyAllocation: {raw: plain(E.modalExperiment(H.rows, 'raw')), broad: plain(E.modalExperiment(H.rows, 'broad'))},
  setterSwing: {raw: plain(E.setterSwing(H.rows, 'raw', H.convenors)), broad: plain(E.setterSwing(H.rows, 'broad', H.convenors))},
  varc: plain(E.runVARCStudy(H.rows)),
  dilr: plain(E.runDILRStudy(H.rows)),
  officialMock: {
    recorded: plain(H.officialMocks),
    dilrLayoutsAllowedByRule: plain(E.setLayouts(22, H.officialMocks[2026].rules.dilrSetSizes)),
    backtest2025: plain(E.mockBacktest(H.rows, H.officialMocks[2025], 2025)),
    titaForecast: plain(E.titaForecast(H.rows, H.supplementaryTita || [])),
    note: 'Counts and question types only; no mock question text is stored. Mock QA labels were assigned by this project and are never fitted.'
  },
  topicForecast: (() => {
    const T = context.window.CAT_TOPICS, keys = T.groups.map(g => g.key), G2 = T.twoIIM.groups;
    const sumOf = a => a.reduce((s, x) => s + x, 0);
    const merged = r => { const c = Object.fromEntries(keys.map((k, i) => [k, r.counts[i]])); c.EQ = c.LIN + c.QUAD; return {...r, shares: G2.map(g => c[g] / sumOf(r.counts))}; };
    const forecast = E.topicForecast(T.cracku.rows, {targetYear: T.targetYear});
    return {
      groups: plain(T.groups),
      forecast: plain({...forecast, groups: forecast.groups.map(({dist, ...g}) => g)}),
      backtest: plain(E.topicBacktest(T.cracku.rows)),
      setterRepeat: plain(E.setterRepeatTest(E.taggedRows(T.twoIIM.rows.filter(r => r.year <= 2020), G2), T.cracku.rows.map(merged), T.setterPairs)),
      titaTendency: plain(E.titaTendency(T.twoIIM.rows, G2)),
      mocks: plain(T.mocks), mockDilr: plain(T.mockDilr), scenarios: plain(T.scenarios),
      note: 'Sub-topic counts from Cracku shift tables (2020-2025); question types from 2IIM per-question tags (2017-2020, 2024). Providers label borderline questions differently.'
    };
  })()
};

const audit = {
  schemaVersion: 'CAT-forecast-audit-1.0',
  generatedAt: new Date().toISOString(),
  metadata: {
    title: 'CAT 2026 historical QA allocation study',
    datasetVersion: H.version,
    sourceReviewDate: H.reviewed,
    studyType: 'Retrospective chronological reconstruction assembled after the historical outcomes were known.',
    targetYear: raw.forecast.targetYear,
    primaryProvider: H.provider,
    primaryRows: primaryRows.length,
    primaryQuestionAllocations: primaryRows.length * 22,
    independentPredictionCountClaimed: false,
    chronologicalEvaluationYears: raw.folds.map(fold => fold.year),
    omittedYearsWithinCoverage: omittedYears,
    coverage,
    supplementaryRowsExcludedFromEveryStudy: (H.supplementaryRows || []).length,
    scope: 'The selector scores QA family counts. The diagnostics block separately scores a damped-trend rule, a slot-noise floor, Verbal Ability type mix and DILR set layout. Section totals remain descriptive metadata.',
    convenors: plain(H.convenors),
    indore2020: plain(H.indore2020),
    limitations: [
      'No archived pre-exam publication of these predictions is claimed.',
      'Each exam year in 2021-2025 had a different convening IIM, so a setter-specific style cannot be estimated; IIM Indore\'s last CAT (2020) used a different 76-question format.',
      'The official CAT 2026 mock repeats the 2025 mock and, by its own note, is not meant to reveal the 2026 pattern; it confirms format rules only. Scored on 2025, that mock missed the Verbal Ability mix and the TITA count.',
      'Rows added in v4.0 other than 2022 Slot 1 were read from IMS page content in search results, not opened directly.',
      'Rules and source selection were assembled retrospectively; chronological computation does not remove retrospective design choices.',
      'Slots within a year are correlated, coverage is incomplete, and the evaluation contains only a few target years.',
      'Topic-count overlap is an allocation similarity measure, not the percentage of exact exam questions predicted.',
      'Observed ranges and maximum historical errors are descriptive, not calibrated confidence or prediction intervals.',
      'No exact-paper guarantee, question-match probability, difficulty forecast, percentile prediction or individual paper-author inference is supplied.'
    ],
    sourceNotes: plain(H.notes || []),
    reproducibility: {
      command: 'node tests/export-audit.cjs',
      engine: 'forecast-engine.js',
      dataset: 'history-data.js',
      sha256: inputHashes
    }
  },
  modelSettings: {
    rawLabels: plain(E.labels.raw),
    broadLabels: plain(E.labels.broad),
    rawToBroad: 'Merge Algebra and Modern Math; retain Arithmetic, Geometry and Numbers.',
    targetQuestionTotal: 22,
    trainingCutoff: 'For each target year, use primary rows with year strictly less than target year.',
    foldDefinition: 'Each observed year after the first is one target fold; missing years do not create folds or imputed rows.',
    withinYearWeighting: 'Equal mean of available slots in each training year.',
    comparisonAggregation: 'Equal mean over target-year metric values, not a pooled average over all historical slots.',
    methods: plain(E.methods),
    recencyHalfLifeCalendarYears: 2,
    selector: {
      candidatesInTiePreferenceOrder: ['last', 'annual', 'recency', 'ensemble'],
      objective: 'Lowest mean target-year MAE among completed earlier folds only.',
      firstFoldFallback: 'last',
      equalityTolerance: tolerance,
      uniformNullExcludedFromSelection: true
    },
    metrics: {
      mae: 'Mean absolute difference between forecast and actual question counts across topic cells within a target year.',
      overlapPercent: '100 * (1 - absolute_count_error / (2 * target_slots * 22)). Averaged equally over target years in summaries.',
      exact: 'Cells with absolute error below 1e-9. Summaries sum exact counts and evaluated cells across target folds.',
      maxHistoricalErrors: 'Largest absolute error by family in the selector predictions for historical target slots; not a future bound.'
    },
    rounding: 'Only displayed integer scenarios are rounded. Largest remainders preserve 22 questions; ties follow displayed family order. All evaluation scores use unrounded forecasts.'
  },
  primaryRows,
  studies: {raw, broad},
  diagnostics,
  sensitivity: {alternativeSources}
};

// CSV includes primary observations only; alternative and supplementary rows
// remain separate in the JSON audit or the source research files.
const csvColumns = [
  'year', 'slot', 'provider', 'arithmetic', 'algebra', 'geometry', 'numbers', 'modern_math', 'qa_total',
  'varc_rc', 'varc_summary', 'varc_sentence_placement', 'varc_odd_sentence', 'varc_parajumbles',
  'varc_section', 'dilr_section', 'qa_section', 'dilr_set_sizes', 'source', 'source_access', 'note'
];
const csvEscape = value => {
  const text = value === undefined || value === null ? '' : String(value);
  return /[",\r\n]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text;
};
const csvRows = primaryRows.map(row => [
  row.year, row.slot, row.provider, ...row.qa, row.qa.reduce((a, b) => a + b, 0),
  ...(row.varc || Array(5).fill('')), ...(row.sections || Array(3).fill('')),
  (row.dilr || []).join('|'), row.source, row.sourceAccess || '', row.note || ''
]);
assert.ok(csvRows.every(row => row.length === csvColumns.length), 'CSV column alignment failed.');
const csv = [csvColumns, ...csvRows].map(row => row.map(csvEscape).join(',')).join('\r\n') + '\r\n';

const fmt = number => Number(number).toFixed(3);
const pct = number => Number(number).toFixed(2) + '%';
const methodName = id => id === 'selector' ? 'Chronological selector' : E.methods.find(method => method.id === id).name;
const selectionComparison = study => {
  const tied = Math.abs(study.summary.selector.mae - study.summary.last.mae) < tolerance;
  return tied
    ? `For ${study.taxonomy} groups, the selector ties the last-year baseline on MAE (${fmt(study.summary.selector.mae)}). It establishes no improvement over that simple baseline.`
    : `For ${study.taxonomy} groups, selector MAE is ${fmt(study.summary.selector.mae)}, versus ${fmt(study.summary.last.mae)} for the last-year baseline. This is a small retrospective comparison, not independent prospective validation.`;
};
const methodTable = [...E.methods.map(method => method.id), 'selector'].map(id =>
  `| ${methodName(id)} | ${fmt(raw.summary[id].mae)} | ${pct(raw.summary[id].overlap)} | ${fmt(broad.summary[id].mae)} | ${pct(broad.summary[id].overlap)} |`
).join('\n');
const foldTable = raw.folds.map(fold =>
  `| ${fold.year} | ${fold.trainingYears.join(', ')} | ${fold.trainingSlots} | ${fold.targetSlots} | ${methodName(fold.selectedMethod)} | ${fmt(fold.selected.metrics.mae)} |`
).join('\n');
const allocationTable = raw.labels.map((label, index) =>
  `| ${label} | ${fmt(raw.forecast.prediction[index])} | ${raw.forecast.rounded[index]} | ${raw.forecast.observed[index].join('–')} |`
).join('\n');
const alternativeText = alternativeSources.available
  ? `Conflicting IMS tables exist for ${alternativeSources.changes.map(c => `${c.year} Slot ${c.slot} ([${c.selectedQA.join(', ')}] against [${c.alternativeQA.join(', ')}])`).join(' and ')}. Swapping all of them and re-running every fold gives raw selector MAE ${fmt(alternativeSources.raw.summary.selector.mae)} (overlap ${pct(alternativeSources.raw.summary.selector.overlap)}), raw 2026 method **${methodName(alternativeSources.raw.forecast.selectedMethod)}** and raw forecast [${alternativeSources.raw.forecast.prediction.map(fmt).join(', ')}]. The broad-group study ${alternativeSources.broadStudyUnchanged ? 'is unchanged' : `changes (selector MAE ${fmt(alternativeSources.broad.summary.selector.mae)}, forecast [${alternativeSources.broad.forecast.prediction.map(fmt).join(', ')}])`}. So the raw 2026 split depends on the disputed table cells (swapping 2023 Slot 2 alone is enough to change the raw method) and should be held loosely. See the audit for both complete reruns and source URLs.`
  : alternativeSources.reason;
const trendRaw = diagnostics.trendExperiment.raw, trendBroad = diagnostics.trendExperiment.broad;
const noiseRaw = diagnostics.slotNoiseFloor.raw, noiseBroad = diagnostics.slotNoiseFloor.broad;
const swingRaw = diagnostics.setterSwing.raw, vs = diagnostics.varc, ds = diagnostics.dilr;
const mlRaw = diagnostics.mostLikelyAllocation.raw, mlBroad = diagnostics.mostLikelyAllocation.broad;
const mlRow = (label, m) => `| ${label} | ${fmt(m.summary.modal.mae)} | ${Math.round(100 * m.summary.modal.exactRate)}% | ${fmt(m.summary.lastRounded.mae)} | ${Math.round(100 * m.summary.lastRounded.exactRate)}% | ${fmt(m.summary.lastMean.mae)} |`;
const mlChance = (names, m) => names.map((n, i) => `${n} ${m.forecast.allocation[i]} (${Math.round(100 * m.forecast.probabilityOfChosen[i])}%)`).join(', ');
const mostLikely = `## Most-likely allocation (the best single guess)

Instead of averaging, this rule builds a probability for each count of each family from the earlier slots (year-equal weights, two-year recency half-life, fixed before scoring) and picks the integer allocation totalling 22 that maximises the expected number of exactly-right families. Compared on the same ${mlRaw.folds.length} test years with last year's mean and with that mean rounded to integers (the fair baseline, since a fractional forecast cannot match a count exactly):

| Grouping | Most-likely MAE | Most-likely exact families | Rounded last-year MAE | Rounded last-year exact | Last-year mean MAE |
| --- | ---: | ---: | ---: | ---: | ---: |
${mlRow('Five families', mlRaw)}
${mlRow('Four merged groups', mlBroad)}

On the merged groups the rule is better than rounded last year on error and exact hits; on the five raw families error improves slightly but exact hits do not (${Math.round(100 * mlRaw.summary.modal.exactRate)}% against ${Math.round(100 * mlRaw.summary.lastRounded.exactRate)}%), so no raw-family gain is established. Four test years is a small sample, and the half-life was fixed after trying a few variants; unsmoothed variants gave the same scores except a one-year half-life on the raw families. Most-likely allocation for ${mlBroad.forecast.targetYear}: merged groups [${mlBroad.forecast.allocation.join(', ')}] (${mlChance(['Arithmetic', 'Algebra + Modern Math', 'Geometry', 'Numbers'], mlBroad)}); five families [${mlRaw.forecast.allocation.join(', ')}] (${mlChance(['Arithmetic', 'Algebra', 'Geometry', 'Numbers', 'Modern Math'], mlRaw)}). Percentages are model probabilities from a small sample, not calibrated odds. The Algebra against Modern Math split is close to a coin flip (Algebra 4 at ${Math.round(100 * mlRaw.forecast.probabilities[1].find(x => x.count === 4).p)}% against 5 at ${Math.round(100 * mlRaw.forecast.probabilities[1].find(x => x.count === 5).p)}%).

`;
const beyondQA = mostLikely + `## What did not help

A damped linear trend (half of the fitted yearly drift carried forward, damping fixed before scoring) ${trendRaw.beatsLastYear ? 'beat' : 'did not beat'} the last-year baseline: raw MAE ${fmt(trendRaw.summary.trend)} against ${fmt(trendRaw.summary.last)}, broad ${fmt(trendBroad.summary.trend)} against ${fmt(trendBroad.summary.last)}. Arithmetic is drifting down and Numbers up, but the drift is smaller than the year-to-year noise.

Slot-to-slot noise inside one exam year gives a rough floor: predicting each slot from the other slots of the same year misses by ${fmt(noiseRaw.mae)} raw (${fmt(noiseBroad.mae)} broad). The last-year baseline already misses by ${fmt(trendRaw.summary.last)} raw (${fmt(trendBroad.summary.last)} broad). The room left for a better QA count rule is therefore close to zero; the remaining error is how different slots of one exam differ.

## Setter effect (IIM Indore)

IIM Indore convenes CAT 2026 (secondary reporting, supported by the official portal: disputes fall under the CAT Centre 2026 in Indore and the help desk uses an iimidr.ac.in address). Convening IIMs were ${Object.entries(H.convenors).filter(([y]) => y >= 2021 && y <= 2025).map(([y, n]) => `${y} ${n}`).join(', ')}. Every consecutive pair of years changed the convening IIM, so the IMS family panel cannot estimate a setter style; the topic-level section below tests it with 2017-2019 papers. Indore's last CAT (2020) used a different format (${H.indore2020.questions} questions: ${H.indore2020.sections.join('/')}). What the data does show: the yearly QA mix moved by about ${swingRaw.meanChurn.toFixed(1)} of 22 questions between consecutive years, with a new convening IIM each time. A new setter in 2026 should be treated as that much expected movement, not as a known shift in any direction.

## Verbal Ability type mix and DILR layout

Verbal Ability is the 8 non-RC VARC questions; RC was 16 in every recovered report. The type mix changed in ${vs.changes.changed} of ${vs.changes.transitions} year-to-year transitions. Last-year MAE ${fmt(vs.summary.last.mae)}, equal-year ${fmt(vs.summary.annual.mae)}, equal split ${fmt(vs.summary.uniform.mae)}. Selected 2026 mix (Summary, Sentence placement, Odd sentence, Parajumbles): [${vs.forecast.rounded.join(', ')}]. Presence across ${vs.presence[0].years} years: ${vs.presence.map(p => `${p.label} ${p.yearsPresent}/${p.years}`).join(', ')}.

DILR layout changed in ${ds.changes.changed} of ${ds.changes.transitions} transitions. Carrying last year's layout got the question total right in ${Math.round(100 * ds.summary.totalCorrect)}% of test years and the exact set sizes in ${Math.round(100 * ds.summary.exactShape)}%. 2026 default: ${ds.forecast.total} questions as ${ds.forecast.shape.join(' / ')}. Contexts and constraint types are not modelled.

## Official CAT 2026 mock (released ${H.officialMocks[2026].released})

${(() => {
  const om = diagnostics.officialMock, b = om.backtest2025, t = om.titaForecast, total = a => a.reduce((s, x) => s + x, 0);
  return `Confirmed format: 24/22/22 questions and 40 minutes per section (the mock-link PDF states the 120-minute, 40-per-section timing for CAT 2026 itself), four questions per RC passage, four or five questions per DILR set, MCQ +3/−1, TITA +3/0 with whole-number answers. With 22 DILR questions the set rule allows only ${om.dilrLayoutsAllowedByRule.map(l => l.join(' / ')).join(' or ')}.

The 2026 mock repeats the 2025 mock question for question (${H.officialMocks[2026].sameEvidence}), so it carries no new information about 2026 topics. Scored against the real 2025 paper, the 2025 mock matched section counts and DILR layout (repeating 2024 matched too), but showed Verbal Ability ${b.va.mock.join('/')} against ${b.va.actual.join('/')} actual (MAE ${fmt(b.va.mockMAE)}; equal split ${fmt(b.va.equalSplitMAE)}) and TITA ${b.tita.mock.join('/')} = ${total(b.tita.mock)} against ${b.tita.actual.join('/')} = ${total(b.tita.actual)}. Its QA mix (labels assigned by this project) had MAE ${fmt(b.qa.raw.mock)} raw (${fmt(b.qa.raw.mockAlternative)} with alternative labels) and ${fmt(b.qa.broad.mock)} merged, against ${fmt(b.qa.raw.lastYear)} and ${fmt(b.qa.broad.lastYear)} for repeating 2024: no reliable gain.

TITA forecast for ${t.targetYear}: ${t.bySection.join(' / ')} (VARC / DILR / QA) = ${t.total}, repeating ${t.basisYear}; reported totals range ${t.range[0]}–${t.range[1]}.`;
})()}
`;
const topicSection = (() => {
  const tf = diagnostics.topicForecast, f = tf.forecast, b = tf.backtest, st = tf.setterRepeat, tt = tf.titaTendency;
  const rate = Object.fromEntries(tt.groups.map(g => [g.group, g.rate]));
  const best = b.byHalfLife.find(h => h.halfLife === f.halfLife);
  const rows = tf.groups.map((g, i) => `| ${g.label} | ${f.groups[i].mostLikely} | ${f.groups[i].range[0]}–${f.groups[i].range[1]} | ${Math.round(100 * f.groups[i].pAtLeastOne)}% | ${Math.round(100 * rate[g.key === 'LIN' || g.key === 'QUAD' ? 'EQ' : g.key])}% |`).join('\n');
  return `## Topic-level forecast (QA sub-topics)

Counts per shift come from Cracku's tables for 2020-2025 (18 shifts, one labelling scheme, including IIM Indore's 2020 paper); each year counts 0.7 times the year after it (half-life ${f.halfLife} years). Rolling test on ${b.targets.join(', ')}: error ${fmt(best.mae)} questions per topic against ${fmt(b.uniform.mae)} for an equal split and a shift-to-shift floor of ${fmt(b.noiseFloor)}. Typed-answer share by topic comes from ${tt.questions} 2IIM-tagged questions (2017-2020, 2024).

| Topic | Most likely | Likely range (80%) | Appears in a shift | Typed-answer share |
| --- | ---: | ---: | ---: | ---: |
${rows}

Same-setter test: ${st.pairs.map(p => `${p.setter} ${p.earlier}→${p.later} r = ${fmt(p.r)}`).join('; ')}; pooled slope ${fmt(st.pooledSlope)}. No sign that a convening IIM repeats its earlier topic mix, so the forecast is not tilted towards IIM Indore's 2020 paper. Practice Papers ${Object.keys(tf.scenarios).join(' and ')} cover that scenario (${Object.values(tf.scenarios).join('; ')}).
`;
})();
const summary = `# CAT 2026 research summary

Generated ${audit.generatedAt}. Dataset ${H.version}; sources reviewed ${H.reviewed}.

This is a retrospective QA topic-count study using ${primaryRows.length} complete ${H.provider} slot reports from ${years.join(', ')}. It contains ${primaryRows.length * 22} reported allocations, not that many independent predictions. Historical outcomes were already known when the study was assembled. Supplementary providers are excluded from every fitted result.

## Coverage and evaluation

There are ${raw.folds.length} target-year folds: ${raw.folds.map(fold => fold.year).join(', ')}. Missing years within the covered interval: ${omittedYears.length ? omittedYears.join(', ') : 'none'}. A missing year remains a gap; the most recent available year can be older than the immediately preceding calendar year. Slots within a year are correlated.

| Target year | Training years | Training slots | Target slots | Method selected before target evaluation | QA MAE |
| --- | --- | ---: | ---: | --- | ---: |
${foldTable}

Year-level results have equal weight. Within each training year, available slots have equal weight. Recency uses a fixed two-calendar-year half-life. The selector consults only completed earlier folds; ties favour last-year, then equal-year, recency and ensemble. The uniform null is never a selection candidate.

## What the comparison found

| Rule | Raw MAE | Raw allocation overlap | Broad MAE | Broad allocation overlap |
| --- | ---: | ---: | ---: | ---: |
${methodTable}

${selectionComparison(raw)} ${selectionComparison(broad)} The selected ${raw.forecast.targetYear} raw-group method is **${methodName(raw.forecast.selectedMethod)}**; the broad-group method is **${methodName(broad.forecast.selectedMethod)}**.

MAE is error in the number of questions per category. Allocation overlap is 100 × (1 − absolute error / (2 × 22 × target-slot count)); the table averages this measure over target years. It is not the percentage of exam questions predicted. Exact raw count cells for the selector: ${raw.summary.selector.exact}/${raw.summary.selector.cells}. Merging Algebra with Modern Math reduces one classification-boundary problem and also makes the comparison coarser; a higher broad overlap does not show improved exact-question prediction.

## The ${raw.forecast.targetYear} preparation scenario

| QA family | Unrounded expected count | Integer practice allocation | Observed count range |
| --- | ---: | ---: | ---: |
${allocationTable}

The integer allocation totals 22 using largest-remainder rounding. Unrounded values drive all scores. Observed ranges and historical errors describe this incomplete sample; they are not calibrated prediction intervals. This scenario supports topic balance in practice and does not establish future difficulty or exact question text.

${beyondQA}
${topicSection}
## Source sensitivity

${alternativeText}

## Sources and gaps

${primaryRows.map(row => `- ${row.year} Slot ${row.slot}: [${row.provider} analysis](${row.source}). ${row.sourceAccess || ''}`).join('\n')}

${(H.notes || []).map(note => `- ${note}`).join('\n')}

## Reproduce and use

Run \`node tests/export-audit.cjs\` from the project folder. The JSON audit saves input SHA-256 hashes, all settings, complete raw/broad fold results and the alternative-source reruns. The CSV contains the primary rows only. Start the website with \`python3 -m http.server 8000 --bind 127.0.0.1\`, then open http://localhost:8000.

The accompanying 68-question paper is original practice material. No actual CAT 2026 paper, confidential question content, exact-paper guarantee or question-match probability is claimed.
`;

function writeDerived(name, content) {
  const target = path.join(root, name);
  const temporary = target + '.tmp-' + process.pid;
  try {
    fs.writeFileSync(temporary, content, {encoding: 'utf8', flag: 'wx'});
    fs.renameSync(temporary, target);
  } finally {
    if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
  }
  console.log(`${name}: ${fs.statSync(target).size} bytes`);
}
writeDerived('CAT-2026-Forecast-Audit.json', JSON.stringify(audit, null, 2) + '\n');
writeDerived('CAT-2021-2025-Topic-Data.csv', csv);
writeDerived('CAT-2026-Research-Summary.md', summary);
console.log(JSON.stringify({status: 'passed', primaryRows: primaryRows.length,
  supplementaryRowsFitted: 0, folds: raw.folds.length, targetYear: raw.forecast.targetYear,
  selectedRawMethod: raw.forecast.selectedMethod, selectedBroadMethod: broad.forecast.selectedMethod,
  alternativeAvailable: alternativeSources.available}));
