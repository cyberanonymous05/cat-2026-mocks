/* Structural and length audit; semantic answer review remains an editorial task. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert/strict');
// Paper 01 has its existing validator; this file covers Papers 02-10.
const base=path.resolve(__dirname,'..'),files=fs.readdirSync(path.join(base,'papers')).filter(f=>/^paper-(0[2-9]|10)-varc\.js$/.test(f)).sort(),seen=new Set(),report=[];
assert.equal(files.length,9,'The release requires VARC files for Papers 02–10.');
const words=s=>s.trim().split(/\s+/).filter(Boolean).length;
for(const file of files){
 const ctx={window:{}};vm.runInNewContext(fs.readFileSync(path.join(base,'papers',file),'utf8'),ctx,{filename:file});
 const qs=ctx.window.CAT2026_VARC;assert.equal(qs.length,24,file);
 assert.equal(qs.filter(q=>q.type==='MCQ').length,20,file);assert.equal(qs.filter(q=>q.type==='TITA').length,4,file);
 const passageWords=[],vaWords=[],positions=[0,0,0,0];
 for(let i=0;i<24;i++){
  const q=qs[i];assert.equal(q.id,'V'+String(i+1).padStart(2,'0'));assert.equal(q.section,'VARC');assert.ok(q.question&&q.solution&&q.topic);
  assert.ok(['Moderate','Hard','Easy'].includes(q.difficulty));
  if(q.type==='MCQ'){assert.equal(q.options.length,4);assert.equal(new Set(q.options).size,4);assert.ok(Number.isInteger(q.answer)&&q.answer>=0&&q.answer<4);positions[q.answer]++;}
  else {assert.equal(q.options.length,0);assert.equal(typeof q.answer,'string');}
 }
 for(let g=1;g<=4;g++){
  const rows=qs.filter(q=>q.groupId==='RC'+g);assert.equal(rows.length,4,file+' RC'+g);assert.equal(new Set(rows.map(q=>q.passage)).size,1);
  const p=rows[0].passage,n=words(p);assert.ok(n>=380&&n<=480,file+' RC'+g+' words '+n);assert.ok(!seen.has(p),'Repeated RC passage across papers');seen.add(p);passageWords.push(n);
 }
 for(const q of qs.slice(16,20)){
  const body=(q.passage||q.question.split('\n\n').at(-1)).replace(/\([1-4]\)/g,'');const n=words(body);assert.ok(n>=100&&n<=150,file+' '+q.id+' VA words '+n);vaWords.push(n);
 }
 for(const q of qs.slice(20,22))assert.match(q.answer,/^(?!.*(.).*\1)[1-4]{4}$/);
 for(const q of qs.slice(22))assert.match(q.answer,/^[1-5]$/);
 assert.ok(positions.every(n=>n>=3&&n<=7),file+' answer-position imbalance');
 report.push({file,questions:qs.length,passageWords,vaWords,positions});
}
console.log(JSON.stringify({papers:files.length,questions:files.length*24,distinctPassages:seen.size,checks:'Structure, exact-passage uniqueness, word lengths, answer ranges and position balance passed. This script does not establish semantic answer uniqueness.',report},null,2));
