"""Exercise the actual site, persistence, scoring and section deadlines."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent.parent
BASE='http://127.0.0.1:8000'
KEY='cat2026.prediction01.attempt.v3'

def assert_no_overflow(page,label):
    dimensions=page.evaluate('''() => ({viewport:innerWidth,width:document.documentElement.scrollWidth})''')
    assert dimensions['width']<=dimensions['viewport']+1,(label,dimensions)

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1050})
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto(BASE+'/prediction.html',wait_until='networkidle')
    assert page.locator('h1').inner_text().startswith('The full paper.')
    paper_forecast=page.evaluate('catForecast().study.forecast')
    paper_model_cells=page.locator('table:has(th:text-is("Source QA family")) tbody tr td:nth-child(2)').all_text_contents()
    assert [float(value) for value in paper_model_cells]==[round(value,2) for value in paper_forecast['prediction']]
    result=page.evaluate('''() => {
      const bank=CATPaper.bank,all={answers:Object.fromEntries(bank.map(q=>[q.id,q.answer]))};
      const wrong={answers:Object.fromEntries(bank.map(q=>[q.id,q.type==='MCQ'?(q.answer+1)%4:'99999999']))};
      const blank={answers:{}};
      return {correct:CATPaper.getSummary(all).reduce((s,x)=>s+x.score,0),wrong:CATPaper.getSummary(wrong).reduce((s,x)=>s+x.score,0),blank:CATPaper.getSummary(blank).reduce((s,x)=>s+x.score,0)};
    }''')
    assert result=={'correct':204,'wrong':-45,'blank':0},result
    page.locator('[data-action="practice"]').click()
    page.locator('[data-option="1"]').click()
    page.locator('[data-action="flag"]').click() # Mark for Review & Next saves V01, flags it and moves on.
    page.reload(wait_until='networkidle')
    page.locator('[data-action="resume"]').click()
    page.locator('[data-index="0"]').click()
    assert page.locator('[data-option="1"]').get_attribute('aria-pressed')=='true'
    assert 'st-am' in page.locator('[data-index="0"]').get_attribute('class')
    # As on the test software, a choice left unsaved is discarded when jumping from the palette.
    page.locator('[data-index="1"]').click()
    page.locator('[data-option="2"]').click()
    page.locator('[data-index="2"]').click()
    assert 'st-na' in page.locator('[data-index="1"]').get_attribute('class')
    page.locator('[data-section="2"]').click()
    page.locator('[data-index="58"]').click() # Q13 has a negative TITA answer.
    page.locator('#titaAnswer').fill('-1')
    page.locator('[data-action="next"]').click()
    page.locator('[data-index="58"]').click()
    assert page.locator('#titaAnswer').input_value()=='-1'
    page.locator('[data-action="calculator"]').click()
    for key in ['1','7','/','4','=']:
        page.locator(f'.calc [data-calc="{key}"]').click()
    assert page.locator('.calc-value').inner_text()=='4.25'
    page.locator('.calc [data-calc-close]').click()
    page.locator('[data-action="submit"]').click()
    page.locator('[data-action="summaryYes"]').click()
    page.locator('[data-action="confirmYes"]').click()
    assert page.locator('.result-score').count()==1
    page.locator('#reviewSection').select_option('QA')
    assert page.locator('.review-item').count()==22
    # Persisted exam state is tested at actual deadline transitions.
    page.goto(BASE+'/prediction.html',wait_until='networkidle')
    page.locator('[data-action="exam"]').click()
    page.locator('#acceptConfirm').click()
    assert page.locator('[data-section="1"]').is_disabled()
    page.clock.install()
    page.clock.fast_forward(40*60*1000+200)
    page.reload(wait_until='networkidle')
    page.locator('[data-action="resume"]').click()
    assert page.locator('[data-section="1"]').get_attribute('class')=='active'
    assert page.locator('[data-section="0"]').is_disabled()
    page.clock.fast_forward(80*60*1000+200)
    page.reload(wait_until='networkidle')
    page.locator('[data-action="resume"]').click()
    assert page.locator('.result-score').count()==1
    page.evaluate('(k)=>localStorage.removeItem(k)',KEY)
    page.goto(BASE+'/backtest.html',wait_until='networkidle')
    assert page.locator('.score-cards').count()==0
    before=page.evaluate('JSON.stringify(CATBacktestResult.prediction)')
    page.locator('[data-action="reveal"]').click()
    assert '90.9%' in page.locator('.score-cards').inner_text()
    assert '91.7%' in page.locator('.score-cards').inner_text()
    page.locator('[data-tab="varc"]').click()
    page.locator('#actualSlot').select_option('2')
    assert 'Parajumbles' in page.locator('#comparison').inner_text()
    assert before==page.evaluate('JSON.stringify(CATBacktestResult.prediction)')
    page.screenshot(path=str(ROOT/'tests'/'backtest-desktop.png'),full_page=True)
    print('Original exam, persistence and 2025 replay checks passed.',flush=True)

    # Exercise actual controls and downloads, including both source taxonomies.
    lab_states=0
    method_choices=['selector','last','annual','recency','ensemble','uniform']
    lab_audit=None
    for viewport_name,viewport in [('desktop',{'width':1440,'height':1050}),('mobile',{'width':390,'height':844})]:
        page.set_viewport_size(viewport)
        page.goto(BASE+'/validation.html',wait_until='networkidle')
        assert page.locator('.lab-source-table tbody tr').count()==8
        assert page.locator('#foldYear option').all_text_contents()==['2022','2024','2025']
        assert page.evaluate('CATValidation.study.questions')==176
        assert page.evaluate('CATValidation.study.years')==[2021,2022,2024,2025]
        assert 'Four annual tests' not in page.locator('body').inner_text()
        for taxonomy in ['broad','raw']:
            page.locator('#taxonomy').select_option(taxonomy)
            primary_broad=None
            for alternative in [False,True]:
                page.locator('#alternativeSource').set_checked(alternative)
                assert page.evaluate('CATValidation.taxonomy')==taxonomy
                assert page.evaluate('CATValidation.alternative')==alternative
                assert page.locator('.lab-source-table tbody tr').count()==8
                assert len(page.evaluate('CATValidation.study.labels'))==(4 if taxonomy=='broad' else 5)
                if taxonomy=='broad':
                    broad_snapshot=page.evaluate('JSON.stringify(CATValidation.broad)')
                    if alternative:
                        assert broad_snapshot==primary_broad,'Algebra/Modern recoding must not change the merged study.'
                    else:
                        primary_broad=broad_snapshot
                for target_year,target_slots in [(2022,1),(2024,2),(2025,3)]:
                    page.locator('#foldYear').select_option(str(target_year))
                    for selected_method in method_choices:
                        page.locator('#foldMethod').select_option(selected_method)
                        wiring=page.evaluate('''({year,method}) => {
                          const f=CATValidation.study.folds.find(f=>f.year===year);
                          const expected=method==='selector'?f.selected:f.methods[method];
                          return {actual:CATValidation.currentPrediction,expected:expected.prediction,
                            beforeTarget:f.trainingYears.every(y=>y<year)};
                        }''',{'year':target_year,'method':selected_method})
                        assert wiring['actual']==wiring['expected'],(taxonomy,target_year,selected_method)
                        assert wiring['beforeTarget']
                        assert abs(sum(wiring['actual'])-22)<1e-9
                        assert_no_overflow(page,(viewport_name,taxonomy,alternative,target_year,selected_method))
                        lab_states+=1
                    page.locator('#foldMethod').select_option('selector')
                    hidden_prediction=page.evaluate('JSON.stringify(CATValidation.currentPrediction)')
                    assert page.locator('#foldComparison tbody tr').count()==1
                    page.locator('[data-lab="reveal"]').click()
                    assert page.locator('#foldComparison tbody tr').count()==target_slots+1
                    assert hidden_prediction==page.evaluate('JSON.stringify(CATValidation.currentPrediction)')
                    assert_no_overflow(page,(viewport_name,taxonomy,alternative,target_year,'revealed'))
                    page.locator('[data-lab="reveal"]').click()
                    assert page.locator('#foldComparison tbody tr').count()==1
        # The final loop state is raw taxonomy with the alternative source active.
        if viewport_name=='desktop':
            displayed_study=page.evaluate('CATValidation.study')
            with page.expect_download() as download_info:
                page.locator('[data-lab="download"]').click()
            download=download_info.value
            assert download.suggested_filename=='CAT-2026-current-evidence-audit.json'
            lab_audit=json.loads(Path(download.path()).read_text())
            assert lab_audit['metadata']['retrospective'] is True
            assert lab_audit['metadata']['alternative2025S1'] is True
            assert lab_audit['study']==displayed_study
            assert len(lab_audit['sourceRows'])==8
            assert next(r for r in lab_audit['sourceRows'] if r['year']==2025 and r['slot']==1)['qa']==[8,5,3,3,3]
            assert [f['year'] for f in lab_audit['study']['folds']]==[2022,2024,2025]
        page.locator('#alternativeSource').uncheck()
        assert page.evaluate('CATValidation.raw.forecast')==paper_forecast,'Paper and lab must use the same primary raw forecast.'
        page.locator('#foldYear').select_option('2025')
        page.locator('#foldMethod').select_option('selector')
        page.locator('[data-lab="reveal"]').click()
        assert_no_overflow(page,(viewport_name,'final-lab'))
        page.screenshot(path=str(ROOT/'tests'/f'validation-{viewport_name}.png'),full_page=True)
        print(f'Evidence lab {viewport_name}: all taxonomy/source, year and method controls passed.',flush=True)

    page.set_viewport_size({'width':1440,'height':1050})
    page.goto(BASE+'/index.html',wait_until='networkidle')
    assert page.locator('#chartLead').inner_text()=='8 slots'
    assert '176 QA questions' in page.locator('#chartPeriod').inner_text()
    assert page.evaluate('catForecast().study.forecast')==paper_forecast
    assert page.locator('#mockGrid a[href="validation.html"]').count()==1
    assert 'Forecasts for 3 target years' in page.locator('#mockGrid').inner_text()
    page.locator('#yearTable tr[data-year="2022"]').click()
    assert 'Slot 2: 8 / 6 / 3 / 1 / 4' in page.locator('#yearDetail').inner_text()
    assert '24 / 20 / 22' in page.locator('#yearDetail').inner_text()
    page.locator('#yearTable tr[data-year="2023"]').click()
    supplementary=page.locator('#yearDetail').inner_text()
    assert 'Supplementary QA breakdown' in supplementary
    assert 'Career Launcher' in supplementary
    assert 'excluded from the numeric forecast study' in supplementary
    assert page.evaluate('CAT_HISTORY.rows.length')==8
    assert page.evaluate('CAT_HISTORY.supplementaryRows.filter(r=>r.year===2023).length')>0
    page.locator('#yearTable tr[data-year="2024"]').click()
    assert 'over 70%' not in page.locator('#yearDetail').inner_text()
    page.locator('#yearTable tr[data-year="2020"]').click()
    assert 'complete slot-by-slot topic audit has not been added' in page.locator('#yearDetail').inner_text()
    syllabus_text=page.locator('#syllabusBoard').inner_text()
    assert 'Simple & compound interest' in syllabus_text and 'Probability & set theory' in syllabus_text
    assert not any(value in syllabus_text for value in ['70%','8–10 Q','6–8 Q','1–2 Q'])
    page.locator('[data-trend="DILR"]').click()
    assert '22 Q' in page.locator('#chartLead').inner_text()
    assert '78%' not in page.locator('body').inner_text()
    page.set_viewport_size({'width':390,'height':844})
    page.locator('#yearTable tr[data-year="2023"]').click()
    assert_no_overflow(page,'mobile-dashboard-supplementary-archive')
    print('Dashboard source coverage, supplementary archive and shared forecast checks passed.',flush=True)
    page.goto(BASE+'/prediction.html',wait_until='networkidle')
    page.set_viewport_size({'width':390,'height':844})
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
    page.screenshot(path=str(ROOT/'tests'/'paper-mobile.png'),full_page=True)
    page.goto(BASE+'/backtest.html',wait_until='networkidle')
    page.locator('[data-action="reveal"]').click()
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
    page.goto(BASE+'/prediction.html?view=paper',wait_until='networkidle')
    assert page.locator('.print-question').count()==68
    assert page.locator('.print-question .solution').count()==0
    page.goto(BASE+'/prediction.html?view=solutions',wait_until='networkidle')
    assert page.locator('.print-question .solution').count()==68
    pdf_pages={}
    import re
    for name in ['CAT-2026-Prediction-Paper-01.pdf','CAT-2026-Prediction-Solutions-01.pdf']:
        response=page.request.get(BASE+'/'+name)
        assert response.status==200,name
        content=response.body()
        assert content.startswith(b'%PDF-'),name
        pdf_pages[name]=len(re.findall(rb'/Type /Page\b',content))
        assert pdf_pages[name]>10,(name,pdf_pages[name])
    assert not errors,errors
    browser.close()
    print(json.dumps({'browser':'passed','rawScoring':result,'questions':68,'solutions':68,'deadlineTransitions':'passed','storageRestore':'passed','backtestIsolation':'passed','labControlStates':lab_states,'labRevealIsolation':'passed','auditDownloadRows':len(lab_audit['sourceRows']),'forecastConsistency':'passed','supplementaryArchive':'passed','mobileOverflow':'none','pdfPages':pdf_pages,'pageErrors':errors},indent=2))
