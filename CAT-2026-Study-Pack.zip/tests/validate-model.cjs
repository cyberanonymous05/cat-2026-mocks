const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname,'..');
const context={window:{}};vm.createContext(context);
for(const file of ['prediction-varc.js','prediction-dilr.js','prediction-qa.js','history-data.js','forecast-engine.js','evidence.js','backtest-data.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),context,{filename:file});
const w=context.window;
const bank=[...w.CAT2026_VARC,...w.CAT2026_DILR,...w.CAT2026_QA];
assert.equal(bank.length,68);assert.equal(new Set(bank.map(q=>q.id)).size,68);
for(const q of bank){
  assert.ok(q.question.trim().length>0,q.id);assert.ok(q.solution.trim().length>0,q.id);
  if(q.type==='MCQ'){assert.equal(q.options.length,4,q.id);assert.equal(new Set(q.options).size,4,q.id);assert.ok(Number.isInteger(q.answer)&&q.answer>=0&&q.answer<4,q.id);}
  else {assert.equal(q.type,'TITA');assert.equal(q.options.length,0);assert.ok(/^-?\d+(\.\d+)?$/.test(q.answer),q.id);}
}
for(const [section,n,mcq]of [['VARC',24,20],['DILR',22,11],['QA',22,14]]){
  const qs=bank.filter(q=>q.section===section);assert.equal(qs.length,n);assert.equal(qs.filter(q=>q.type==='MCQ').length,mcq);
}
const groups={};for(const q of bank.filter(q=>q.groupId)){(groups[q.groupId]??=[]).push(q);}
for(const qs of Object.values(groups))assert.ok(qs.every(q=>q.passage===qs[0].passage));
const d=w.CAT_BACKTEST;
for(const r of [...d.training.qaRows,...w.CAT_EVIDENCE.rows])assert.equal(r.counts.reduce((s,x)=>s+x,0),22);
const forecast=w.buildHistoricalForecast(d.training);
assert.equal(JSON.stringify(forecast.qa),'[8,6,3,2,3]');
const evaluation=w.evaluateHistoricalForecast(forecast,d.actual);
assert.equal(evaluation.qa.common,60);assert.equal(evaluation.qa.total,66);assert.equal(evaluation.qa.exact,6);assert.equal(evaluation.qa.mae,.8);
assert.equal(evaluation.varc.common,66);assert.equal(evaluation.varc.total,72);assert.equal(evaluation.sections.exact,9);
// Challenge training isolation: target values are irrelevant to the prediction.
const changed=JSON.parse(JSON.stringify(d.actual));changed[0].qa=[22,0,0,0,0];
w.evaluateHistoricalForecast(forecast,changed);
assert.equal(JSON.stringify(w.buildHistoricalForecast(d.training)),JSON.stringify(forecast));
assert.throws(()=>w.buildHistoricalForecast({...d.training,qaRows:[{year:2025,counts:[8,6,3,2,3]}]}));
console.log(JSON.stringify({questions:68,mcq:45,tita:23,qaBacktest:evaluation.qa,varcBacktest:evaluation.varc,groups:Object.fromEntries(Object.entries(groups).map(([k,v])=>[k,v.length]))},null,2));
