/* Independent checks of chronology, weighting, taxonomy and selection.
   Run with Node; no browser, network, package install or real-history file is required. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const context = {window:{}};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root, 'forecast-engine.js'), 'utf8'), context, {filename:'forecast-engine.js'});
const E = context.window.CATForecastEngine;
const plain = value => JSON.parse(JSON.stringify(value));
const clone = plain;
const row = (year, slot, qa = [8,6,3,2,3]) => ({year, slot, qa:[...qa], source:`https://example.test/cat/${year}/${slot}`});
const methods = ['last','annual','recency','ensemble','uniform'];
const candidates = methods.filter(id => id !== 'uniform');
const results = [];
function test(name, fn) {
  try { fn(); results.push({name, status:'passed'}); }
  catch (error) { results.push({name, status:'failed', error:error.stack || String(error)}); }
}
function close(actual, expected, message = '') {
  assert.ok(Number.isFinite(actual), `${message}: non-finite result ${actual}`);
  assert.ok(Math.abs(actual - expected) <= 1e-9, `${message}: expected ${expected}, received ${actual}`);
}
function vector(actual, expected, message = '') {
  assert.equal(actual.length, expected.length, message);
  actual.forEach((value, index) => close(value, expected[index], `${message}[${index}]`));
}
function freeze(value) {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
}
const fixture = [
  row(2021,1), row(2021,2),
  row(2022,1,[6,8,3,2,3]), row(2022,2,[6,8,3,2,3]), row(2022,3,[6,8,3,2,3]),
  row(2023,1,[9,4,3,3,3]), row(2023,2,[8,5,3,3,3]),
  row(2024,1,[7,5,3,3,4]), row(2024,2,[8,5,3,2,4]), row(2024,3,[8,4,3,3,4]),
  row(2025,1,[8,4,3,3,4]), row(2025,2,[8,5,3,2,4]), row(2025,3,[7,4,3,4,4])
];

test('reject empty, duplicate, incomplete and invalid source rows', () => {
  for (const bad of [undefined, null, {}, [], [null]]) assert.throws(() => E.validateRows(bad));
  assert.throws(() => E.validateRows([row(2021,1), row(2021,1)]), /Duplicate/);
  const invalidChanges = [
    {year:2021.5}, {year:'2021'}, {year:NaN}, {slot:0}, {slot:4}, {slot:1.5},
    {qa:null}, {qa:[8,6,3,5]}, {qa:[8,6,3,2,3,0]}, {qa:[8,6,3,2,2]},
    {qa:[8.5,5.5,3,2,3]}, {qa:[-1,10,3,5,5]}, {qa:[NaN,6,3,2,3]},
    {qa:[Infinity,6,3,2,3]}, {qa:['8',6,3,2,3]}, {source:''}, {source:'http://example.test'}
  ];
  invalidChanges.forEach(change => assert.throws(() => E.validateRows([{...row(2021,1), ...change}])));
});

test('reject sparse arrays rather than skipping missing topic counts', () => {
  const sparse = Array(5); sparse[0] = 22;
  assert.throws(() => E.validateRows([{...row(2021,1), qa:sparse}]));
  assert.throws(() => E.evaluate(sparse, [row(2022,1)]));
  assert.throws(() => E.roundAllocation(sparse));
});

test('fixed forecasts reject target-year and future training data for every method', () => {
  for (const method of methods) {
    assert.throws(() => E.fixedForecast([row(2021,1),row(2022,1)],2022,method), /strictly before/);
    assert.throws(() => E.fixedForecast([row(2021,1),row(2023,1)],2022,method), /strictly before/);
    assert.throws(() => E.fixedForecast([],2022,method));
  }
  assert.throws(() => E.fixedForecast([row(2021,1)],2022.5));
  assert.throws(() => E.fixedForecast([row(2021,1)],'2022'));
  assert.throws(() => E.fixedForecast([row(2021,1)],2022,'unknown'));
  assert.throws(() => E.fixedForecast([row(2021,1)],2022,'last','unknown'));
});

test('equal-year averaging does not overweight a year with three slots', () => {
  const training = fixture.filter(r => r.year <= 2022);
  vector(E.fixedForecast(training,2023,'annual'),[7,7,3,2,3]);
  vector(E.fixedForecast(training,2023,'last'),[6,8,3,2,3]);
  const annual = E.annualRows(training);
  assert.deepEqual(plain(annual.map(r => r.slots)),[2,3]);
  vector(annual[0].counts,[8,6,3,2,3]);
  vector(annual[1].counts,[6,8,3,2,3]);
  assert.notEqual(E.fixedForecast(training,2023,'annual')[0],(8*2+6*3)/5);
});

test('recency weights use calendar-year gaps and yearly means', () => {
  const training = [row(2021,1),row(2021,2),row(2023,1,[6,8,3,2,3]),row(2023,2,[6,8,3,2,3]),row(2023,3,[6,8,3,2,3])];
  vector(E.fixedForecast(training,2024,'recency'),[20/3,22/3,3,2,3]);
  vector(E.fixedForecast(training,2030,'recency'),[20/3,22/3,3,2,3]);
});

test('all methods conserve 22 questions in raw and merged taxonomies', () => {
  for (const taxonomy of ['raw','broad']) for (const method of methods) {
    const prediction = E.fixedForecast(fixture,2026,method,taxonomy);
    assert.equal(prediction.length,taxonomy === 'raw' ? 5 : 4);
    assert.ok(prediction.every(x => Number.isFinite(x) && x >= 0));
    close(prediction.reduce((a,b) => a+b,0),22,`${taxonomy}/${method}`);
  }
  vector(E.fixedForecast(fixture,2026,'uniform'),[4.4,4.4,4.4,4.4,4.4]);
  vector(E.fixedForecast(fixture,2026,'uniform','broad'),[4.4,8.8,4.4,4.4]);
  const component = ['last','annual','recency'].map(id => E.fixedForecast(fixture,2026,id));
  vector(E.fixedForecast(fixture,2026,'ensemble'),component[0].map((_,i) => component.reduce((s,p) => s+p[i],0)/3));
});

test('merging commutes with every fixed rule and is invariant to Algebra/Modern recoding', () => {
  const changed = fixture.map(r => {
    const copy = clone(r), shift = Math.min(copy.qa[1],1+(copy.year+copy.slot)%3);
    copy.qa[1] -= shift; copy.qa[4] += shift;
    return copy;
  });
  for (const method of methods) {
    vector(E.fixedForecast(fixture,2026,method,'broad'),E.project(E.fixedForecast(fixture,2026,method),'broad'));
    vector(E.fixedForecast(changed,2026,method,'broad'),E.fixedForecast(fixture,2026,method,'broad'));
  }
  assert.notEqual(E.fixedForecast(changed,2026,'annual')[1],E.fixedForecast(fixture,2026,'annual')[1]);
  assert.deepEqual(plain(E.runStudy(changed,'broad')),plain(E.runStudy(fixture,'broad')));
});

test('metric definitions match exact, disjoint and one-transfer examples', () => {
  const exact = E.evaluate([8,6,3,2,3],[row(2022,1),row(2022,2)]);
  close(exact.mae,0); close(exact.overlap,100); assert.equal(exact.exact,10); assert.equal(exact.cells,10);
  const disjoint = E.evaluate([22,0,0,0,0],[row(2022,1,[0,22,0,0,0])]);
  close(disjoint.mae,8.8); close(disjoint.overlap,0); assert.equal(disjoint.absolute,44);
  const shifted = E.evaluate([8,6,3,2,3],[row(2022,1,[7,7,3,2,3])]);
  close(shifted.mae,0.4); close(shifted.overlap,100*21/22); assert.equal(shifted.exact,3);
  for (const invalid of [[22,0,0,0],[21,0,0,0,0],[23,-1,0,0,0],[NaN,6,3,2,3]]) assert.throws(() => E.evaluate(invalid,[row(2022,1)]));
  assert.throws(() => E.evaluate([8,6,3,2,3],[]));
});

test('annual score summaries give two-slot and three-slot years equal weight', () => {
  const history = [row(2021,1),row(2022,1,[7,7,3,2,3]),row(2022,2,[7,7,3,2,3]),
    row(2023,1,[4,10,3,2,3]),row(2023,2,[4,10,3,2,3]),row(2023,3,[4,10,3,2,3])];
  const study = E.runStudy(history);
  vector(study.summary.last.annualMAE,[0.4,1.2]);
  close(study.summary.last.mae,0.8);
  close(study.summary.last.overlap,100*20/22);
  assert.ok(Math.abs(study.summary.last.mae-0.88)>0.01,'Must not pool slots across years.');
});

test('largest-remainder rounding conserves totals and resolves exact ties by family order', () => {
  assert.deepEqual(plain(E.roundAllocation([4.4,4.4,4.4,4.4,4.4])),[5,5,4,4,4]);
  assert.deepEqual(plain(E.roundAllocation([8.5,5.5,3,2,3])),[9,5,3,2,3]);
  assert.deepEqual(plain(E.roundAllocation([8,6,3,2,3])),[8,6,3,2,3]);
  for (const method of methods) for (const taxonomy of ['raw','broad']) {
    const prediction = E.fixedForecast(fixture,2026,method,taxonomy), rounded = E.roundAllocation(prediction);
    assert.equal(rounded.reduce((a,b) => a+b,0),22);
    rounded.forEach((x,i) => assert.ok(Number.isInteger(x) && x >= 0 && (x===Math.floor(prediction[i]) || x===Math.ceil(prediction[i]))));
  }
  assert.throws(() => E.roundAllocation([8,6,3,2,2]));
  assert.throws(() => E.roundAllocation([23,-1,0,0,0]));
});

test('decimal-equivalent rounding ties are stable despite binary floating-point error', () => {
  assert.deepEqual(plain(E.roundAllocation([8.2,5.2,3.2,2.2,3.2])),[9,5,3,2,3]);
});

test('selector excludes uniform and resolves equal scores toward simpler rules', () => {
  const fold = values => ({methods:Object.fromEntries(methods.map(id => [id,{metrics:{mae:values[id]}}]))});
  assert.equal(E.chooseMethod([]),'last');
  assert.equal(E.chooseMethod([fold({last:1,annual:1,recency:1,ensemble:1,uniform:0})]),'last');
  assert.equal(E.chooseMethod([fold({last:2,annual:1,recency:0.5,ensemble:0.75,uniform:0})]),'recency');
  assert.equal(E.chooseMethod([fold({last:1,annual:0.5,recency:0.5,ensemble:0.5,uniform:0})]),'annual');
});

test('nested selector uses completed earlier folds, with an independent selection oracle', () => {
  for (const taxonomy of ['raw','broad']) {
    const study = E.runStudy(fixture,taxonomy);
    for (let n=0; n<=study.folds.length; n++) {
      let expected='last', best=Infinity;
      if (n) for (const id of candidates) {
        const score=study.folds.slice(0,n).reduce((s,f) => s+f.methods[id].metrics.mae,0)/n;
        if (score<best-1e-9) { expected=id; best=score; }
      }
      assert.equal(n===study.folds.length ? study.forecast.selectedMethod : study.folds[n].selectedMethod,expected);
    }
  }
});

test('mutating target and future outcomes cannot change that target forecast or selection', () => {
  for (const taxonomy of ['raw','broad']) {
    const original = E.runStudy(fixture,taxonomy);
    for (const target of original.folds) {
      const poisoned = fixture.map(r => r.year>=target.year ? {...clone(r),qa:[22,0,0,0,0]} : clone(r));
      const rerun = E.runStudy(poisoned,taxonomy);
      const matched = rerun.folds.find(f => f.year===target.year);
      assert.equal(matched.selectedMethod,target.selectedMethod,`${taxonomy}/${target.year}`);
      for (const method of methods) vector(matched.methods[method].prediction,target.methods[method].prediction);
      original.folds.filter(f => f.year<target.year).forEach(before => {
        assert.deepEqual(plain(rerun.folds.find(f => f.year===before.year)),plain(before));
      });
    }
    const extended = E.runStudy([...fixture,row(2026,1,[22,0,0,0,0])],taxonomy);
    original.folds.forEach((fold,i) => assert.deepEqual(plain(extended.folds[i]),plain(fold)));
  }
});

test('row ordering cannot change forecasts, chronology or selected methods', () => {
  const reordered = [...fixture].reverse();
  for (const taxonomy of ['raw','broad']) {
    for (const method of methods) vector(E.fixedForecast(reordered,2026,method,taxonomy),E.fixedForecast(fixture,2026,method,taxonomy));
    const a=E.runStudy(fixture,taxonomy), b=E.runStudy(reordered,taxonomy);
    assert.deepEqual(plain(a.years),plain(b.years));
    a.folds.forEach((f,i) => {
      assert.equal(f.year,b.folds[i].year); assert.equal(f.selectedMethod,b.folds[i].selectedMethod);
      for (const method of methods) {
        vector(f.methods[method].prediction,b.folds[i].methods[method].prediction);
        close(f.methods[method].metrics.mae,b.folds[i].methods[method].metrics.mae);
      }
    });
    assert.equal(a.forecast.selectedMethod,b.forecast.selectedMethod);
    vector(a.forecast.prediction,b.forecast.prediction);
  }
});

test('single-year data has no invented evaluation fold; study never mutates inputs', () => {
  const frozen=freeze(clone(fixture)), before=JSON.stringify(frozen);
  E.runStudy(frozen); E.runStudy(frozen,'broad');
  assert.equal(JSON.stringify(frozen),before);
  const single=E.runStudy([row(2021,1)]);
  assert.equal(single.folds.length,0); assert.equal(Object.keys(single.summary).length,0);
  assert.equal(single.forecast.targetYear,2022); assert.equal(single.forecast.selectedMethod,'last');
  assert.ok(single.forecast.maxHistoricalErrors.every(x => x===null));
  const changed=clone(fixture); changed[0].qa=[22,0,0,0,0];
  assert.notDeepEqual(plain(E.fixedForecast(changed,2026,'annual')),plain(E.fixedForecast(fixture,2026,'annual')));
});

const historyFile=path.join(root,'history-data.js');
let realHistory=null;
if (fs.existsSync(historyFile)) {
  test('real historical dataset and all rolling folds satisfy chronological invariants', () => {
    vm.runInContext(fs.readFileSync(historyFile,'utf8'),context,{filename:'history-data.js'});
    const history=context.window.CAT_HISTORY;
    assert.ok(history && Array.isArray(history.rows));
    E.validateRows(history.rows);
    const raw=E.runStudy(history.rows), broad=E.runStudy(history.rows,'broad');
    assert.deepEqual(plain(raw.folds.map(f => f.year)),plain(raw.years.slice(1)));
    assert.equal(raw.forecast.targetYear,Math.max(...history.rows.map(r => r.year))+1);
    for (const study of [raw,broad]) {
      study.folds.forEach(f => {
        assert.ok(f.trainingYears.every(y => y<f.year));
        assert.equal(f.trainingSlots,history.rows.filter(r => r.year<f.year).length);
        assert.equal(f.targetSlots,history.rows.filter(r => r.year===f.year).length);
        for (const method of methods) {
          vector(f.methods[method].prediction,E.fixedForecast(history.rows.filter(r => r.year<f.year),f.year,method,study.taxonomy));
          close(f.methods[method].prediction.reduce((a,b) => a+b,0),22);
        }
      });
      for (const method of [...methods,'selector']) {
        if (!study.folds.length) continue;
        const annual=study.folds.map(f => method==='selector' ? f.selected.metrics.mae : f.methods[method].metrics.mae);
        close(study.summary[method].mae,annual.reduce((a,b) => a+b,0)/annual.length);
      }
    }
    realHistory={years:plain(raw.years),slots:raw.slots,folds:raw.folds.length,targetYear:raw.forecast.targetYear};
  });
}
const failed=results.filter(r => r.status==='failed');
console.log(JSON.stringify({status:failed.length?'failed':'passed',tests:results.length,passed:results.length-failed.length,
  realHistory:realHistory || 'not present; synthetic suite still exercised',results},null,2));
if (failed.length) process.exitCode=1;
