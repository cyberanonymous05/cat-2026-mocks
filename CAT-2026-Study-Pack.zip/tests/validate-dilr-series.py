"""Original DILR series and finite-domain mathematical checks.

Each scenario is solved from its stated constraints before a key is built.
--emit NN prints one JSON question array; normal execution recomputes all
available papers and compares every saved key, passage and option with it.
Generated website files contain only static questions, never this solver.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations, permutations, product
import argparse
import json
from pathlib import Path
import random
import re

ROOT = Path(__file__).resolve().parent.parent
BANK = {}
PROOFS = []
PATTERNS = (("TITA", "MCQ", "TITA", "MCQ", "MCQ"),
            ("TITA", "MCQ", "TITA", "TITA", "MCQ"),
            ("TITA", "MCQ", "TITA", "MCQ"))


def unique(values):
    values = set(values)
    assert len(values) == 1, f"Not a unique requested answer: {values}"
    return next(iter(values))


def table(headers, rows):
    return " | ".join(map(str, headers)) + "\n" + "\n".join(" | ".join(map(str, row)) for row in rows)


def item(question, answer, explanation, wrong=()):
    return question, answer, explanation, list(wrong)


def add(paper, group, title, topic, passage, working, items, examined, feasible, hard=False):
    pattern = PATTERNS[group - 1] if group <= 2 else PATTERNS[2]
    assert len(items) == len(pattern)
    questions = BANK.setdefault(paper, [])
    for position, ((question, answer, explanation, wrong), kind) in enumerate(zip(items, pattern)):
        qid = len(questions) + 1
        answer_text = str(answer)
        if kind == "TITA":
            assert re.fullmatch(r"\d+", answer_text), (paper, group, answer)
            options, key = [], answer_text
        else:
            if not wrong:
                assert isinstance(answer, int)
                wrong = [answer + 1, answer + 2, answer + 4]
            options = [answer_text] + list(map(str, wrong))
            assert len(options) == len(set(options)) == 4, (paper, group, options)
            random.Random(83117 + 907 * paper + 71 * qid).shuffle(options)
            key = options.index(answer_text)
        questions.append({
            "id": f"D{qid:02}", "section": "DILR", "topic": topic,
            "difficulty": "Hard" if hard else "Moderate", "type": kind,
            "groupId": f"DL{group}", "groupTitle": title,
            "passage": passage + "\n\nAny additional condition or change in a question applies only to that question.",
            "question": question, "options": options, "answer": key,
            "solution": working + "\n\n" + explanation
        })
    PROOFS.append({"paper": paper, "set": group, "title": title,
                   "candidateSpaceChecked": examined, "feasibleCases": feasible,
                   "questions": len(items)})


def batch_02_04():
    # 02/1: global stock-transfer equations, solved with exact rational ratios.
    stock = []
    for k in range(1, 34):
        for m in range(1, 10):
            post = [5*k, 7*k, 25*m, 19*m]
            pre = [post[0]+15, post[1]-5, post[2]-5, post[3]-5]
            if sum(post) == 400 and min(pre) >= 0 and 3*pre[2] == 4*pre[0]:
                stock.append((pre, post))
    assert len(stock) == 1
    pre, post = stock[0]
    work = "The transfers change A, B, C and D by −15, +5, +5 and +5. Put their final stocks at 5k, 7k, 25m and 19m. Then 12k + 44m = 400 and 3(25m − 5) = 4(5k + 15). Solving gives k = 15 and m = 5.\n" + table(["Depot", "Before", "After"], zip("ABCD", pre, post))
    add(2, 1, "Four-depot stock reconciliation", "DI · transfers and missing stocks",
        "Four depots A, B, C and D together initially hold 400 sealed crates. They simultaneously make these transfers: A sends 20 to B; B sends 15 to C; C sends 10 to D; D sends 5 to A. There are no other receipts, dispatches or losses. After the transfers, A:B stocks are 5:7 and C:D stocks are 25:19. Before the transfers, C held exactly four-thirds as many crates as A. All stocks are whole crates.", work, [
        item("How many crates did B hold initially?", pre[1], "B initially held 105 − 5 = 100 crates."),
        item("Which depot has the greatest final stock?", "C", "Final stocks are 75, 105, 125 and 95; C is greatest.", ["A", "B", "D"]),
        item("After the stated transfers, how many crates must B send to D to make their stocks equal?", (post[1]-post[3])//2, "105 − x = 95 + x gives x = 5."),
        item("Which depot has the greatest percentage increase relative to its own initial stock?", "D", "B, C and D each gain five, but D's initial base is smallest: 5/90 exceeds 5/100 and 5/120. A loses stock.", ["A", "B", "C"]),
        item("What is the smallest combined final stock of any two depots?", sum(sorted(post)[:2]), "Choose A and D: 75 + 95 = 170.", [180, 190, 200])
    ], 297, 1)

    # 02/2: anchored circular arrangements; clockwise orientation is material.
    seats = []
    for tail in permutations("BCDEFGH"):
        order = "A" + "".join(tail)
        p = {person: order.index(person) for person in order}
        if p["E"] not in (3, 4, 5): continue
        if (p["C"]-p["B"]) % 8 != 1 or (p["F"]-p["D"]) % 8 != 1: continue
        if (p["G"]-p["C"]) % 8 != 4 or (p["H"]-p["E"]) % 8 not in (1, 7): continue
        seats.append((order, p))
    assert len(seats) == 3
    seat_work = "Fix A in position 1 to remove rotational duplicates. B–C and D–F must each be clockwise adjacent blocks; G is opposite C. Checking the permitted E positions and the H adjacency leaves exactly:\n" + "\n".join(s[0] for s in seats) + "\nEach row lists positions 1 through 8 clockwise. Mirror images are distinct because clockwise conditions matter."
    add(2, 2, "Seats around the circular table", "LR · circular arrangement",
        "Eight people A through H occupy eight equally spaced seats around a circular table. Number the positions 1 to 8 clockwise, and fix A in position 1. E is in position 4, 5 or 6. C is immediately clockwise from B, and F is immediately clockwise from D. G is opposite C. H is adjacent to E. Every person occupies one seat. A gap of two clockwise positions means one occupied seat lies between the two people.", seat_work, [
        item("How many seating arrangements satisfy every condition?", len(seats), "The exhaustive block placement gives the three displayed orders."),
        item("Which person cannot be opposite A?", "F", "The persons opposite A in the three orders are E, H and B; never F.", ["E", "H", "B"]),
        item("If E is opposite A, what is F's position number?", unique(p["F"]+1 for _, p in seats if p["E"] == 4), "Only ADFGEHBC has E opposite A. F occupies position 3."),
        item("If H is two positions clockwise from G, how many people lie strictly between C and D when travelling clockwise from C?", unique((p["D"]-p["C"]-1) % 8 for _, p in seats if (p["H"]-p["G"]) % 8 == 2), "Only ADFGEHBC satisfies the extra condition. Clockwise from C to D, only A lies between them, so the answer is 1."),
        item("Who can occupy the position immediately clockwise from A?", "D or G only", "The three arrangements have D, D and G in position 2.", ["D only", "F or G only", "D, F or G"])
    ], 5040, len(seats), True)

    # 02/3: pair totals include the triple overlap.
    triple = 135 - (90+80+70-50-40-35)
    regions = [90-50-40+triple, 80-50-35+triple, 70-40-35+triple,
               50-triple, 40-triple, 35-triple, triple, 15]
    assert sum(regions) == 150 and min(regions) >= 0
    work = "Inclusion–exclusion gives 135 = 90 + 80 + 70 − 50 − 40 − 35 + t, hence t = 20. Subtract t from each pair total before obtaining single-course regions.\n" + table(["Region", "Students"], zip(["A only", "B only", "C only", "AB only", "AC only", "BC only", "ABC", "None"], regions))
    add(2, 3, "Course-registration overlap", "DI · three-set overlap",
        "A college has 150 students. Courses A, B and C have 90, 80 and 70 registrants respectively. Exactly 135 students take at least one of them. The numbers taking both A and B, both A and C, and both B and C are 50, 40 and 35 respectively; each of these pair counts includes students taking all three. A student may take zero, one, two or all three courses.", work, [
        item("How many students take all three courses?", triple, "The inclusion–exclusion equation gives 20."),
        item("How many students take exactly two courses?", sum(regions[3:6]), "Add the pair-only regions: 30 + 20 + 15 = 65.", [45, 50, 85]),
        item("How many students take A but neither B nor C?", regions[0], "A-only = 90 − 50 − 40 + 20 = 20."),
        item("Among C registrants, what fraction take exactly two courses?", "1/2", "Of C's 70 registrants, AC-only + BC-only = 20 + 15 = 35 take exactly two; 35/70 = 1/2.", ["2/7", "3/7", "5/7"])
    ], "Exact inclusion–exclusion equations", 1)

    # 02/4: conservation with route-specific loss, distinct from loss-free flow.
    routes = [(x, y) for x in range(81) for y in range(121)
              if F(3,4)*x+y == 100 and (80-x)+F(4,5)*(120-y) == 80]
    assert routes == [(40, 70)]
    add(2, 4, "Deliveries with transit loss", "DI · network conservation with losses",
        "Hub A receives 80 packages and hub B receives 120. Each hub sends every package to either C or D. Exactly one quarter of packages sent on A→C are damaged and discarded before arrival; none are lost on A→D or B→C. Exactly one fifth of packages sent on B→D are damaged and discarded. C receives 100 usable packages and D receives 80. No other routes or losses exist, and all numbers of packages sent and lost are integers.",
        "Let x be packages sent A→C and y those sent B→C. Then 3x/4 + y = 100 and (80 − x) + 4(120 − y)/5 = 80. Solving gives x = 40 and y = 70. The sent/usable route counts are A→C 40/30, A→D 40/40, B→C 70/70 and B→D 50/40.", [
        item("How many packages were sent on A→C?", routes[0][0], "The simultaneous conservation equations give x = 40."),
        item("How many usable packages does D receive from B?", 40, "B sends 120 − 70 = 50 towards D; four fifths, or 40, arrive usable.", [30, 50, 60]),
        item("How many packages are damaged in total?", 80+120-100-80, "Usable arrivals total 180 against 200 dispatched; the difference is 20."),
        item("What percentage of C's usable arrivals came from B?", "70%", "B supplies 70 of C's 100 usable arrivals.", ["60%", "75%", "80%"])
    ], 81*121, len(routes))

    # 02/5: constrained portfolio selection, including a prerequisite.
    projects = {"A": (4,2,9), "B": (5,3,12), "C": (3,3,8), "D": (4,1,7),
                "E": (6,2,15), "F": (2,2,6), "G": (5,4,14), "H": (3,1,8)}
    portfolios = []
    for chosen in combinations(projects, 3):
        cost, risk, benefit = (sum(projects[p][i] for p in chosen) for i in range(3))
        if cost <= 12 and risk <= 6 and (("A" in chosen)+("B" in chosen) == 1) and ("C" not in chosen or "D" in chosen):
            portfolios.append(("".join(chosen), cost, risk, benefit))
    assert len(portfolios) == 8
    work = "Enumerate the triples with exactly one of A and B, apply C's prerequisite, and reject excess cost or risk. The complete feasible table is:\n" + table(["Projects", "Cost", "Risk", "Benefit"], portfolios)
    add(2, 5, "Three-project development portfolio", "LR · selection and optimisation",
        "A council chooses exactly three of eight projects. Total cost must not exceed 12 units and total risk must not exceed 6. Benefits add. Exactly one of A and B must be chosen. If C is chosen, D must also be chosen. There are no other restrictions.\n" + table(["Project", "Cost", "Risk", "Benefit"], [(p, *v) for p,v in projects.items()]), work, [
        item("How many feasible portfolios are there?", len(portfolios), "Eight triples survive every restriction."),
        item("Which portfolio has the maximum benefit?", max(portfolios, key=lambda p:p[3])[0], "AEF has benefit 30, exceeding the next-best BDH at 27.", ["BDH", "BFH", "ACD"]),
        item("If H must be selected, what is the largest attainable benefit?", max(p[3] for p in portfolios if "H" in p[0]), "The feasible H portfolios are ADH, AFH, BDH and BFH; their benefits are 24, 23, 27 and 26. The maximum is 27."),
        item("What is the minimum cost among feasible portfolios with benefit at least 25?", min(p[1] for p in portfolios if p[3] >= 25), "Qualifying portfolios AEF, BDF, BDH and BFH cost 12, 11, 12 and 10. BFH attains the minimum 10.", [9, 11, 12])
    ], 56, len(portfolios), True)

    # 03/1: inventory recurrence with an endogenous sales fraction.
    inventories = []
    for x in range(1, 101):
        outputs = [x, x+10, 2*x, x+20]
        s1 = 20+x-30
        if (s1+outputs[1]) % 2: continue
        sold2 = (s1+outputs[1])//2
        closes = [s1, sold2, sold2+outputs[2]-40, sold2+outputs[2]-40+outputs[3]-60]
        if min(closes) >= 0 and closes[-1] == 100: inventories.append((x, outputs, sold2, closes))
    assert len(inventories) == 1
    x, outputs, sold2, closes = inventories[0]
    work = "Closing stock each day becomes the next day's opening stock. Day 1 closes at x − 10. Day 2 starts with x − 10, produces x + 10, and sells half of 2x, leaving x. Day 3 closes at 3x − 40. Day 4 closes at 4x − 80 = 100, so x = 45.\n" + table(["Day", "Output", "Sales", "Closing stock"], zip(range(1,5), outputs, [30,sold2,40,60], closes))
    add(3, 1, "Four days of factory inventory", "DI · inventory recurrence",
        "A factory opens Day 1 with 20 units in stock. Output on Days 1–4 is x, x + 10, 2x and x + 20 respectively, where x is a positive integer. Each day's output is available before that day's sales. Sales are 30 on Day 1, exactly half the available stock on Day 2, 40 on Day 3 and 60 on Day 4. Day 4 closes with 100 units. Stock is never negative and nothing is lost or returned.", work, [
        item("What is x?", x, "The Day 4 balance 4x − 80 = 100 gives x = 45."),
        item("How many units are sold on Day 2?", sold2, "Available stock is 90 and half is sold, giving 45.", [35, 40, 55]),
        item("What is the closing stock on Day 3?", closes[2], "45 + 90 − 40 = 95."),
        item("Which day has the greatest closing stock?", "Day 4", "Closing stocks are 35, 45, 95 and 100, so Day 4 is greatest.", ["Day 1", "Day 2", "Day 3"]),
        item("If only Day 4 sales are reduced by one third, what is the revised closing stock?", closes[3]+20, "Day 4 sales fall from 60 to 40, adding 20 to the original closing stock: 120.", [110, 130, 140])
    ], 100, 1)

    # 03/2: digit identities checked over all distinct positive digit assignments.
    digits = [(a,b,c,d,e) for a,b,c,d,e in permutations(range(1,10),5)
              if a+b == c and c+d == e and a*d == b+c and e % 2 and b > a]
    assert digits == [(2,3,5,4,9)]
    a,b,c,d,e = digits[0]
    add(3, 2, "The five-digit identification system", "LR · numerical constraint decoding",
        "A, B, C, D and E represent five distinct digits from 1 to 9. They satisfy A + B = C, C + D = E and A × D = B + C. E is odd and B > A. A two-letter expression such as AD means the two-digit number with tens digit A and units digit D; products are always written with ×.",
        "Substitute C = A + B into A × D = B + C to obtain A(D − 1) = 2B. Also E = A + B + D ≤ 9. Testing positive distinct digits with B > A and odd E leaves only A = 2, B = 3, C = 5, D = 4, E = 9. The bound on E sharply restricts A and D; this also checks all 15,120 distinct-digit assignments.", [
        item("What digit does C represent?", c, "The unique assignment has C = 5."),
        item("What is the two-digit number AD?", 10*a+d, "AD means 10A + D = 20 + 4 = 24.", [14, 25, 34]),
        item("What is E − A?", e-a, "9 − 2 = 7."),
        item("What is A + B + C + D + E?", a+b+c+d+e, "2 + 3 + 5 + 4 + 9 = 23."),
        item("What is C² − A × E?", c*c-a*e, "25 − 18 = 7.", [5, 9, 11])
    ], 15120, len(digits), True)

    # 03/3: two-resource integer production frontier.
    mixes = [(x,y,z,7*x+6*y+9*z) for x in range(5,21) for y in range(16) for z in range(14)
             if 2*x+y+3*z == 40 and x+2*y+z == 30]
    assert len(mixes) == 3
    work = "The resource equations are 2x + y + 3z = 40 and x + 2y + z = 30. They give z = 3y − 20 and x = 50 − 5y. Non-negative z and x ≥ 5 force y = 7, 8 or 9.\n" + table(["X", "Y", "Z", "Revenue"], mixes)
    add(3, 3, "The chemical production frontier", "DI · simultaneous constraints and revenue",
        "A laboratory makes whole batches of products X, Y and Z. X consumes 2 units of resource R and 1 of S; Y consumes 1 of R and 2 of S; Z consumes 3 of R and 1 of S. Exactly 40 units of R and 30 of S must be used, with no waste. At least five X batches must be made. Revenue per batch is ₹7 for X, ₹6 for Y and ₹9 for Z. Batch counts may otherwise be zero.", work, [
        item("How many feasible production mixes are possible?", len(mixes), "Only y = 7, 8 or 9 yields non-negative counts with x ≥ 5."),
        item("Which mix maximises revenue? Counts are X, Y, Z.", "15, 7, 1", "Revenues are 156, 154 and 152 for (15, 7, 1), (10, 8, 4) and (5, 9, 7), respectively.", ["10, 8, 4", "5, 9, 7", "20, 6, 0"]),
        item("Among mixes earning at least ₹154, what is the greatest number of Z batches?", max(z for x,y,z,r in mixes if r >= 154), "Only the first two mixes qualify; their Z counts are 1 and 4, giving 4."),
        item("If the revenue per Y batch rises to ₹10, how many Y batches occur in the revenue-maximising mix?", max(mixes,key=lambda m:7*m[0]+10*m[1]+9*m[2])[1], "Revised revenues are 184, 186 and 188. Thus y = 9 is optimal.", [6, 7, 8])
    ], 16*16*14, len(mixes), True)

    # 03/4: pair-sum reconstruction with a genuinely unresolved pair.
    agecases = [v for v in permutations(range(21,27))
                if v[0]+v[1] == 49 and v[2]+v[3] == 47 and v[4]+v[5] == 45 and v[0]>v[3] and v[1]<v[4]]
    assert len(agecases) == 2
    agework = "The distinct ages are 21–26. The three disjoint pair sums and the two inequalities leave:\n" + table(list("ABCDEF"), agecases) + "\nThus only C and D remain interchangeable; the other four ages are fixed."
    add(3, 4, "Ages inferred from pair totals", "LR · pair sums and partial identification",
        "Six researchers A through F have distinct integer ages 21, 22, 23, 24, 25 and 26, one each. A and B together are 49 years old; C and D together are 47; E and F together are 45. A is older than D, and B is younger than E.", agework, [
        item("What is F's age?", unique(v[5] for v in agecases), "F is 21 in both feasible assignments."),
        item("Who is necessarily the oldest?", "A", "A is 26 in both rows; no other person can have that age.", ["C", "D", "E"]),
        item("If C is younger than D, what is their age difference?", unique(v[3]-v[2] for v in agecases if v[2]<v[3]), "The extra condition fixes C = 22 and D = 25, a difference of 3."),
        item("Which pair of people is not individually identifiable from the original information?", "C and D", "The two feasible assignments differ only by exchanging C's and D's ages.", ["A and B", "B and E", "E and F"])
    ], 720, len(agecases))

    # 03/5: a league with two feasible completions and conditional outcomes.
    teams = "ABCDE"; pairs = list(combinations(teams,2)); leagues=[]
    for results in product(range(3), repeat=10):
        pts = dict.fromkeys(teams,0); outcomes={}
        for (u,v),r in zip(pairs,results):
            outcomes[u+v]=r
            if r==0: pts[u]+=1; pts[v]+=1
            else: pts[u if r==1 else v]+=3
        if list(pts.values()) == [10,7,4,4,3] and outcomes["AB"]==0 and outcomes["CD"]==0 and outcomes["CE"]==1:
            leagues.append(outcomes)
    assert len(leagues)==2
    leaguework = "Ten games distribute 28 points, so exactly two games are draws; they are the stated A–B and C–D draws. A wins its other three games. B has two wins and one loss; C and D each have one win, one draw and two losses; E has one win and three losses. C's win is against E. The unresolved triangle B, D, E has two orientations: B beats D, D beats E, E beats B; or D beats B, B beats E, E beats D."
    add(3, 5, "A league with an unresolved triangle", "LR · tournaments and conditional results",
        "Five teams A–E play each other once. A win earns 3 points, a draw 1 per team and a loss 0. Final points are A = 10, B = 7, C = 4, D = 4, E = 3. A drew with B; C drew with D; C defeated E. No penalties or bonuses apply.", leaguework, [
        item("How many games ended in draws?", 30-sum([10,7,4,4,3]), "The ten games would give 30 points if decisive; the actual sum of 28 implies two draws."),
        item("Which statement must be true?", "B lost exactly one game", "Seven points from four games, including its draw with A, requires two wins and one loss.", ["B defeated E", "D defeated B", "E defeated D"]),
        item("How many complete sets of game results satisfy all the data?", len(leagues), "The two possible directed cycles on B, D and E are the only remaining alternatives."),
        item("If E defeated B, what was the result of D against E?", "D won", "E's sole win has been used against B; D's sole win must therefore be against E, giving the first triangle orientation.", ["E won", "Draw", "Cannot be determined"])
    ], 3**10, len(leagues), True)

    # 04/1: a fixed-quantity price index, with basket quantities reconstructed.
    baskets = [(a,b,c) for a in range(91) for b in range(91-a)
               for c in [90-a-b] if 3*a==4*b and 2*a+3*b+5*c==270]
    assert baskets == [(40,30,20)]
    a,b,c=baskets[0]; newcost=F(5,2)*a+F(33,10)*b+6*c
    assert newcost.denominator==1
    add(4, 1, "What changed in the basket index?", "DI · weighted price indices",
        "A standard basket contains 90 items of types A, B and C. Base prices per item are ₹2, ₹3 and ₹5 respectively. The basket's base cost is ₹270 and its A:B quantity ratio is 4:3. In the next period A's price rises 25%, B's rises 10% and C's rises 20%. Basket quantities remain fixed unless a question explicitly changes them.",
        "Write quantities A = 4t, B = 3t and C = 90 − 7t. The base-cost equation is 8t + 9t + 5(90 − 7t) = 270, giving t = 10. Thus quantities are 40, 30 and 20. New prices are ₹2.50, ₹3.30 and ₹6.00, and new contributions are ₹100, ₹99 and ₹120. Base contributions were ₹80, ₹90 and ₹100.", [
        item("How many C items does the standard basket contain?", c, "C = 90 − 70 = 20."),
        item("What is the new cost of the unchanged basket?", int(newcost), "100 + 99 + 120 = ₹319.", [297, 309, 324]),
        item("At the new prices, how many rupees are saved if ten B items are replaced by ten A items?", 8, "The per-item saving is 3.30 − 2.50 = ₹0.80; ten replacements save ₹8."),
        item("Which type or types contribute the greatest absolute increase in basket cost?", "A and C equally", "A adds ₹20, B adds ₹9, and C adds ₹20.", ["A only", "B only", "C only"]),
        item("What is the new fixed-basket price index, with the base period set to 100, rounded to two decimals?", f"{float(newcost/F(270))*100:.2f}", "The index is 319/270 × 100 = 118.148..., which rounds to 118.15.", ["117.00", "118.00", "120.00"])
    ], 4186, 1)

    # 04/2: capital-times-months with a permutation of investment periods.
    capitals=[40,60,80,100]
    partnerships=[]
    for months in permutations([6,8,10,12]):
        capitalmonths=[c*m for c,m in zip(capitals,months)]
        if 3*capitalmonths[0]==4*capitalmonths[1] and capitalmonths[2]==capitalmonths[3]:
            partnerships.append((months,capitalmonths))
    assert len(partnerships)==1
    months,weights=partnerships[0]
    add(5, 2, "When the partners invested", "DI · ratios and time-weighted capital",
        "Partners A, B, C and D invest ₹40,000, ₹60,000, ₹80,000 and ₹100,000 respectively. Each makes one investment, unchanged until a common year-end. Their investment durations are 6, 8, 10 and 12 months, one each. Profit is divided in proportion to capital multiplied by months invested. A:B profit shares are 4:3 and C and D receive equal shares. The total profit is ₹244,000.",
        "Measure capital in thousands. The A:B condition gives 40m_A/(60m_B) = 4/3, hence m_A = 2m_B. The available durations force m_A = 12 and m_B = 6. Equal C and D shares require 80m_C = 100m_D, fixing m_C = 10 and m_D = 8.\n"+table(["Partner","Months","Capital-month weight","Profit (₹)"],zip("ABCD",months,weights,[100*w for w in weights])), [
        item("How much profit, in rupees, does B receive?",100*weights[1],"Weights total 2440, so each weight unit receives ₹100; B receives 360 × 100 = ₹36,000."),
        item("Which pair receives equal amounts?","C and D","Both have capital-month weight 800 and receive ₹80,000.",["A and B","A and C","B and D"]),
        item("For how many months was B's original investment active?",months[1],"The ratio and duration list force B's duration to 6 months."),
        item("Instead, suppose B doubles its capital only for the final two months of its six-month investment. Other investments are unchanged and the profit pool is ₹256,000. What is B's revised profit in rupees?",48000,"B's weight rises from 360 to 480; total weight rises from 2440 to 2560. Its share is 480/2560 × 256000 = ₹48,000."),
        item("What fraction of the original profit pool belongs to A?","12/61","A's fraction 480/2440 reduces to 12/61.",["9/61","20/61","1/4"])
    ],24,1,True)

    # 04/3: common turnout reconstructed from valid-vote rates.
    electorate=[1250,1250,1000]; validrates=[F(9,10),F(4,5),F(7,8)]
    turnout=F(2400,sum(n*r for n,r in zip(electorate,validrates)))
    ballots=[int(n*turnout) for n in electorate]
    valid=[int(n*r) for n,r in zip(ballots,validrates)]
    votes_r=[valid[0]*5//9,valid[1]*3//8,valid[2]*4//7]
    votes_s=[v-r for v,r in zip(valid,votes_r)]
    assert turnout==F(4,5) and sum(votes_r)==sum(votes_s)==1200
    add(4,3,"Turnout and a tied election","DI · percentages with changing bases",
        "Booths A, B and C have 1250, 1250 and 1000 registered voters respectively. The same percentage of registered voters votes at each booth. Every voter casts one ballot. Invalid ballots are 10% of votes cast at A, 20% at B and 12.5% at C. There are 2400 valid ballots overall. All valid ballots go to candidates R or S. Their valid-vote ratios R:S are 5:4 at A, 3:5 at B and 4:3 at C.",
        "If the common turnout fraction is t, valid ballots total t(1250 × 0.9 + 1250 × 0.8 + 1000 × 0.875) = 3000t = 2400. Thus t = 0.8.\n"+table(["Booth","Cast","Valid","R","S"],zip("ABC",ballots,valid,votes_r,votes_s)),[
        item("What is the common turnout percentage?",int(turnout*100),"t = 0.8, so turnout is 80%."),
        item("What is the overall outcome based on valid ballots?","Tie","Both candidates receive 1200 valid votes.",["R wins by 100","S wins by 100","R wins by 200"]),
        item("How many invalid ballots are cast in total?",sum(ballots)-sum(valid),"Ballots cast total 2800; subtract 2400 valid ballots to obtain 400 invalid ballots."),
        item("If a recount transfers 10% of S's booth-B votes to R, leaving all else unchanged, what is R's winning margin?",100,"S has 500 votes at B, so 50 votes transfer. R gains 50 and S loses 50, producing a 100-vote margin.",[50,150,200])
    ],"Exact turnout and booth-share equations",1)

    # 04/4: infer return counts from a count and value total.
    returns=[(x,38-x) for x in range(39) if x<=120 and 38-x<=80 and 200*x+250*(38-x)==8000]
    assert returns==[(30,8)]
    add(5,3,"Returns across two sales channels","DI · refunds and retained revenue",
        "A retailer sells 120 units online at ₹200 each and 80 units in shops at ₹250 each. Later, exactly 38 of these units are returned, for full refunds at the original channel price. The total refund is ₹8,000. There are no taxes, discounts, exchanges or other transactions. Each unit is returned at most once.",
        "Let x be online returns; shop returns are 38 − x. The refund equation 200x + 250(38 − x) = 8000 gives x = 30 and shop returns 8. Retained units are 90 online and 72 in shops. Original revenue is ₹44,000 and retained revenue is ₹36,000.",[
        item("What percentage of online units is returned?",25,"30/120 × 100 = 25%."),
        item("How much revenue is retained from shop sales?",18000,"(80 − 8) × 250 = ₹18,000.",[16000,17500,20000]),
        item("How many sold units are retained by customers overall?",200-38,"200 − 38 = 162 units are not returned."),
        item("If the online selling price had been 10% higher, with the same numbers sold and returned in both channels and full refunds at that revised price, what total revenue would be retained?",37800,"Online net revenue becomes 90 × 220 = ₹19,800; shop net revenue remains ₹18,000. Total: ₹37,800.",[36800,38000,38800])
    ],39,1)

    # 04/5: piecewise net rates with linked durations.
    tankcases=[]
    for a in range(1,73):
        for b in range(1,73):
            c=2*b
            if 2*a==3*b and 20*a+40*b+10*c==720:tankcases.append((a,b,c))
    assert tankcases==[(12,8,16)]
    add(4,5,"Three phases of filling a reservoir","DI · rates and duration ratios",
        "An empty 720-litre reservoir is filled using inlet P at 30 litres/minute and inlet Q at 20 litres/minute. A leak removes 10 litres/minute whenever water is present. First only P runs for a minutes; next P and Q run together for b minutes; finally only Q runs for c minutes. The phase durations satisfy a:b = 3:2 and c = 2b. The reservoir becomes exactly full at the end of the third phase and never overflows.",
        "Net filling rates in the phases are 20, 40 and 10 litres/minute. Put a = 3t, b = 2t and c = 4t. Then total water is 60t + 80t + 40t = 180t = 720, giving t = 4 and durations 12, 8 and 16 minutes. The phases contribute 240, 320 and 160 litres. Total time is 36 minutes; gross inflow is 1080 litres and leak loss is 360 litres.",[
        item("How many minutes does the middle phase last?",8,"b = 2t = 8."),
        item("What fraction of final water is added during the middle phase?","4/9","Its 320 litres form 320/720 = 4/9 of the final contents.",["1/3","2/5","1/2"]),
        item("How many litres escape through the leak during the entire process?",360,"Water is present after filling starts, and the leak operates for 36 minutes: 10 × 36 = 360 litres."),
        item("If the leak were blocked but the same inlet schedule were run in a larger initially empty reservoir, what capacity would just avoid overflow?",1080,"Gross inflow is 30(12 + 8) + 20(8 + 16) = 600 + 480 = 1080 litres.",[900,960,1200])
    ],72*72,1)


def batch_05():
    # 05/1: all 9! placements are tested, not merely the displayed solutions.
    grids=[]
    for v in permutations(range(1,10)):
        if [sum(v[:3]),sum(v[3:6]),sum(v[6:])]!=[12,15,18]: continue
        if [sum(v[i::3]) for i in range(3)]!=[14,17,14]: continue
        if v[0]+v[4]+v[8]!=14 or v[1]%2!=1: continue
        grids.append(v)
    assert len(grids)==3
    assert all(v[4]%2==1 for v in grids)
    assert not all(v[4]==5 for v in grids)
    assert not all(v[1]==9 for v in grids)
    assert not all(v[6]>max(v[7:]) for v in grids)
    gridwork="The row totals sum to 45, exactly the sum of 1 through 9. Select a distinct-digit top row summing to 12 with an odd middle, then a disjoint middle row summing to 15. Each column total determines its bottom entry. Reject repeated or missing digits and test the main diagonal. The complete list is:\n"+table(["Top row","Middle row","Bottom row"],[[" ".join(map(str,v[i:i+3])) for i in (0,3,6)] for v in grids])+"\nThus there are three, and only three, feasible grids. Rows and columns refer to their displayed positions; rotations are not identified."
    add(5,1,"The incomplete number panel","LR · number-grid reconstruction",
        "A 3 by 3 panel contains each integer from 1 to 9 exactly once. The totals of its top, middle and bottom rows are 12, 15 and 18 respectively. The totals of its left, middle and right columns are 14, 17 and 14 respectively. The main diagonal, from the top-left cell through the centre to the bottom-right cell, totals 14. The top-middle cell contains an odd number. There are no other conditions.",gridwork,[
        item("How many complete grids satisfy all the conditions?",len(grids),"There are three distinct grids in the complete list."),
        item("Which statement must be true?","The centre contains an odd number","The centre is 5, 5 or 7, so it is always odd. It need not be 5; the top-middle need not be 9. In the third grid, the bottom-left entry 5 is not the largest in its row.",["The centre contains 5","The top-middle contains 9","The bottom-left is the largest entry in its row"]),
        item("If the top-left entry is 2, what is the bottom-middle entry?",unique(v[7] for v in grids if v[0]==2),"Only the second grid has top-left entry 2. Its bottom row is 8, 3, 7, giving bottom-middle 3."),
        item("What is the largest possible sum of the top-left and bottom-right entries?",max(v[0]+v[8] for v in grids),"The three corner sums are 1+8=9, 2+7=9 and 3+4=7. The maximum is 9.",[7,10,11]),
        item("If the centre contains 7, what is the top-right entry?",unique(v[2] for v in grids if v[4]==7),"The third grid is the only one with centre 7. Its top-right entry is 8.",[1,4,9])
    ],362880,len(grids),hard=True)

    # 05/2: discrete nonpreemptive schedules with a shared resource and outage.
    schedules=[]
    for c,d,e in product(range(8),repeat=3):
        if c<2 or d<3 or c==d or c==4 or d==4: continue
        if e<max(c+1,d+1) or e+2>8: continue
        schedules.append((c,d,e,e+2))
    assert len(schedules)==6
    assert unique((c,d) for c,d,e,f in schedules if f<=7)==(2,3)
    schedulework="A occupies machine 1 during [0,2), and B occupies machine 2 during [1,3). Consequently C must start at c≥2 and D at d≥3. Their one-minute durations and the common technician imply c≠d; the technician's outage forbids c=4 and d=4. E must start at e≥max(c+1,d+1) and e≤6. Enumerating these integer bounds gives:\n"+table(["C start","D start","E start","Final completion"],schedules)+"\nAll unused machine or technician time is allowed to remain idle."
    add(4,2,"Two machines and one technician","LR · resource-constrained scheduling",
        "Five jobs A, B, C, D and E must be completed. Times are measured in whole minutes from time 0. Every start time is a nonnegative integer. Jobs cannot be interrupted, and two jobs cannot use the same machine simultaneously.\n"+table(["Job","Machine(s)","Duration","Restriction"],[["A","1",2,"Starts at 0"],["B","2",2,"Starts at 1"],["C","1",1,"Starts only after A finishes"],["D","2",1,"Starts only after B finishes"],["E","1 and 2",2,"Starts only after both C and D finish"]])+"\nC and D each additionally need the same single technician throughout their execution, so they cannot overlap. That technician is unavailable from time 4 inclusive to time 5 exclusive. No other job needs the technician. One job may start exactly when another finishes. Idle time is permitted. Every job must finish by time 8. Two schedules are different if at least one of C, D or E has a different start time.",schedulework,[
        item("What is the earliest possible time at which all jobs are complete?",min(s[-1] for s in schedules),"C can run during [2,3), D during [3,4), and E during [4,6). The two one-minute technician jobs cannot both finish before 4, so final completion before 6 is impossible."),
        item("How many different complete schedules meet all the conditions?",len(schedules),"The full enumeration has six distinct triples of start times for C, D and E.",[4,5,8]),
        item("If E starts at time 6, how many different schedules are possible?",sum(s[2]==6 for s in schedules),"The possible (C,D) start pairs are (2,3), (2,5), (3,5) and (5,3): four schedules."),
        item("If C starts at time 3 and D at time 5, for how many minutes in total is machine 1 idle from time 0 until E starts?",unique(e-3 for c,d,e,f in schedules if c==3 and d==5),"D finishes at 6, forcing E to start at 6 to meet the deadline. Before time 6, machine 1 works for two minutes on A and one minute on C. Its idle time is 6−2−1=3 minutes: [2,3) and [4,6)."),
        item("If every job must instead finish by time 7, which start-time pair for C and D is possible?","C at 2, D at 3","Only the first two rows finish by 7. Both have C starting at 2 and D at 3. Each other listed pair forces E to start at 6, so completion is at 8.",["C at 2, D at 5","C at 3, D at 5","C at 5, D at 3"])
    ],512,len(schedules),hard=True)

    # 05/3: truth values are calculated from the assigned numbers themselves.
    truthcases=[]
    for v in permutations(range(1,6)):
        a,b,c,d,e=v
        truths=[b>a,c%2==0,d in (1,5),a+e==6,b==3]
        if sum(truths)==2 and sum(n for n,t in zip(v,truths) if t)==7:
            truthcases.append((v,"".join(p for p,t in zip("ABCDE",truths) if t)))
    assert len(truthcases)==5
    truthpairs={s for v,s in truthcases}
    assert "CE" not in truthpairs and {"AB","AC","AD"}<=truthpairs
    truthwork="The two truthful speakers must hold numbers 2 and 5, or 3 and 4, since their distinct numbers total 7. For each assignment of the five numbers, calculate all five statements and retain it only if exactly two are true and those speakers' numbers total 7. The complete possibilities are:\n"+table(["A","B","C","D","E","Truthful speakers"],[list(v)+[s] for v,s in truthcases])+"\nFor example, in the first row only A's comparison (3>2) and E's claim (B=3) are true; those speakers hold 2 and 5. The other rows are checked in the same way."
    add(4,4,"Number holders and true statements","LR · truth-condition decoding",
        "Five people A, B, C, D and E hold the integers 1, 2, 3, 4 and 5, one distinct integer each. They make the following statements.\nA: 'B's number is greater than mine.'\nB: 'C's number is even.'\nC: 'D's number is either 1 or 5.'\nD: 'A's and E's numbers add to 6.'\nE: 'B's number is 3.'\nExactly two of these five statements are true. The numbers held by the two people whose statements are true add to 7. A statement's truth is determined only by the number assignment; there is no additional rule about permanent truth-tellers or liars.",truthwork,[
        item("How many assignments of numbers satisfy all the information?",len(truthcases),"There are five assignments in the exhaustive table."),
        item("Which pair cannot be exactly the two people making true statements?","C and E","The feasible truthful pairs are AE, AC, AB, AD and BD. CE does not occur, whereas each of AB, AC and AD does.",["A and B","A and C","A and D"]),
        item("If E holds 1, what is the largest possible product of the numbers held by A and C?",max(v[0]*v[2] for v,s in truthcases if v[4]==1),"Two assignments have E=1: (A,B,C,D,E)=(2,5,4,3,1) and (5,4,2,3,1). The products A×C are 8 and 10 respectively. Thus the maximum is 10."),
        item("What is the largest number that A can hold?",max(v[0] for v,s in truthcases),"A can hold 2, 4 or 5. In the final row A holds 5 and only B and D are truthful, holding 4 and 3. Hence 5 is attainable and is the maximum.",[2,3,4])
    ],120,len(truthcases),hard=True)

    # 05/4: test every subset, calculating parity and cost independently.
    masks=[3,6,5,12,24,20]
    costs=[1,4,6,2,3,7]
    plans=[]
    for bits in product((0,1),repeat=6):
        state=0
        for bit,mask in zip(bits,masks):
            if bit: state^=mask
        if state==17:
            plans.append(("".join(x for x,b in zip("ABCDEF",bits) if b),sum(bits),sum(c*b for c,b in zip(costs,bits))))
    assert len(plans)==4
    cheapest=unique(name for name,press,cost in plans if cost==min(p[2] for p in plans))
    assert {p[0] for p in plans}=={"CF","CDE","ABF","ABDE"}
    switchwork="Let a,b,c,d,e,f be 0 or 1 according to whether each button is pressed. Lamp 2 must remain OFF, so a=b. Lamp 4 must remain OFF, so d=e. Lamp 1 must be ON, so c=1−a; lamp 5 must be ON, so f=1−d. With these substitutions, lamp 3 receives an even number of toggles automatically. Thus the independent choices of a and d yield four plans:\n"+table(["Buttons pressed","Number of presses","Total cost"],plans)+"\nThis also shows why the minimum-press plan need not be the cheapest plan."
    add(5,4,"The priced switchboard","LR · parity and constrained optimization",
        "Five lamps numbered 1 to 5 are initially OFF. Six buttons are available. Pressing a button toggles exactly the two lamps listed below: an OFF lamp becomes ON and an ON lamp becomes OFF. Each button may be pressed at most once.\n"+table(["Button","Lamps toggled","Cost"],[["A","1 and 2",1],["B","2 and 3",4],["C","1 and 3",6],["D","3 and 4",2],["E","4 and 5",3],["F","3 and 5",7]])+"\nA valid plan ends with lamps 1 and 5 ON and lamps 2, 3 and 4 OFF. A plan is a set of buttons; different orders of pressing the same set do not count as different plans. Total cost is the sum of costs of the buttons pressed.",switchwork,[
        item("How many valid plans are there?",len(plans),"The four possibilities are CF, CDE, ABF and ABDE."),
        item("Which valid plan has the least total cost?",cheapest,"ABDE costs 1+4+2+3=10. The alternatives CDE, ABF and CF cost 11, 12 and 13 respectively.",["CDE","ABF","CF"]),
        item("What is the smallest number of button presses in any valid plan?",min(p[1] for p in plans),"CF needs two presses: lamp 3 is toggled twice, while lamps 1 and 5 are each toggled once. No single button toggles exactly lamps 1 and 5."),
        item("If total cost cannot exceed 11, what is the smallest possible number of button presses?",min(press for name,press,cost in plans if cost<=11),"The affordable valid plans are ABDE (cost 10, four presses) and CDE (cost 11, three presses). CF has fewer presses but exceeds the budget. Hence the required minimum is 3.",[2,4,5])
    ],64,len(plans),hard=True)

    # 05/5: combinations, two exact quotas, and logical implication constraints.
    staffcosts=[5,3,4,6,4,7,2,5]
    committees=[]
    for selected in combinations(range(8),4):
        if sum(i<4 for i in selected)!=2: continue
        if sum(i in (0,2,5,7) for i in selected)!=2: continue
        if 0 in selected and 4 in selected: continue
        if (1 in selected)!=(6 in selected): continue
        if 2 in selected and 7 in selected: continue
        committees.append(("".join("ABCDEFGH"[i] for i in selected),sum(staffcosts[i] for i in selected)))
    assert len(committees)==4
    affordable=[name for name,cost in committees if cost<=16]
    common=set.intersection(*(set(name) for name in affordable))
    assert common=={"B","G"}
    committeework="Start with the 6 possible pairs of analysts and 6 pairs of engineers. Keep exactly two certified people, enforce the exclusions AE and CH, and enforce that B and G either both occur or both do not. The complete feasible committees are:\n"+table(["Committee","Cost"],committees)+"\nWhen B and G are selected, the remaining analyst and engineer must both be certified: AF, AH or CF works, while CH is excluded. When B and G are both absent, the only feasible committee is CDEF. This split proves completeness without listing all 70 four-person subsets."
    add(5,5,"The dual-quota review committee","LR · selection with linked membership",
        "A four-person committee must be selected from eight staff. It must contain exactly two analysts, exactly two engineers and exactly two certified people. The table also gives each person's participation cost, in the same units.\n"+table(["Person","Role","Certified?","Cost"],[["A","Analyst","Yes",5],["B","Analyst","No",3],["C","Analyst","Yes",4],["D","Analyst","No",6],["E","Engineer","No",4],["F","Engineer","Yes",7],["G","Engineer","No",2],["H","Engineer","Yes",5]])+"\nA and E cannot both be selected. B is selected if and only if G is selected: either both are selected or neither is selected. C and H cannot both be selected. There are no other restrictions unless a question adds one. The committee's total cost is the sum of its members' costs.",committeework,[
        item("How many committees satisfy all the original conditions?",len(committees),"The possibilities are ABFG, ABGH, BCFG and CDEF: four committees."),
        item("What is the minimum possible committee cost?",min(cost for name,cost in committees),"ABGH costs 5+3+2+5=15. The remaining feasible costs are 17, 16 and 21, all larger.",[14,16,17]),
        item("If C must be selected, what is the maximum possible committee cost?",max(cost for name,cost in committees if "C" in name),"With C selected the possible committees are BCFG (cost 16) and CDEF (cost 21). Therefore the maximum is 21."),
        item("If total cost cannot exceed 16, which pair is present in every permissible committee?","B and G","The budget permits ABGH and BCFG only. Their common members are exactly B and G. Each other option contains someone absent from at least one of those committees.",["A and H","C and F","F and G"])
    ],70,len(committees),hard=True)


def build():
    batch_02_04()
    batch_05()
    # Since 2026-11-07 Papers 04 and 05 exchange two sets each so that both carry two or three
    # DI sets, as the 2024-2025 papers did. Sets are kept in set order and renumbered.
    for paper, questions in BANK.items():
        questions.sort(key=lambda q: int(q["groupId"][2:]))
        for number, question in enumerate(questions, 1):
            question["id"] = f"D{number:02}"
    for paper, questions in BANK.items():
        assert len(questions)==22, (paper,len(questions))
        assert Counter(q["type"] for q in questions)=={"TITA":11,"MCQ":11}
        assert [sum(q["groupId"]==f"DL{g}" for q in questions) for g in range(1,6)]==[5,5,4,4,4]
    return BANK


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--emit",type=int)
    parser.add_argument("--check",type=int,nargs="*")
    args=parser.parse_args()
    bank=build()
    if args.emit is not None:
        print(json.dumps(bank[args.emit],ensure_ascii=False,indent=2))
        return
    selected=args.check or sorted(bank)
    for paper in selected:
        file=ROOT/"papers"/f"paper-{paper:02}-dilr.js"
        text=file.read_text(encoding="utf-8")
        match=re.search(r"window\.CAT2026_DILR\s*=\s*(\[.*\]);\s*\}\)\(\);",text,re.S)
        assert match, f"Cannot locate array in {file}"
        actual=json.loads(match.group(1))
        assert actual==bank[paper], f"Data or key differs from recomputed constraints: Paper {paper:02}"
    print(json.dumps({"status":"passed","papers":selected,"questions":22*len(selected),
                      "TITA":11*len(selected),"MCQ":11*len(selected),
                      "proofs":[p for p in PROOFS if p["paper"] in selected]},ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
