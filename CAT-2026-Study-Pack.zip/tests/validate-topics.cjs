// Checks the topic-level data, the forecast it produces, and that the ten papers follow it.
const assert = require('assert'), fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..');
const context = {window: {}};
vm.createContext(context);
for (const file of ['history-data.js', 'topic-data.js', 'forecast-engine.js', 'paper-catalog.js'])
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, {filename: file});
const w = context.window, T = w.CAT_TOPICS, E = w.CATForecastEngine;
const keys = T.groups.map(g => g.key), G2 = T.twoIIM.groups, sum = a => a.reduce((s, x) => s + x, 0);
const results = [];
const test = (name, fn) => { fn(); results.push({name, status: 'passed'}); };

test('Cracku rows: 12 groups, sum to the section size, three shifts a year 2020-2025', () => {
  assert.equal(T.cracku.rows.length, 18);
  for (const r of T.cracku.rows) {
    assert.equal(r.counts.length, keys.length);
    assert.ok(r.counts.every(c => Number.isInteger(c) && c >= 0));
    assert.equal(sum(r.counts), r.year === 2020 ? 26 : 22, `${r.year} S${r.slot}`);
  }
  for (let y = 2020; y <= 2025; y++) assert.equal(T.cracku.rows.filter(r => r.year === y).length, 3);
});

test('2IIM rows: question and typed-answer counts per shift match the papers', () => {
  const expected = {2017: [34, 11], 2018: [34, 12], 2019: [34, 11], 2020: [26, 8], 2024: [22, 8]};
  for (const r of E.taggedRows(T.twoIIM.rows, G2)) {
    assert.equal(r.n, expected[r.year][0], `${r.year} S${r.slot}`);
    assert.equal(r.items.filter(i => i.t === 'T').length, expected[r.year][1], `${r.year} S${r.slot}`);
  }
});

const forecast = E.topicForecast(T.cracku.rows, {targetYear: 2026});
test('Forecast: whole-number mix sums to 22 and matches the published table', () => {
  assert.equal(sum(forecast.allocation), 22);
  assert.deepEqual(forecast.allocation, [3, 2, 2, 4, 2, 1, 1, 2, 3, 2, 0, 0]);
  assert.ok(Math.abs(forecast.expectedHits - 6.47) < 0.01);
  assert.deepEqual(forecast.groups.map(g => g.range), [[2, 5], [1, 3], [2, 4], [2, 4], [1, 2], [1, 3], [0, 2], [1, 2], [2, 3], [1, 3], [0, 1], [0, 1]]);
  assert.ok(Math.abs(sum(forecast.groups.map(g => g.mean)) - 22) < 1e-9);
  for (const g of forecast.groups) assert.ok(Math.abs(sum(g.dist) - 1) < 1e-9);
});

test('Backtest: half-life 2 is best of the tested weightings and beats an equal split', () => {
  const b = E.topicBacktest(T.cracku.rows);
  const best = b.byHalfLife.reduce((a, h) => h.mae < a.mae ? h : a);
  assert.equal(best.halfLife, 2);
  assert.ok(Math.abs(best.mae - 0.724) < 0.001 && Math.abs(b.noiseFloor - 0.678) < 0.001);
  assert.ok(b.uniform.mae > best.mae + 0.2);
  const lastOnly = b.byHalfLife.find(h => h.halfLife === 0.5), equal = b.byHalfLife.find(h => h.halfLife === Infinity);
  assert.ok(lastOnly.mae > best.mae && equal.mae > best.mae);
});

test('Backtest uses only earlier years (changing a later year leaves earlier forecasts unchanged)', () => {
  const changed = T.cracku.rows.map(r => r.year === 2025 ? {...r, counts: [22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]} : r);
  const a = E.topicBacktest(T.cracku.rows), b = E.topicBacktest(changed);
  for (let h = 0; h < a.byHalfLife.length; h++) assert.deepEqual(a.byHalfLife[h].errors.slice(0, 3), b.byHalfLife[h].errors.slice(0, 3));
});

test('Setter test: no repeat of a setter’s earlier topic tilt', () => {
  const merged = r => { const c = Object.fromEntries(keys.map((k, i) => [k, r.counts[i]])); c.EQ = c.LIN + c.QUAD; return {...r, shares: G2.map(g => c[g] / sum(r.counts))}; };
  const st = E.setterRepeatTest(E.taggedRows(T.twoIIM.rows.filter(r => r.year <= 2020), G2), T.cracku.rows.map(merged), T.setterPairs);
  assert.deepEqual(st.pairs.map(p => Math.round(100 * p.r) / 100), [-0.41, 0.11, 0.33]);
  assert.ok(Math.abs(st.pooledSlope) < 0.1);
});

test('Typed-answer tendency: 116 of 348 tagged questions, P&C mostly typed', () => {
  const t = E.titaTendency(T.twoIIM.rows, G2);
  assert.equal(t.questions, 348);
  assert.ok(Math.abs(t.overall - 116 / 348) < 1e-12);
  const pnc = t.groups.find(g => g.group === 'PNC');
  assert.equal(pnc.tita, 8); assert.equal(pnc.questions, 10);
});

const files = n => n === '01' ? ['prediction-varc.js', 'prediction-dilr.js', 'prediction-qa.js'] : ['varc', 'dilr', 'qa'].map(s => `papers/paper-${n}-${s}.js`);
const papers = {};
for (const p of w.CAT_PAPER_CATALOG) {
  const win = {};
  for (const f of files(p.number)) vm.runInNewContext(fs.readFileSync(path.join(root, f), 'utf8'), {window: win});
  papers[p.number] = win;
}

test('Every paper: 22 topic tags, regular papers inside every likely range, scenarios declared', () => {
  assert.deepEqual(Object.keys(T.mocks).sort(), w.CAT_PAPER_CATALOG.map(p => p.number));
  for (const [paper, seq] of Object.entries(T.mocks)) {
    const items = seq.split(' ');
    assert.equal(items.length, 22, paper);
    assert.ok(items.every(x => keys.includes(x)), paper);
    const counts = keys.map(k => items.filter(x => x === k).length);
    const out = keys.filter((k, i) => counts[i] < forecast.groups[i].range[0] || counts[i] > forecast.groups[i].range[1]);
    if (T.scenarios[paper]) continue;
    assert.deepEqual(out, [], `Paper ${paper} outside forecast range: ${out}`);
  }
  assert.deepEqual(Object.keys(T.scenarios).sort(), ['07', '09']);
  assert.equal(w.CAT_PAPER_CATALOG.find(p => p.number === '09').focus, 'Indore scenario');
});

test('Paper topic labels agree with the family counts in the catalog', () => {
  const families = ['Arithmetic', 'Algebra', 'Geometry', 'Number Systems', 'Modern Math'];
  for (const p of w.CAT_PAPER_CATALOG) {
    const qa = papers[p.number].CAT2026_QA;
    assert.deepEqual(families.map(f => qa.filter(q => q.topic === f).length), p.qa, p.number);
  }
});

test('Every paper: 5/5/4/4/4 DILR sets with 11 typed answers, DI/LR tags match the set labels', () => {
  for (const p of w.CAT_PAPER_CATALOG) {
    const d = papers[p.number].CAT2026_DILR, groups = [...new Set(d.map(q => q.groupId))];
    assert.deepEqual(groups.map(g => d.filter(q => q.groupId === g).length), [5, 5, 4, 4, 4], p.number);
    assert.equal(d.filter(q => q.type === 'TITA').length, 11, p.number);
    const tags = T.mockDilr[p.number].split(' ');
    assert.equal(tags.length, 5);
    if (p.number === '01') continue; // Paper 01 names its set types in words, not DI/LR prefixes.
    groups.forEach((g, i) => assert.equal(d.find(q => q.groupId === g).topic.slice(0, 2), tags[i], `${p.number} ${g}`));
  }
});

test('Every paper: 2 summary, 2 placement, 2 odd-sentence and 2 parajumble questions; 4 typed VARC answers', () => {
  for (const p of w.CAT_PAPER_CATALOG) {
    const va = papers[p.number].CAT2026_VARC.filter(q => !q.groupId);
    assert.equal(va.length, 8, p.number);
    assert.equal(va.filter(q => q.type === 'TITA').length, 4, p.number);
    const count = re => va.filter(q => re.test(q.topic)).length;
    assert.deepEqual([count(/summary/i), count(/placement|insertion|completion/i), count(/odd/i), count(/parajumble/i)], [2, 2, 2, 2], p.number);
    assert.ok(va.filter(q => /odd|parajumble/i.test(q.topic)).every(q => q.type === 'TITA'), p.number);
  }
});

console.log(JSON.stringify({status: 'passed', tests: results.length, results}, null, 2));
