/* Checks for the v4.0 diagnostics: damped trend, slot-noise floor, setter swing, VARC and DILR studies,
   plus invariants of the real dataset. Run with Node; no browser or network needed. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const context = {window:{}};
vm.createContext(context);
for (const file of ['forecast-engine.js','history-data.js']) vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, {filename:file});
const E = context.window.CATForecastEngine, H = context.window.CAT_HISTORY;
const plain = value => JSON.parse(JSON.stringify(value));
const row = (year, slot, qa = [8,6,3,2,3], extra = {}) => ({year, slot, qa:[...qa], source:`https://example.test/cat/${year}/${slot}`, ...extra});
const results = [];
function test(name, fn) {
  try { fn(); results.push({name, status:'passed'}); }
  catch (error) { results.push({name, status:'failed', error:error.stack || String(error)}); }
}
const close = (a, b, m = '') => assert.ok(Math.abs(a - b) <= 1e-9, `${m}: expected ${b}, received ${a}`);
const vector = (a, b, m = '') => { assert.equal(a.length, b.length, m); a.forEach((x, i) => close(x, b[i], `${m}[${i}]`)); };

test('damped trend carries half the fitted drift, full drift at damping 1', () => {
  const drift = [row(2021,1,[6,8,3,2,3]), row(2022,1,[7,7,3,2,3]), row(2023,1,[8,6,3,2,3])];
  vector(E.dampedTrend(drift, 2024, 'raw', 0.5), [8.5,5.5,3,2,3]);
  vector(E.dampedTrend(drift, 2024, 'raw', 1), [9,5,3,2,3]);
  vector(E.dampedTrend(drift, 2024, 'raw', 0), [8,6,3,2,3]);
});

test('damped trend needs three years, conserves 22 and never goes negative', () => {
  vector(E.dampedTrend([row(2021,1,[6,8,3,2,3]), row(2022,1,[7,7,3,2,3])], 2023), [7,7,3,2,3]);
  const steep = [row(2021,1,[10,4,3,2,3]), row(2022,1,[6,8,3,2,3]), row(2023,1,[2,12,3,2,3])];
  const p = E.dampedTrend(steep, 2025, 'raw', 1);
  assert.ok(p.every(x => x >= 0)); close(p[0], 0); close(p.reduce((a, b) => a + b, 0), 22);
  assert.throws(() => E.dampedTrend(steep, 2023), /strictly before/);
});

test('trend experiment cannot see target-year or later outcomes', () => {
  const rows = [row(2021,1), row(2022,1,[7,7,3,2,3]), row(2023,1,[8,6,3,2,3]), row(2024,1,[9,5,3,2,3]), row(2025,1,[7,7,3,2,3])];
  const a = E.trendExperiment(rows), b = E.trendExperiment(rows.map(r => r.year >= 2025 ? {...r, qa:[22,0,0,0,0]} : r));
  assert.deepEqual(plain(a.folds.slice(0, 3)), plain(b.folds.slice(0, 3)));
  assert.equal(a.targetYear, 2026); assert.equal(typeof a.beatsLastYear, 'boolean');
});

test('slot-noise floor uses only other slots of the same year and skips single-slot years', () => {
  const n = E.withinYearNoise([row(2021,1), row(2022,1,[8,6,3,2,3]), row(2022,2,[7,7,3,2,3])]);
  assert.equal(n.years.length, 1); close(n.mae, 0.4);
  close(E.withinYearNoise([row(2022,1), row(2022,2)]).mae, 0);
  assert.equal(E.withinYearNoise([row(2021,1)]).mae, null);
});

test('setter swing measures year-to-year movement and flags convening-IIM changes', () => {
  const rows = [row(2021,1,[8,6,3,2,3]), row(2022,1,[6,8,3,2,3])];
  const s = E.setterSwing(rows, 'raw', {2021:'A', 2022:'B'});
  vector(s.meanDelta, [2,2,0,0,0]); close(s.meanChurn, 2); assert.equal(s.allNewConvenor, true);
  assert.equal(E.setterSwing(rows, 'raw', {2021:'A', 2022:'A'}).transitions[0].newConvenor, false);
  assert.equal(E.setterSwing(rows).transitions[0].newConvenor, null);
  assert.equal(E.setterSwing([row(2021,1)]).meanChurn, null);
});

const va = (year, slot, v) => row(year, slot, [8,6,3,2,3], {varc:v});
test('VARC study validates rows, selects past-only and rounds the forecast to 8', () => {
  assert.throws(() => E.runVARCStudy([va(2021,1,[16,3,3,3,3])]));
  assert.throws(() => E.runVARCStudy([va(2021,1,[16,3,0,2])]));
  const rows = [va(2021,1,[16,3,0,2,3]), va(2022,1,[16,2,2,2,2]), va(2023,1,[16,2,2,2,2])];
  const s = E.runVARCStudy(rows);
  assert.deepEqual(plain(s.folds.map(f => f.selectedMethod)), ['last','uniform']);
  close(s.folds[0].methods.last.mae, 1); close(s.folds[0].methods.uniform.mae, 0);
  assert.equal(s.forecast.rounded.reduce((a, b) => a + b, 0), 8); assert.equal(s.forecast.targetYear, 2024);
  assert.deepEqual(plain(s.changes), {changed:1, transitions:2});
  const poisoned = E.runVARCStudy(rows.map(r => r.year === 2023 ? va(2023,1,[16,8,0,0,0]) : r));
  assert.deepEqual(plain(poisoned.folds[0]), plain(s.folds[0]));
  assert.equal(E.runVARCStudy([row(2021,1)]).forecast.prediction, null);
});

test('DILR study scores total and set sizes against the previous year only', () => {
  const d = (year, dilr) => row(year, 1, [8,6,3,2,3], {dilr});
  const s = E.runDILRStudy([d(2021,[6,6,4,4]), d(2022,[5,5,5,5]), d(2023,[5,5,4,4,4])]);
  assert.deepEqual(plain(s.folds.map(f => f.totalCorrect)), [1, 0]);
  assert.deepEqual(plain(s.folds.map(f => f.setSizeError)), [4, 6]);
  assert.deepEqual(plain(s.changes), {changed:2, transitions:2});
  assert.deepEqual(plain(s.forecast), {targetYear:2024, shape:[5,5,4,4,4], total:22});
  assert.throws(() => E.runDILRStudy([d(2021,[0,5])]));
  assert.equal(E.runDILRStudy([row(2021,1)]).forecast, null);
});

test('count distribution is a probability per family and the modal allocation conserves 22', () => {
  const rows = [row(2021,1,[8,6,3,2,3]), row(2022,1,[8,6,3,2,3]), row(2022,2,[7,7,3,2,3]), row(2023,1,[8,5,3,3,3])];
  for (const taxonomy of ['raw','broad']) {
    const dist = E.countDistribution(rows, taxonomy, 2);
    dist.forEach(d => { assert.equal(d.length, 23); close(d.reduce((a, b) => a + b, 0), 1); assert.ok(d.every(p => p >= 0)); });
    const m = E.modalAllocation(dist);
    assert.equal(m.allocation.reduce((a, b) => a + b, 0), 22); assert.equal(m.allocation.length, dist.length);
    assert.ok(m.expectedHits > 0 && m.expectedHits <= dist.length);
  }
  assert.deepEqual(plain(E.modalAllocation(E.countDistribution([row(2021,1), row(2022,1)], 'raw', 0)).allocation), [8,6,3,2,3]);
  const equal = E.countDistribution([row(2021,1,[8,6,3,2,3]), row(2022,1,[6,8,3,2,3])], 'raw', 0);
  close(equal[0][8], 0.5); close(equal[0][6], 0.5);
  const recent = E.countDistribution([row(2021,1,[8,6,3,2,3]), row(2023,1,[6,8,3,2,3])], 'raw', 2);
  assert.ok(recent[0][6] > recent[0][8], 'newer year must weigh more under decay');
  const tiny = E.modalAllocation([[0.2,0.8],[0.9,0.1]], 1);
  assert.deepEqual(plain(tiny.allocation), [1,0]); close(tiny.expectedHits, 1.7);
});

test('modal experiment scores only earlier years and compares with a rounded last-year baseline', () => {
  const rows = [row(2021,1), row(2022,1,[7,7,3,2,3]), row(2023,1,[8,6,3,2,3]), row(2024,1,[8,5,3,3,3]), row(2025,1,[8,6,3,2,3])];
  const a = E.modalExperiment(rows), b = E.modalExperiment(rows.map(r => r.year >= 2025 ? {...r, qa:[22,0,0,0,0]} : r));
  assert.deepEqual(plain(a.folds.slice(0, 3)), plain(b.folds.slice(0, 3)));
  assert.equal(a.folds.length, 4); assert.equal(a.forecast.targetYear, 2026);
  assert.equal(a.forecast.allocation.reduce((x, y) => x + y, 0), 22);
  assert.equal(typeof a.beatsRoundedLast, 'boolean');
  for (const f of a.folds) for (const k of ['modal','lastRounded','lastMean']) { assert.ok(f[k].mae >= 0); assert.ok(f[k].exactRate >= 0 && f[k].exactRate <= 1); }
  assert.equal(E.modalExperiment([row(2021,1)]).summary.modal.mae, null);
});

test('set layouts enumerate every multiset of allowed sizes and reject bad input', () => {
  assert.deepEqual(plain(E.setLayouts(22, [4,5])), [[5,5,4,4,4]]);
  assert.deepEqual(plain(E.setLayouts(20, [5,4])), [[5,5,5,5],[4,4,4,4,4]]);
  assert.deepEqual(plain(E.setLayouts(7, [4,5])), []);
  assert.deepEqual(plain(E.setLayouts(16, [4])), [[4,4,4,4]]);
  assert.throws(() => E.setLayouts(0, [4])); assert.throws(() => E.setLayouts(10, [0]));
});

test('mock backtest compares a mock with the same-year paper and with repeating last year', () => {
  const rows = [
    row(2024,1,[8,6,3,2,3],{varc:[16,3,3,2,0],sections:[24,22,22],dilr:[5,5,4,4,4]}),
    row(2025,1,[8,4,3,3,4],{varc:[16,2,2,2,2],sections:[24,22,22],dilr:[5,5,4,4,4],tita:[4,11,8]})];
  const mock = {sections:[24,22,22],varc:[16,3,3,2,0],tita:[2,10,8],dilrSets:[4,5,4,5,4],qa:[9,4,3,2,4],qaAlternative:[9,5,3,2,3]};
  const b = E.mockBacktest(rows, mock, 2025);
  assert.equal(b.priorYear, 2024); assert.equal(b.sectionsMatch, true); assert.equal(b.dilrLayoutMatch, true); assert.equal(b.lastYearDilrLayoutMatch, true);
  close(b.va.mockMAE, 1); close(b.va.lastYearMAE, 1); close(b.va.equalSplitMAE, 0);
  assert.deepEqual(plain(b.tita.difference), [-2,-1,0]); assert.equal(b.tita.totalDifference, -3);
  close(b.qa.raw.mock, 0.4); close(b.qa.raw.mockAlternative, 0.8); close(b.qa.raw.lastYear, 0.8);
  close(b.qa.broad.mock, 0.5); close(b.qa.broad.lastYear, 0.5);
  assert.equal(E.mockBacktest(rows, mock, 2030), null);
  assert.equal(E.mockBacktest([rows[1]], mock, 2025).qa.raw.lastYear, null);
});

test('TITA forecast repeats the latest reported year and widens the range with context rows', () => {
  const rows = [row(2024,1), row(2025,1,[8,4,3,3,4],{tita:[4,11,8]}), row(2025,2,[8,5,3,2,4],{tita:[4,11,8]})];
  const t = E.titaForecast(rows, [{year:2024,slot:1,tita:[2,10,8]}]);
  assert.equal(t.targetYear, 2026); assert.equal(t.basisYear, 2025); vector(t.bySection, [4,11,8]); assert.equal(t.total, 23);
  assert.deepEqual(plain(t.range), [20,23]); assert.deepEqual(plain(t.sectionRanges), [[2,4],[10,11],[8,8]]);
  assert.equal(E.titaForecast([row(2024,1)]), null);
});

test('official mocks: recorded counts are consistent and the 2026 mock repeats 2025', () => {
  const M = H.officialMocks, total = a => a.reduce((x, y) => x + y, 0);
  for (const year of [2025, 2026]) {
    const m = M[year];
    assert.deepEqual(plain(m.sections), [24,22,22]); assert.equal(m.minutesPerSection, 40);
    assert.equal(total(m.varc), 24); assert.equal(m.varc[0], 16); assert.equal(total(m.dilrSets), 22); assert.equal(total(m.qa), 22); assert.equal(total(m.qaAlternative), 22);
    assert.ok(m.dilrSets.every(s => m.rules.dilrSetSizes.includes(s)), 'every set must have four or five questions');
    assert.equal(total(m.dilrTitaBySet), m.tita[1]); assert.ok(m.dilrTitaBySet.every((t, i) => t <= m.dilrSets[i]));
    assert.ok(new URL(m.url).hostname.endsWith('digialm.com'));
  }
  assert.equal(M[2026].sameQuestionsAs, 2025);
  for (const k of ['varc','tita','qa','qaAlternative']) assert.deepEqual(plain(M[2026][k]), plain(M[2025][k]));
  assert.deepEqual(plain([...M[2026].dilrSets].sort()), plain([...M[2025].dilrSets].sort()));
  assert.deepEqual(plain(E.setLayouts(22, M[2026].rules.dilrSetSizes)), [[5,5,4,4,4]]);
  const b = E.mockBacktest(H.rows, M[2025], 2025);
  assert.equal(b.va.equalSplitMAE < b.va.mockMAE, true, 'the 2025 mock should not beat an equal split on Verbal Ability');
  assert.equal(b.tita.totalDifference, -3);
  assert.ok(b.qa.broad.mock >= b.qa.broad.lastYear, 'notes claim the mock did not beat repeating last year on merged groups');
  const t = E.titaForecast(H.rows, H.supplementaryTita);
  assert.deepEqual(plain(t.bySection), [4,11,8]); assert.deepEqual(plain(t.range), [20,23]);
});

test('real dataset: sums, chronology, source hosts, alternatives and convening IIMs', () => {
  E.validateRows(H.rows);
  const years = [...new Set(H.rows.map(r => r.year))].sort();
  assert.deepEqual(plain(years), [2021,2022,2023,2024,2025]);
  assert.ok(H.rows.every(r => new URL(r.source).hostname.endsWith('imsindia.com')), 'primary rows must stay IMS-only');
  for (const r of H.rows.filter(r => r.alternativeQA)) {
    assert.equal(r.alternativeQA.reduce((a, b) => a + b, 0), 22);
    assert.notDeepEqual(plain(r.alternativeQA), plain(r.qa)); assert.ok(r.alternativeSource.startsWith('https://'));
  }
  for (const r of H.rows.filter(r => r.varc)) assert.equal(r.varc.slice(1).reduce((a, b) => a + b, 0), 8);
  for (const y of years) assert.ok(H.convenors[y], `convening IIM missing for ${y}`);
  assert.equal(H.convenors[2026], 'IIM Indore');
  assert.ok(E.setterSwing(H.rows, 'raw', H.convenors).allNewConvenor, 'notes claim every 2021-2025 pair had a new convening IIM');
  for (const t of ['raw','broad']) {
    const trend = E.trendExperiment(H.rows, t), study = E.runStudy(H.rows, t);
    assert.equal(trend.folds.length, study.folds.length); close(trend.summary.last, study.summary.last.mae);
    close(trend.forecast.reduce((a, b) => a + b, 0), 22);
  }
  const v = E.runVARCStudy(H.rows), d = E.runDILRStudy(H.rows);
  assert.equal(v.rcAlways16, true); assert.equal(v.forecast.targetYear, 2026); assert.equal(d.forecast.targetYear, 2026);
});

const failed = results.filter(r => r.status === 'failed');
console.log(JSON.stringify({status:failed.length ? 'failed' : 'passed', tests:results.length, passed:results.length - failed.length, results}, null, 2));
if (failed.length) process.exitCode = 1;
