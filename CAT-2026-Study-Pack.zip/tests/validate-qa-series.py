"""Independently recompute all 198 answer keys in QA Papers 02–10."""
import json
import math
import re
from collections import Counter
from fractions import Fraction as F
from itertools import combinations, permutations, product
from math import comb, factorial
from pathlib import Path
import sympy as s

ROOT = Path(__file__).resolve().parent.parent
EXPECTED = {
    2:[8,6,3,2,3], 3:[7,7,3,2,3], 4:[9,6,3,2,2], 5:[8,6,3,3,2],
    6:[8,4,3,3,4], 7:[8,7,3,2,2], 8:[8,5,3,2,4], 9:[9,9,2,1,1], 10:[8,7,3,2,2]
}
FAMILIES = ['Arithmetic','Algebra','Geometry','Number Systems','Modern Math']
checks = json.loads(Path(__file__).with_name('qa-series-checks.json').read_text())
oracle = {entry['id']:entry['code'] for entry in checks}
assert len(oracle) == len(checks), 'Duplicate independent check IDs'
seen_questions = set()
verified = []
errors = []
for file in sorted((ROOT/'papers').glob('paper-*-qa.js')):
    number = int(file.name.split('-')[1])
    if number not in EXPECTED:
        continue
    try:
        match = re.search(r'window\.CAT2026_QA\s*=\s*(\[.*\])\s*;',file.read_text(),re.S)
        assert match, 'Missing JSON-compatible QA assignment'
        questions = json.loads(match.group(1))
        assert len(questions)==22
        topics = Counter(q['topic'] for q in questions)
        assert [topics[f] for f in FAMILIES] == EXPECTED[number], topics
        assert Counter(q['type'] for q in questions)=={'MCQ':14,'TITA':8}
        for i,q in enumerate(questions,1):
            key=f'P{number:02}Q{i:02}'
            assert q['id']==f'Q{i:02}' and q['section']=='QA'
            normalized=' '.join(q['question'].casefold().split())
            assert normalized not in seen_questions, f'Duplicate question: {key}'
            seen_questions.add(normalized)
            assert len(q['question'].split())>=8 and len(q['solution'].split())>=20, key
            assert key in oracle, f'Missing independent calculation: {key}'
            namespace={'F':F,'s':s,'x':s.symbols('x',real=True),'math':math,
                       'comb':comb,'factorial':factorial,'combinations':combinations,
                       'permutations':permutations,'product':product}
            exec(oracle[key],namespace)
            expected=s.Rational(str(namespace['result']))
            if q['type']=='MCQ':
                assert len(q['options'])==4 and len(set(q['options']))==4, key
                assert type(q['answer']) is int and 0<=q['answer']<4
                values=[s.Rational(option.replace(':','/')) for option in q['options']]
                assert len(set(values))==4, (key,'Mathematically duplicate options')
                assert sum(value==expected for value in values)==1, (key,'Non-unique correct option',expected)
                actual=values[q['answer']]
            else:
                assert q['options']==[] and re.fullmatch(r'-?\d+(\.\d+)?',q['answer'])
                actual=s.Rational(q['answer'])
            assert actual==expected, (key,'Key differs from independent calculation',actual,expected)
            verified.append(key)
    except Exception as error:
        errors.append({'file':file.name,'error':str(error)})
unused=sorted(set(oracle)-set(verified))
if not errors and (len(verified)!=198 or unused):
    errors.append({'scope':'final ten-paper edition','error':'Expected exactly 198 independently checked QA answers and no unused checks.'})
print(json.dumps({'status':'failed' if errors else 'passed','verifiedAnswers':len(verified),
                  'papers':sorted({int(key[1:3]) for key in verified}),
                  'errors':errors,'unverifiedCheckIds':unused},indent=2))
if errors:
    raise SystemExit(1)
