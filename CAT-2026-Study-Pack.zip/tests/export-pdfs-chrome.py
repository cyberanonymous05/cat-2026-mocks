"""Export question and solution PDFs for all ten papers with a locally installed Chrome.

This is the no-Playwright counterpart of tests/export-pdfs.py. It prints the
reader editions served by a local static server (default http://127.0.0.1:8765)
and writes tests/pdf-manifest.json with the same fields, so tests/export-pack.py
can verify that every PDF matches its current source files.

Usage: python3 -m http.server 8765 --bind 127.0.0.1   (in the project root)
       python3 tests/export-pdfs-chrome.py [--papers 1 2 ...] [--base URL] [--chrome PATH]
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
SHARED = ["prediction.html", "prediction.js", "prediction.css", "papers.css", "cbt.css", "paper-catalog.js", "paper-loader.js"]

parser = argparse.ArgumentParser(description="Export separate question and solution PDFs with headless Chrome.")
parser.add_argument("--papers", nargs="+", type=int, choices=range(1, 11), default=list(range(1, 11)))
parser.add_argument("--base", default="http://127.0.0.1:8765")
parser.add_argument("--chrome", default=DEFAULT_CHROME)
args = parser.parse_args()

manifest_path = ROOT / "tests" / "pdf-manifest.json"
previous = json.loads(manifest_path.read_text()) if manifest_path.exists() else []
manifest = {(e["paper"], e["edition"]): e for e in previous}
with tempfile.TemporaryDirectory(prefix="cat-pdf-profile-") as profile:
    for number in args.papers:
        label = f"{number:02}"
        for view, name in (("paper", f"CAT-2026-Prediction-Paper-{label}.pdf"), ("solutions", f"CAT-2026-Prediction-Solutions-{label}.pdf")):
            target = ROOT / name
            subprocess.run([args.chrome, "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
                            f"--user-data-dir={profile}", "--no-pdf-header-footer", "--run-all-compositor-stages-before-draw",
                            "--virtual-time-budget=15000", f"--print-to-pdf={target}",
                            f"{args.base}/prediction.html?paper={label}&view={view}"],
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=180)
            data = target.read_bytes()
            pages = len(re.findall(rb"/Type\s*/Page\b", data))
            assert data.startswith(b"%PDF-") and pages >= 12, (name, pages)
            inputs = SHARED + [f"prediction-{s}.js" if number == 1 else f"papers/paper-{label}-{s}.js" for s in ("varc", "dilr", "qa")]
            manifest[(label, view)] = {"paper": label, "edition": view, "file": name, "bytes": len(data), "pages": pages,
                                       "sha256": hashlib.sha256(data).hexdigest(),
                                       "inputs": {s: hashlib.sha256((ROOT / s).read_bytes()).hexdigest() for s in inputs}}
            print(name, len(data), "bytes", pages, "pages", flush=True)
ordered = [manifest[k] for k in sorted(manifest)]
manifest_path.write_text(json.dumps(ordered, indent=2) + "\n", encoding="utf-8")
