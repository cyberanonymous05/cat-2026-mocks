"""Build and CRC-check a fixed, portable whitelist of CAT study materials.

Only the filenames below are eligible. Arbitrary user files, test screenshots,
temporary files, and earlier ZIPs cannot be picked up by recursive traversal.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "CAT-2026-Study-Pack.zip"
PDF_OUTPUT = ROOT / "CAT-2026-Ten-Papers-PDFs.zip"
PDF_MEMBERS = tuple(
    f"CAT-2026-Prediction-{kind}-{number:02}.pdf"
    for number in range(1, 11) for kind in ("Paper", "Solutions")
)
MEMBERS = (
    "index.html", "prediction.html", "backtest.html", "validation.html", "topics.html",
    "styles.css", "prediction.css", "cbt.css", "backtest.css", "validation.css",
    "app.js", "evidence.js", "prediction.js", "prediction-varc.js",
    "prediction-dilr.js", "prediction-qa.js", "backtest.js", "backtest-data.js",
    "history-data.js", "forecast-engine.js", "validation.js", "topic-data.js", "topics.js",
    "research-2021-2022.json", "research-2023-2024.json",
    "CAT-2026-Forecast-Audit.json", "CAT-2021-2025-Topic-Data.csv",
    "CAT-2026-Research-Summary.md", "README.md",
    "papers.html", "papers.css", "papers.js", "paper-catalog.js", "paper-loader.js",
    "tests/export-audit.cjs", "tests/export-pack.py",
    "tests/validate-history.cjs", "tests/validate-model.cjs",
    "tests/browser-check.py", "tests/export-pdfs.py",
    "tests/browser-series.py", "tests/browser-storage.py", "tests/validate-series.cjs",
    "tests/validate-varc-series.cjs", "tests/validate-qa-series.py",
    "tests/qa-series-checks.json", "tests/validate-dilr-series.py",
    "tests/pdf-manifest.json", "tests/export-pdfs-chrome.py", "tests/validate-extensions.cjs", "tests/validate-topics.cjs",
    "tests/build-qa-06-10.py", "tests/dilr-series-06-10.py",
) + tuple(
    f"papers/paper-{number:02}-{section}.js"
    for number in range(2, 11) for section in ("varc", "dilr", "qa")
) + PDF_MEMBERS


def build_pack():
    assert len(set(MEMBERS)) == len(MEMBERS), "Duplicate whitelist member"
    assert OUTPUT.name not in MEMBERS, "The output ZIP must never include itself"
    assert PDF_OUTPUT.name not in MEMBERS, "The PDF bundle is added only after rebuilding it"
    for name in MEMBERS:
        relative = PurePosixPath(name)
        assert not relative.is_absolute() and ".." not in relative.parts
        source = ROOT / name
        if source.is_symlink() or not source.is_file() or source.stat().st_size == 0:
            raise ValueError(f"Missing, empty, or symlinked study-pack member: {name}")
        if ROOT not in source.resolve().parents:
            raise ValueError(f"Member resolves outside the project: {name}")
        if name.endswith(".pdf"):
            with source.open("rb") as document:
                if document.read(5) != b"%PDF-":
                    raise ValueError(f"Invalid PDF header: {name}")

    audit = json.loads((ROOT / "CAT-2026-Forecast-Audit.json").read_text(encoding="utf-8"))
    expected_hashes = audit["metadata"]["reproducibility"]["sha256"]
    for name in ("history-data.js", "forecast-engine.js"):
        actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        if actual != expected_hashes[name]:
            raise ValueError(f"Stale audit for {name}; run node tests/export-audit.cjs first")

    manifest = json.loads((ROOT / "tests/pdf-manifest.json").read_text(encoding="utf-8"))
    if len(manifest) != 20 or {entry["file"] for entry in manifest} != set(PDF_MEMBERS):
        raise ValueError("PDF manifest must contain exactly the twenty release PDFs")
    for entry in manifest:
        actual = hashlib.sha256((ROOT / entry["file"]).read_bytes()).hexdigest()
        if actual != entry["sha256"]:
            raise ValueError(f"Stale PDF manifest for {entry['file']}; export all ten papers")
        if not entry.get("inputs"):
            raise ValueError(f"Missing source hashes for {entry['file']}; export all ten papers")
        for name, expected in entry["inputs"].items():
            if name not in MEMBERS or hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
                raise ValueError(f"Stale PDF source {name} for {entry['file']}; export all ten papers")

    write_archive(PDF_OUTPUT, PDF_MEMBERS)
    write_archive(OUTPUT, MEMBERS + (PDF_OUTPUT.name,))


def write_archive(output, members):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".cat-study-pack-", suffix=".zip", dir=ROOT, delete=False) as handle:
            temporary = Path(handle.name)
        with ZipFile(temporary, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
            for name in members:
                archive.write(ROOT / name, arcname=name)
        with ZipFile(temporary, "r") as archive:
            if archive.namelist() != list(members):
                raise ValueError("ZIP membership differs from the exact whitelist")
            bad_member = archive.testzip()
            if bad_member is not None:
                raise ValueError(f"ZIP CRC failure: {bad_member}")
            for entry in archive.infolist():
                relative = PurePosixPath(entry.filename)
                if relative.is_absolute() or ".." in relative.parts or entry.is_dir():
                    raise ValueError(f"Unsafe archive path: {entry.filename}")
        os.replace(temporary, output)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)

    print(json.dumps({
        "status": "passed", "output": output.name, "files": len(members),
        "bytes": output.stat().st_size, "crc": "all members passed",
        "whitelist": list(members), "audit_input_hashes": "current",
    }, indent=2))


if __name__ == "__main__":
    build_pack()
