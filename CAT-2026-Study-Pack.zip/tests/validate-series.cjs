/* Structural, distinctness and coverage checks for all ten complete papers.
   Author-side mathematical solvers are separate: schema checks alone do not
   establish that a quantitative answer or a verbal inference is correct. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),availableOnly=process.argv.includes('--available');
const c={window:{}};vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(root,'paper-catalog.js'),'utf8'),c);
const catalog=JSON.parse(JSON.stringify(c.window.CAT_PAPER_CATALOG));
assert.equal(catalog.length,10);assert.equal(new Set(catalog.map(p=>p.storageKey)).size,10);
assert.equal(catalog[0].storageKey,'cat2026.prediction01.attempt.v3');
assert.equal(catalog[0].paperId,'CAT2026-P01-v3');
const fingerprints=new Set(),rcTexts=new Set(),setTexts=new Set(),qaStems=new Map(),result=[];
const normalize=s=>s.toLowerCase().replace(/\s+/g,' ').trim();
const digest=s=>crypto.createHash('sha256').update(s).digest('hex');
for(const paper of catalog){
  const missing=paper.files.filter(f=>!fs.existsSync(path.join(root,f)));
  if(missing.length){if(availableOnly){result.push({paper:paper.number,status:'not complete',missing});continue;}assert.fail('Missing files: '+missing.join(', '));}
  const ctx={window:{}};vm.createContext(ctx);
  for(const f of paper.files)vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f,timeout:5000});
  const bank=['VARC','DILR','QA'].flatMap(s=>ctx.window['CAT2026_'+s]);
  assert.equal(bank.length,68,paper.number);assert.equal(new Set(bank.map(q=>q.id)).size,68);
  for(const [section,length,mcq,prefix]of [['VARC',24,20,'V'],['DILR',22,11,'D'],['QA',22,14,'Q']]){
    const qs=bank.filter(q=>q.section===section);
    assert.equal(qs.length,length,`${paper.number} ${section}`);assert.equal(qs.filter(q=>q.type==='MCQ').length,mcq);
    qs.forEach((q,i)=>assert.equal(q.id,prefix+String(i+1).padStart(2,'0')));
  }
  for(const q of bank){
    const label=paper.number+'/'+q.id;
    assert.ok(typeof q.question==='string'&&q.question.trim().length>=3,label);
    assert.ok(typeof q.solution==='string'&&q.solution.trim().length>=80,label+' needs worked reasoning');
    assert.ok(typeof q.topic==='string'&&q.topic.trim(),label);
    assert.ok(['Easy','Moderate','Hard'].includes(q.difficulty),label+' difficulty');
    if(q.type==='MCQ'){
      assert.equal(q.options.length,4,label);assert.equal(new Set(q.options.map(normalize)).size,4,label+' options');
      assert.ok(q.options.every(o=>typeof o==='string'&&o.trim()),label);
      assert.ok(Number.isInteger(q.answer)&&q.answer>=0&&q.answer<4,label);
    }else{
      assert.equal(q.type,'TITA',label);assert.equal(q.options.length,0,label);
      assert.ok(typeof q.answer==='string'&&/^-?\d+$/.test(q.answer),label+' TITA answer must be a whole number (official mock rule)');
    }
    const fingerprint=digest([q.section,normalize(q.passage||''),normalize(q.question),...q.options.map(normalize).sort()].join('\n'));
    assert.ok(!fingerprints.has(fingerprint),'Repeated complete question '+label);fingerprints.add(fingerprint);
    if(q.section==='QA'){
      const stem=normalize(q.question).replace(/[\d.,]+/g,'#');
      const seen=qaStems.get(stem)||[];seen.push(label);qaStems.set(stem,seen);
    }
  }
  const rcWords=[];
  for(let i=1;i<=4;i++){
    const qs=bank.filter(q=>q.groupId==='RC'+i);assert.equal(qs.length,4);
    assert.ok(qs.every(q=>q.section==='VARC'&&q.passage===qs[0].passage&&q.groupTitle===qs[0].groupTitle));
    const text=normalize(qs[0].passage),words=text.split(/\s+/).length;assert.ok(words>=350&&words<=650,`${paper.number} RC${i} ${words} words`);
    assert.ok(!rcTexts.has(text),'Duplicate RC passage');rcTexts.add(text);rcWords.push(words);
  }
  for(let i=1;i<=5;i++){
    const qs=bank.filter(q=>q.groupId==='DL'+i);assert.equal(qs.length,[5,5,4,4,4][i-1],`${paper.number} DL${i}`);
    assert.ok(qs.every(q=>q.section==='DILR'&&q.passage===qs[0].passage&&q.groupTitle===qs[0].groupTitle));
    const text=normalize(qs[0].passage);assert.ok(text.length>=200,`${paper.number} DL${i} data too short`);
    assert.ok(!setTexts.has(text),'Duplicate DILR context');setTexts.add(text);
  }
  const families=['Arithmetic','Algebra','Geometry','Number Systems','Modern Math'];
  const counts=families.map(t=>bank.filter(q=>q.section==='QA'&&q.topic===t).length);
  assert.deepEqual(counts,paper.qa,`${paper.number} QA mix disagrees with catalog`);
  result.push({paper:paper.number,status:'complete',questions:bank.length,rcWords,qa:counts,mcqKeys:[0,1,2,3].map(n=>bank.filter(q=>q.type==='MCQ'&&q.answer===n).length)});
}
const completed=result.filter(r=>r.status==='complete').length;
if(!availableOnly){assert.equal(completed,10);assert.equal(fingerprints.size,680);assert.equal(rcTexts.size,40);assert.equal(setTexts.size,50);}
const similarQaStems=[...qaStems.values()].filter(a=>a.length>1);
console.log(JSON.stringify({status:completed===10?'passed':'partial check only',completedPapers:completed,uniqueQuestions:fingerprints.size,uniqueRC:rcTexts.size,uniqueDILRSets:setTexts.size,similarQaStemsToReview:similarQaStems,papers:result},null,2));
