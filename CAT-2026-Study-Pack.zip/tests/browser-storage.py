"""Bounded multi-tab regression: readers and stale editors must not lose answers.

Uses an isolated browser context; no existing user browser storage is touched.
Serve the site at 127.0.0.1:8000 before running this test.
"""
import json
from playwright.sync_api import sync_playwright

BASE = 'http://127.0.0.1:8000/prediction.html?paper=01'
KEY = 'cat2026.prediction01.attempt.v3'
BLOCK_STORAGE_EVENTS = """(() => {
  const add = window.addEventListener.bind(window);
  window.addEventListener = (type, listener, options) => {
    if (type !== 'storage') add(type, listener, options);
  };
})();"""


def open_page(context, view=None, block_events=False):
    page = context.new_page()
    if block_events:
        page.add_init_script(BLOCK_STORAGE_EVENTS)
    page.goto(BASE + (f'&view={view}' if view else ''), wait_until='networkidle')
    page.wait_for_function('window.CATPaper?.number === "01"')
    return page


def saved(page):
    return page.evaluate('(key) => JSON.parse(localStorage.getItem(key))', KEY)


def lifecycle(page):
    page.evaluate("""() => {
      document.dispatchEvent(new Event('visibilitychange'));
      window.dispatchEvent(new Event('pagehide'));
    }""")


with sync_playwright() as p:
    browser = p.chromium.launch(
        headless=True,
        executable_path='/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',
        args=['--no-sandbox'],
    )
    errors = []

    def context():
        ctx = browser.new_context()
        ctx.on('page', lambda page: page.on('pageerror', lambda error: errors.append(str(error))))
        return ctx

    # Deliberately suppress storage events in each reader: correctness must not
    # depend on receiving notifications before a tab closes or becomes hidden.
    ctx = context()
    active = open_page(ctx)
    active.locator('[data-action="practice"]').click()
    for i, view in enumerate(['solutions', 'paper', None]):
        reader = open_page(ctx, view, block_events=True)
        active.locator(f'[data-option="{i + 1}"]').click()
        before = saved(active)
        lifecycle(reader)
        assert saved(reader) == before, ('readonly lifecycle changed storage', view)
        if view is None:
            reader.locator('[data-action="reader"]').click()
            assert saved(reader) == before, 'stale home-to-reader transition wrote storage'
        reader.close()
        assert saved(active) == before, ('reader close lost progress', view)
    ctx.close()

    # Two editable tabs with notifications suppressed exercise the optimistic
    # snapshot check itself, rather than the ordinary storage-event handoff.
    ctx = context()
    first = open_page(ctx, block_events=True)
    first.locator('[data-action="practice"]').click()
    stale = open_page(ctx, block_events=True)
    stale.locator('[data-action="resume"]').click()
    first.locator('[data-option="2"]').click()
    first.locator('[data-action="next"]').click()  # a choice is saved only by Save & Next
    stale.locator('[data-action="next"]').click()
    assert saved(first)['answers'] == {'V01': 2}, 'stale navigation erased a newer answer'
    assert stale.locator('[data-action="resume"]').is_visible(), 'stale editor did not yield'
    stale.locator('[data-action="resume"]').click()
    stale.locator('[data-index="1"]').click()
    stale.locator('[data-option="0"]').click()
    stale.locator('[data-action="next"]').click()
    assert saved(stale)['answers'] == {'V01': 2, 'V02': 0}, 'resume failed to adopt saved answers'
    lifecycle(first)
    assert saved(stale)['answers'] == {'V01': 2, 'V02': 0}, 'stale active lifecycle erased progress'
    assert first.locator('[data-action="resume"]').is_visible()
    ctx.close()

    # Normal storage events refresh desks/readers without resaving, and yield
    # a competing active editor before it can overwrite the new response.
    ctx = context()
    first = open_page(ctx)
    first.locator('[data-action="practice"]').click()
    second = open_page(ctx)
    first.locator('[data-option="1"]').click()
    first.locator('[data-action="next"]').click()
    second.wait_for_function("document.querySelector('.resume-card')?.textContent.includes('1/68 answered')")
    second.locator('[data-action="resume"]').click()
    second.locator('[data-index="1"]').click()
    second.locator('[data-option="3"]').click()
    second.locator('[data-action="next"]').click()
    first.locator('[data-action="resume"]').wait_for(state='visible')
    assert saved(first)['answers'] == {'V01': 1, 'V02': 3}
    second.locator('[data-action="home"]').click()
    second.locator('[data-action="practice"]').click()
    assert second.locator('#confirmDialog').is_visible(), 'replacement needs explicit confirmation'
    second.locator('#acceptConfirm').click()
    replacement = saved(second)
    assert replacement['answers'] == {}
    assert replacement['paper'] == 'CAT2026-P01-v3'
    assert set(replacement) == {
        'paper', 'mode', 'stage', 'sectionIndex', 'current', 'answers', 'flags',
        'visited', 'times', 'startedAt', 'lastTouch', 'deadline',
    }, 'existing persisted schema changed'
    assert second.evaluate('CATPaper.storageKey') == KEY
    ctx.close()

    # Expiration while at the desk remains read-only until an explicit resume;
    # resuming must then persist the completed timed attempt correctly.
    ctx = context()
    timed = open_page(ctx)
    timed.clock.install()
    timed.locator('[data-action="exam"]').click()
    timed.locator('[data-action="home"]').click()
    timed.clock.fast_forward(120 * 60 * 1000 + 1000)
    assert saved(timed)['stage'] == 'active'
    timed.locator('[data-action="resume"]').click()
    assert timed.locator('.result-score').count() == 1
    assert saved(timed)['stage'] == 'complete'
    ctx.close()
    assert not errors, errors
    browser.close()
    print(json.dumps({
        'status': 'passed', 'readOnlyViews': ['solutions', 'paper', 'home'],
        'staleEditorRefused': True, 'storageEventHandoff': True,
        'confirmedReplacement': True, 'schemaCompatible': True,
        'timedDeskResume': True, 'pageErrors': errors,
    }, indent=2))
