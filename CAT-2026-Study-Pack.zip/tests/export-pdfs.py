"""Export separate questions and answers with the browser's print renderer."""
from pathlib import Path
import argparse
import hashlib
import json
import re
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser(description='Export separate question and solution PDFs for selected complete papers.')
parser.add_argument('--papers',nargs='+',type=int,choices=range(1,6),default=list(range(1,6)))
args=parser.parse_args()
manifest=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',args=['--no-sandbox'])
    page=browser.new_page()
    for number in args.papers:
        label=f'{number:02}'
        for view,name in [('paper',f'CAT-2026-Prediction-Paper-{label}.pdf'),('solutions',f'CAT-2026-Prediction-Solutions-{label}.pdf')]:
            page.goto(f'http://127.0.0.1:8000/prediction.html?paper={label}&view={view}',wait_until='networkidle')
            page.wait_for_function('(number)=>window.CATPaper?.number===number',arg=label)
            assert page.locator('.print-question').count()==68
            assert page.locator('.print-question .solution').count()==(68 if view=='solutions' else 0)
            assert f'Paper {label}' in page.locator('.paper-cover h1').inner_text()
            page.pdf(path=str(ROOT/name),format='A4',print_background=True,prefer_css_page_size=True,display_header_footer=True,
                     header_template='<div></div>',footer_template=f'<div style="font-size:8px;width:100%;margin:0 55px;color:#66706b;display:flex;justify-content:space-between"><span>CAT 2026 · Original practice · Paper {label}</span><span><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>')
            data=(ROOT/name).read_bytes()
            pages=len(re.findall(rb'/Type /Page\b',data))
            assert data.startswith(b'%PDF-') and pages>=12,(name,pages)
            inputs=['prediction.html','prediction.js','prediction.css','papers.css','paper-catalog.js','paper-loader.js']
            inputs += [f'prediction-{s}.js' if number==1 else f'papers/paper-{label}-{s}.js' for s in ['varc','dilr','qa']]
            manifest.append({'paper':label,'edition':view,'file':name,'bytes':len(data),'pages':pages,'sha256':hashlib.sha256(data).hexdigest(),
                             'inputs':{source:hashlib.sha256((ROOT/source).read_bytes()).hexdigest() for source in inputs}})
            print(name,len(data),'bytes',pages,'pages',flush=True)
    browser.close()
(ROOT/'tests'/'pdf-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
