"""Original DILR sets for Papers 06-10, solved by finite enumeration.

Every set is solved from its stated conditions before any key is written; the
assertions fail if a requested answer is not unique. `--emit NN` prints one
paper's question array; `--write` regenerates papers/paper-NN-dilr.js; plain
execution recomputes every saved file and compares it with the solver output.
Layout per paper: sets of 5, 5, 4, 4 and 4 questions, 11 TITA and 11 MCQ, the
only layout allowed by the official mock's rule of four or five questions per set.
"""
from collections import Counter
from itertools import combinations, permutations, product
import argparse
import heapq
import json
from pathlib import Path
import random
import re

ROOT = Path(__file__).resolve().parent.parent
BANK = {}
PROOFS = []
PATTERNS = (("TITA", "MCQ", "TITA", "MCQ", "MCQ"),
            ("TITA", "MCQ", "TITA", "TITA", "MCQ"),
            ("TITA", "MCQ", "TITA", "MCQ"))


def unique(values):
    values = set(values)
    assert len(values) == 1, f"Not a unique requested answer: {values}"
    return next(iter(values))


def table(headers, rows):
    return " | ".join(map(str, headers)) + "\n" + "\n".join(" | ".join(map(str, row)) for row in rows)


def item(question, answer, explanation, wrong=()):
    return question, answer, explanation, list(wrong)


def add(paper, group, title, topic, passage, working, items, examined, feasible, hard=False):
    pattern = PATTERNS[group - 1] if group <= 2 else PATTERNS[2]
    assert len(items) == len(pattern), (paper, group, len(items))
    questions = BANK.setdefault(paper, [])
    for (question, answer, explanation, wrong), kind in zip(items, pattern):
        qid = len(questions) + 1
        answer_text = str(answer)
        if kind == "TITA":
            assert re.fullmatch(r"\d+", answer_text), (paper, group, answer)
            options, key = [], answer_text
        else:
            if not wrong:
                assert isinstance(answer, int)
                wrong = [answer + 1, answer + 2, answer + 4]
            options = [answer_text] + list(map(str, wrong))
            assert len(options) == len(set(options)) == 4, (paper, group, options)
            random.Random(52361 + 911 * paper + 73 * qid).shuffle(options)
            key = options.index(answer_text)
        questions.append({
            "id": f"D{qid:02}", "section": "DILR", "topic": topic,
            "difficulty": "Hard" if hard else "Moderate", "type": kind,
            "groupId": f"DL{group}", "groupTitle": title,
            "passage": passage + "\n\nAny additional condition or change in a question applies only to that question.",
            "question": question, "options": options, "answer": key,
            "solution": working + "\n\n" + explanation
        })
    PROOFS.append({"paper": paper, "set": group, "title": title,
                   "candidateSpaceChecked": examined, "feasibleCases": feasible,
                   "questions": len(items)})


def shortest(edges, start, closed=()):
    graph = {}
    for a, b, w in edges:
        if (a, b) in closed or (b, a) in closed:
            continue
        graph.setdefault(a, []).append((b, w))
        graph.setdefault(b, []).append((a, w))
    dist, heap = {start: 0}, [(0, start)]
    while heap:
        d, node = heapq.heappop(heap)
        if d > dist[node]:
            continue
        for nxt, w in graph.get(node, []):
            if d + w < dist.get(nxt, 10**9):
                dist[nxt] = d + w
                heapq.heappush(heap, (d + w, nxt))
    return dist


def count_paths(edges, start, goal):
    dist = shortest(edges, start)
    best = dist[goal]
    graph = {}
    for a, b, w in edges:
        graph.setdefault(a, []).append((b, w))
        graph.setdefault(b, []).append((a, w))
    ways = {start: 1}
    for node in sorted(dist, key=dist.get):
        for nxt, w in graph.get(node, []):
            if dist[node] + w == dist.get(nxt):
                ways[nxt] = ways.get(nxt, 0) + ways.get(node, 0)
    return best, ways[goal]


def batch_06():
    # 06/1: linear arrangement with ten feasible orders.
    orders = []
    for perm in permutations("ABCDEFG"):
        p = {c: i + 1 for i, c in enumerate(perm)}
        if p["A"] in (1, 7) and p["B"] == p["C"] + 1 and p["E"] == p["D"] + 3 and p["G"] % 2 == 0 and p["F"] != 4:
            orders.append("".join(perm))
    assert len(orders) == 10
    second = Counter(o[1] for o in orders)
    top_second = max(second, key=second.get)
    assert list(second.values()).count(second[top_second]) == 1
    g_when_c6 = unique(o.index("G") + 1 for o in orders if o.index("C") == 5)
    last_when_d1 = unique(o[6] for o in orders if o[0] == "D")
    b_next_a = sum(1 for o in orders if abs(o.index("A") - o.index("B")) == 1)
    work = "Place C and B as a block, then D and E three places apart, and keep A at an end, G in an even place and F out of place 4. Exhaustive checking leaves exactly ten orders (positions 1 to 7, left to right):\n" + "\n".join(orders)
    add(6, 1, "Parcels on a shelf", "LR · linear arrangement",
        "Seven parcels A, B, C, D, E, F and G are placed in a single row in positions 1 to 7 from left to right, one parcel per position.\nA is at one end of the row.\nB is immediately to the right of C.\nE is to the right of D, with exactly two parcels between them.\nG is in an even-numbered position.\nF is not in position 4.", work, [
        item("How many different arrangements satisfy all the conditions?", len(orders), "Counting the listed orders gives 10."),
        item("Which parcel occupies position 2 in the largest number of possible arrangements?", top_second,
             "Across the ten orders position 2 holds G four times, D three times, C twice and B once.", [x for x in "DCB"]),
        item("If C is in position 6, what is the position number of G?", g_when_c6, "Only ADFGECB has C in position 6, and G is in position 4 there."),
        item("If D is in position 1, which parcel is in position 7?", last_when_d1,
             "The orders starting with D are DCBEFGA and DGFECBA; both end with A.", ["B", "E", "F"]),
        item("In how many of the possible arrangements is B next to A?", b_next_a,
             "Only DGFECBA places B immediately beside A.")
    ], 5040, len(orders))

    # 06/2: a complete data table with percentage changes.
    museums = ["Aster", "Birch", "Cedar", "Delta"]
    jan = [40, 55, 32, 48]
    change = [25, -20, 50, 12.5]
    child_share = [30, 25, 25, None]
    feb = [jan[i] * (100 + change[i]) / 100 for i in range(4)]
    feb_children = [feb[0] * 0.30, feb[1] * 0.25, feb[2] * 0.25, feb[3] / 3]
    assert all(float(x).is_integer() for x in feb + feb_children)
    total_feb = int(sum(feb))
    top_children = museums[max(range(4), key=lambda i: feb_children[i])]
    adults = int(total_feb - sum(feb_children))
    march = [feb[i] * (100 + change[i]) / 100 for i in range(4)]
    top_march = museums[max(range(4), key=lambda i: march[i])]
    overall = (sum(feb) - sum(jan)) / sum(jan) * 100
    assert overall == 12
    birch_gap = int(feb[1] - 2 * feb_children[1])
    rows = [(museums[i], jan[i], f"{change[i]:+g}%", "one third" if child_share[i] is None else f"{child_share[i]}%") for i in range(4)]
    work = "February visitors (thousands) = January × (1 + change). Children = February visitors × share.\n" + table(["Museum", "Feb visitors", "Feb children", "Mar visitors at same change"], [(museums[i], int(feb[i]), int(feb_children[i]), march[i]) for i in range(4)])
    add(6, 2, "Footfall at four museums", "DI · percentage change and shares",
        "The table gives January visitors (in thousands) at four city museums, the percentage change in visitors from January to February, and the share of February visitors who were children.\n\n" + table(["Museum", "January visitors (thousands)", "Change, Jan to Feb", "Children among Feb visitors"], rows), work, [
        item("What was the total number of February visitors, in thousands, across the four museums?", total_feb, "50 + 44 + 48 + 54 = 196 thousand."),
        item("Which museum had the most child visitors in February?", top_children,
             "Child visitors were 15, 11, 12 and 18 thousand respectively; Delta is highest.", ["Aster", "Birch", "Cedar"]),
        item("What was the total number of adult visitors, in thousands, across the four museums in February?", adults,
             "Children total 15 + 11 + 12 + 18 = 56 thousand, so adults number 196 − 56 = 140 thousand."),
        item("In February, by how many thousand did adult visitors at Birch exceed child visitors at Birch?", birch_gap,
             "Birch had 44 thousand February visitors, of whom a quarter (11 thousand) were children and 33 thousand adults: a gap of 22 thousand."),
        item("If each museum's visitors changed from February to March by the same percentage as from January to February, which museum would have the most visitors in March?", top_march,
             "March visitors would be 62.5, 35.2, 72 and 60.75 thousand; Cedar is highest.", ["Aster", "Birch", "Delta"])
    ], "Direct table computation", 1)

    # 06/3: round-robin with points, draws and one fixed draw.
    players, games = "ABCDE", list(combinations("ABCDE", 2))
    points = {"A": 6, "B": 5, "C": 4, "D": 3, "E": 2}
    tables = []
    for outcome in product((0, 1, 2), repeat=10):
        score, wins, losses, draws = Counter(), Counter(), Counter(), 0
        for (a, b), o in zip(games, outcome):
            if o == 0:
                score[a] += 2; wins[a] += 1; losses[b] += 1
            elif o == 2:
                score[b] += 2; wins[b] += 1; losses[a] += 1
            else:
                score[a] += 1; score[b] += 1; draws += 1
        if all(score[p] == points[p] for p in players) and draws == 3 and losses["A"] == 0 and wins["E"] == 1 and outcome[games.index(("B", "C"))] == 1:
            tables.append({g: o for g, o in zip(games, outcome)})
    assert len(tables) == 2
    def won(t, p):
        return sum(1 for (a, b), o in t.items() if (o == 0 and a == p) or (o == 2 and b == p))
    b_wins = unique(won(t, "B") for t in tables)
    d_wins = unique(won(t, "D") for t in tables)
    e_beat = unique(next((a if b == "E" else b) for (a, b), o in t.items() if "E" in (a, b) and ((o == 2 and b == "E") or (o == 0 and a == "E"))) for t in tables if t[("C", "D")] == 0)
    certain = [g for g in games if len({t[g] for t in tables}) == 1]
    assert ("A", "E") in certain and tables[0][("A", "E")] == 0
    assert ("C", "D") not in certain and ("C", "E") not in certain and ("D", "E") not in certain
    def show(t):
        return ", ".join(f"{a}{'>' if o == 0 else '=' if o == 1 else '<'}{b}" for (a, b), o in t.items())
    work = "A has 6 points from 4 games with no loss, so A has 2 wins and 2 draws. With only 3 draws in all and B–C drawn, A's two draws are the other two. Checking all 3^10 result tables leaves two:\n" + "\n".join(show(t) for t in tables) + "\n(X>Y means X won; X=Y a draw.)"
    add(6, 3, "Round-robin chess", "LR · tournament points",
        "Five players A, B, C, D and E played a chess tournament in which every player met every other player exactly once. A win earned 2 points, a draw 1 point and a loss 0 points. Final points: A 6, B 5, C 4, D 3 and E 2.\nExactly three games were drawn, one of them between B and C.\nA did not lose any game.\nE won exactly one game.", work, [
        item("How many games did B win?", b_wins, "In both possible tables B beat D and E, lost to A and drew with C: 2 wins."),
        item("If C defeated D, whom did E defeat?", e_beat, "C beating D leaves only the first table, in which E beat C.", ["D", "A", "B"]),
        item("How many games did D win?", d_wins, "D has 3 points with one draw (against A) in both tables, so D won exactly one game."),
        item("Which of the following results is certain?", "A defeated E",
             "Only the A–E result is the same in both tables among the options; the others hold in just one table.", ["C defeated D", "E defeated C", "D defeated E"])
    ], 3 ** 10, len(tables), True)

    # 06/4: three-language Venn with two feasible splits.
    venn = []
    for t in range(0, 25):
        for x in range(0, 15):
            for y in range(0, 15):
                z = 14 - x - y
                if z < 0:
                    continue
                a, b, c = 32 - x - z - t, 27 - x - y - t, 23 - y - z - t
                if min(a, b, c) < 0 or a + b + c + x + y + z + t != 60:
                    continue
                if x == y and a > b > c:
                    venn.append(dict(a=a, b=b, c=c, x=x, y=y, z=z, t=t))
    assert len(venn) == 2
    all_three = unique(v["t"] for v in venn)
    exactly_one = unique(v["a"] + v["b"] + v["c"] for v in venn)
    fj_if_c9 = unique(v["z"] for v in venn if v["c"] == 9)
    max_gj = max(v["y"] for v in venn)
    work = "Let F only = a, G only = b, J only = c, F and G only = x, G and J only = y, F and J only = z and all three = t. Totals give a + x + z + t = 32, b + x + y + t = 27, c + y + z + t = 23 and x + y + z = 14 with 60 members in all. Adding the three language totals: 82 = (a + b + c) + 2 × 14 + 3t, while 60 = (a + b + c) + 14 + t, so t = 4. With x = y the conditions a > b > c leave:\n" + table(["F only", "G only", "J only", "FG only", "GJ only", "FJ only", "All three"], [(v["a"], v["b"], v["c"], v["x"], v["y"], v["z"], v["t"]) for v in venn])
    add(6, 4, "A three-language club", "DI · three-set overlap",
        "A language club has 60 members, and each member studies at least one of French, German and Japanese. 32 members study French, 27 study German and 23 study Japanese. Exactly 14 members study exactly two of the languages.\nThe number studying French and German but not Japanese equals the number studying German and Japanese but not French.\nMore members study only French than only German, and more study only German than only Japanese.", work, [
        item("How many members study all three languages?", all_three, "Comparing the two totals forces t = 4."),
        item("How many members study exactly one language?", exactly_one, "60 − 14 − 4 = 42 in either case."),
        item("If 9 members study only Japanese, how many study French and Japanese but not German?", fj_if_c9, "Only the first split has 9 Japanese-only members; there FJ-only is 6."),
        item("What is the largest possible number of members who study German and Japanese but not French?", max_gj, "The two feasible splits give 4 and 5; the largest is 5.")
    ], "All integer splits with x + y + z = 14", len(venn))

    # 06/5: shortest delivery routes on a road network.
    edges = [("P", "Q", 7), ("P", "R", 9), ("P", "S", 11), ("Q", "R", 10), ("Q", "T", 15), ("R", "S", 2),
             ("R", "T", 11), ("S", "U", 9), ("T", "U", 6), ("T", "V", 8), ("U", "V", 5)]
    best, ways = count_paths(edges, "P", "V")
    closed_rs = shortest(edges, "P", closed={("R", "S")})["V"]
    via_t = shortest(edges, "P")["T"] + shortest(edges, "T")["V"]
    assert (best, ways) == (25, 2)
    work = "Compute shortest times from P (Dijkstra’s method):\n" + table(["Hub", "Q", "R", "S", "T", "U", "V"], [["Minutes from P"] + [shortest(edges, "P")[h] for h in "QRSTUV"]]) + "\nTwo routes reach V in 25 minutes: P–S–U–V (11 + 9 + 5) and P–R–S–U–V (9 + 2 + 9 + 5)."
    add(6, 5, "Delivery routes", "LR · network shortest paths",
        "A courier van starts at depot P and serves hubs Q, R, S, T, U and V. The only roads are the two-way roads below, with travel times in minutes. Time spent at hubs is ignored.\n\n" + table(["Road", "Minutes"], [(f"{a}–{b}", w) for a, b, w in edges]), work, [
        item("What is the minimum travel time, in minutes, from P to V?", best, "The shortest routes take 25 minutes."),
        item("If road R–S is closed, what is the minimum travel time, in minutes, from P to V?", closed_rs,
             "P–S–U–V still takes 11 + 9 + 5 = 25 minutes, so the minimum is unchanged."),
        item("A van must travel from P to V passing through T. What is its minimum travel time, in minutes?", via_t,
             "P to T takes at least 20 minutes (P–R–T) and T to V at least 8, so 28 minutes."),
        item("How many different routes from P to V, visiting no hub twice, take the minimum time?", ways,
             "P–S–U–V and P–R–S–U–V both take 25 minutes; no other route does.")
    ], "All simple routes on 7 hubs", ways)


def batch_07():
    # 07/1: circular seating, A fixed at seat 1 to remove rotations.
    seats = []
    for tail in permutations("BCDEFGH"):
        order = "A" + "".join(tail)
        p = {c: i for i, c in enumerate(order)}
        if (p["B"] - p["A"]) % 8 == 4 and (p["C"] - p["B"]) % 8 == 1 and (p["D"] - p["E"]) % 8 in (1, 7) \
                and (p["F"] - p["A"]) % 8 not in (1, 7) and (p["G"] - p["D"]) % 8 == 2 and (p["H"] - p["B"]) % 8 not in (1, 7):
            seats.append(order)
    assert len(seats) == 2
    adjacent = lambda o, x, y: (o.index(x) - o.index(y)) % 8 in (1, 7)
    always = [pair for pair in (("A", "D"), ("E", "F"), ("G", "H"), ("C", "G")) if all(adjacent(o, *pair) for o in seats)]
    assert always == [("A", "D")]
    between = unique((o.index("C") - o.index("A")) % 8 - 1 for o in seats)
    opp_g = unique(o[(o.index("G") + 4) % 8] for o in seats if (o.index("E") - o.index("D")) % 8 == 1)
    after_a = unique(o[1] for o in seats if (o.index("F") - o.index("D")) % 8 == 4)
    work = "Number the seats 1 to 8 clockwise with A in seat 1. B is in seat 5 (opposite A) and C in seat 6. G is two seats clockwise from D, D and E are neighbours, and F and H avoid the stated neighbours. Exhaustive placement leaves two seatings (seats 1 to 8, clockwise):\n" + "\n".join(seats)
    add(7, 1, "Eight friends at a round table", "LR · circular arrangement",
        "Eight friends A, B, C, D, E, F, G and H sit around a circular table at eight equally spaced seats, all facing the centre.\nB sits directly opposite A.\nC sits immediately clockwise of B.\nD and E sit next to each other.\nF does not sit next to A, and H does not sit next to B.\nG sits two seats clockwise of D, with exactly one person between them.", work, [
        item("How many different seating arrangements satisfy all the conditions? (Arrangements that are rotations of each other count as the same.)", len(seats), "Fixing A removes rotations; the two listed seatings remain."),
        item("Which of the following pairs sit next to each other in every possible arrangement?", "A and D",
             "A and D are neighbours in both seatings; the other pairs are neighbours in at most one.", ["E and F", "G and H", "C and G"]),
        item("Counting clockwise from A, how many people sit strictly between A and C?", between, "C is always in seat 6, so seats 2 to 5 hold four people."),
        item("If E sits immediately clockwise of D, who sits opposite G?", opp_g, "Only ADEGBCFH has E immediately clockwise of D; G is in seat 4 and H is opposite.", ["F", "E", "C"]),
        item("If F sits opposite D, who sits immediately clockwise of A?", after_a, "Only AGHFBCED has F opposite D; there G is next clockwise from A.", ["D", "H", "E"])
    ], 5040, len(seats))

    # 07/2: plant output with one derived row.
    plants = ["K", "L", "M", "N"]
    k = (2100 - 400 - 400) / 3.25
    assert k == 400
    output = [400, 500, 400, 800]
    assert output[1] == 1.25 * output[0] and output[3] == output[0] + output[2] and sum(output) == 2100
    rate = [5, 4, 7.5, 2.5]
    defects = [output[i] * rate[i] / 100 for i in range(4)]
    assert all(float(d).is_integer() for d in defects)
    worst = plants[max(range(4), key=lambda i: defects[i])]
    assert sorted(defects)[-1] > sorted(defects)[-2]
    good = int(sum(output) - sum(defects))
    rework = int(sum(defects) * 15)
    work = "K produced k units, L 1.25k, M 400 and N k + 400. The total gives 3.25k + 800 = 2100, so k = 400.\n" + table(["Plant", "Output", "Defect rate", "Defective units"], [(plants[i], output[i], f"{rate[i]}%", int(defects[i])) for i in range(4)])
    add(7, 2, "Output and defects at four plants", "DI · derived values and rates",
        "Four plants K, L, M and N together produced 2,100 units last month. Plant M produced 400 units. L produced 25% more units than K, and N produced as many units as K and M together.\nThe defect rates were 5% at K, 4% at L, 7.5% at M and 2.5% at N (defect rate = defective units as a percentage of the plant's output).", work, [
        item("How many units did plant N produce?", output[3], "N = k + 400 = 800 units."),
        item("Which plant produced the largest number of defective units?", worst, "Defective units were 20, 20, 30 and 20; M is highest.", ["K", "L", "N"]),
        item("How many non-defective units did the four plants produce in all?", good, "Defective units total 90, so 2100 − 90 = 2010 were non-defective."),
        item("Each defective unit is reworked at a cost of ₹15. What is the total rework cost, in rupees?", rework, "90 defective units × ₹15 = ₹1,350."),
        item("Which of the following is closest to the overall defect rate of the four plants together?", "4.3%",
             "Overall the rate is 90/2100 = 4.29%, which rounds to 4.3%.", ["4.0%", "4.6%", "3.8%"])
    ], "Linear equation for k, then direct computation", 1)

    # 07/3: project network with precedence.
    tasks = {"A": (3, []), "B": (5, []), "C": (2, ["A"]), "D": (4, ["A", "B"]), "E": (6, ["C"]), "F": (3, ["D", "E"])}
    def finish_times(spec):
        done = {}
        for name in "ABCDEF":
            start = max([done[p] for p in spec[name][1]], default=0)
            done[name] = start + spec[name][0]
        return done
    base = finish_times(tasks)
    duration = max(base.values())
    def with_change(name, days):
        changed = dict(tasks); changed[name] = (days, tasks[name][1])
        return max(finish_times(changed).values())
    slack = {t: max(d for d in range(0, 10) if with_change(t, tasks[t][0] + d) == duration) for t in tasks}
    can_delay_two = [t for t in "BACE" if slack[t] >= 2]
    assert can_delay_two == ["B"]
    longer_e = with_change("E", 8)
    shortened = [t for t in "BDE" if with_change(t, tasks[t][0] - 1) == duration - 1]
    assert shortened == ["E"]
    work = "Earliest finish times, taking each task as soon as all its predecessors finish:\n" + table(["Task", "Days", "Needs", "Earliest finish", "Spare days"], [(t, tasks[t][0], ", ".join(tasks[t][1]) or "—", base[t], slack[t]) for t in "ABCDEF"]) + f"\nThe longest chain A–C–E–F takes {duration} days. Spare days are the most a single task can slip without delaying completion."
    add(7, 3, "Six tasks of a project", "LR · scheduling with precedence",
        "A project consists of six tasks. Each task can start only after all the tasks it needs have finished; tasks that do not depend on each other can run at the same time, and enough staff are available for this.\n\n" + table(["Task", "Duration (days)", "Can start only after"], [(t, tasks[t][0], ", ".join(tasks[t][1]) or "—") for t in "ABCDEF"]), work, [
        item("What is the minimum number of days needed to complete the project?", duration, "The chain A–C–E–F takes 3 + 2 + 6 + 3 = 14 days."),
        item("Which of the following tasks can be delayed by 2 days without delaying the completion of the project?", "B",
             "B finishes on day 5 but D need not start until day 7, so B has 2 spare days. A, C and E lie on the longest chain.", ["A", "C", "E"]),
        item("If task E takes 8 days instead of 6, what is the minimum number of days needed for the project?", longer_e, "The chain A–C–E–F becomes 3 + 2 + 8 + 3 = 16 days."),
        item("Shortening which one of the following tasks by one day shortens the whole project by one day?", "E",
             "Only E lies on the longest chain among the options; B and D have spare days.", ["B", "D", "None of these tasks"])
    ], "Earliest-finish recursion for each variant", 1)

    # 07/4: coins in five boxes.
    boxes = []
    for P, Q, R, S, T in product(range(2, 20), repeat=5):
        values = (P, Q, R, S, T)
        if sum(values) == 36 and len(set(values)) == 5 and P > Q and R == 2 * T and S % 2 == 1 and Q + T == 9 and P < R and 4 not in values:
            boxes.append(values)
    assert len(boxes) == 4
    max_s = max(b[3] for b in boxes)
    second = unique("PQRST"[sorted(range(5), key=lambda i: -b[i])[1]] for b in boxes)
    p_if = unique(b[0] for b in boxes if b[3] > b[4])
    work = "R = 2T and Q + T = 9, with every box holding a different number of at least 2 coins and no box holding exactly 4. Checking all cases leaves:\n" + table(["P", "Q", "R", "S", "T"], boxes)
    add(7, 4, "Coins in five boxes", "LR · distribution with constraints",
        "Five boxes P, Q, R, S and T together contain 36 coins. Each box contains at least 2 coins, no two boxes contain the same number of coins, and no box contains exactly 4 coins.\nP contains more coins than Q but fewer than R.\nR contains twice as many coins as T.\nS contains an odd number of coins.\nQ and T together contain 9 coins.", work, [
        item("What is the largest possible number of coins in box S?", max_s, "The feasible values of S are 5, 7, 3 and 5; the largest is 7."),
        item("Which box always contains the second-highest number of coins?", second, "R is always highest and P is second in every feasible distribution.", ["S", "T", "Q"]),
        item("If S contains more coins than T, how many coins does P contain?", p_if, "Only (8, 3, 12, 7, 6) has S above T, so P holds 8 coins."),
        item("How many different distributions of coins satisfy all the conditions?", len(boxes), "Four distributions remain.")
    ], 18 ** 5, len(boxes))

    # 07/5: truth-tellers and liars.
    worlds = []
    for kinds in product((True, False), repeat=5):
        A, B, C, D, E = kinds
        said = {"A": not B, "B": C == D, "C": kinds.count(False) == 2, "D": A, "E": not D}
        if all(said[n] == k for n, k in zip("ABCDE", kinds)):
            worlds.append(dict(zip("ABCDE", kinds)))
    assert len(worlds) == 2
    liars = unique(sum(not v for v in w.values()) for w in worlds)
    sure_liar = [n for n in "ABCDE" if all(not w[n] for w in worlds)]
    assert sure_liar == ["C"]
    truthful_bce = unique(sum(w[n] for n in "BCE") for w in worlds if w["A"])
    world_e = [w for w in worlds if w["E"]]
    assert len(world_e) == 1 and world_e[0]["B"] and not world_e[0]["A"] and not world_e[0]["D"]
    show = lambda w: ", ".join(f"{n} {'truth-teller' if v else 'liar'}" for n, v in w.items())
    work = "Test all 32 assignments: a truth-teller's statement must be true and a liar's false. Two assignments survive:\n" + "\n".join(show(w) for w in worlds) + "\nC's claim that exactly two are liars is false in both, since each has three liars."
    add(7, 5, "Truth-tellers and liars", "LR · consistency of statements",
        "Each of five people A, B, C, D and E is either a truth-teller, who always tells the truth, or a liar, who always lies. They make these statements:\nA: “B is a liar.”\nB: “C and D are of the same type.”\nC: “Exactly two of us five are liars.”\nD: “A is a truth-teller.”\nE: “D is a liar.”", work, [
        item("How many of the five are liars?", liars, "Both consistent assignments have exactly three liars."),
        item("Who is certainly a liar?", "C", "C is a liar in both assignments; each of the others is a truth-teller in one of them.", ["A", "B", "D"]),
        item("If A is a truth-teller, how many of B, C and E are truth-tellers?", truthful_bce, "With A truthful, B, C and E are all liars, so the answer is 0."),
        item("If E is a truth-teller, which of the following must be true?", "B is a truth-teller",
             "E truthful leaves only the assignment in which A, C and D lie and B and E tell the truth.", ["A is a truth-teller", "D is a truth-teller", "C is a truth-teller"])
    ], 32, len(worlds))


def batch_08():
    # 08/1: test scores with three cells recovered from averages and totals.
    names = ["U", "V", "W", "X", "Y", "Z"]
    t1 = [42, 35, None, 30, 47, 38]; t2 = [38, None, 41, 36, 29, 45]; t3 = [None, 44, 39, 33, 40, None]
    t1[2] = 6 * 39 - sum(v for v in t1 if v is not None)
    t2[1] = 6 * 38 - sum(v for v in t2 if v is not None)
    t3[0] = 120 - t1[0] - t2[0]
    t3[5] = t1[5]
    totals = [t1[i] + t2[i] + t3[i] for i in range(6)]
    top = names[max(range(6), key=lambda i: totals[i])]
    assert sorted(totals)[-1] > sorted(totals)[-2]
    avg3 = sum(t3) / 6
    assert avg3 == int(avg3)
    qualify = sum(1 for i in range(6) if min(t1[i], t2[i], t3[i]) >= 35)
    averages = [sum(t1) / 6, sum(t2) / 6, avg3]
    u_above = sum(1 for score, a in zip((t1[0], t2[0], t3[0]), averages) if score > a)
    shown = lambda v: "?" if v is None else v
    work = "Test 1 total must be 6 × 39 = 234, so W scored 42. Test 2 total must be 6 × 38 = 228, so V scored 39. U's total of 120 gives U 40 in Test 3, and Z's Test 3 score equals its Test 1 score, 38.\n" + table(["Student", "Test 1", "Test 2", "Test 3", "Total"], [(names[i], t1[i], t2[i], t3[i], totals[i]) for i in range(6)])
    add(8, 1, "Scores in three tests", "DI · missing values from averages",
        "Six students took three tests, each marked out of 50. Some scores are missing from the table below.\n\n" + table(["Student", "Test 1", "Test 2", "Test 3"], [(names[i], shown([42, 35, None, 30, 47, 38][i]), shown([38, None, 41, 36, 29, 45][i]), shown([None, 44, 39, 33, 40, None][i])) for i in range(6)]) + "\n\nThe average Test 1 score of the six students was 39 and the average Test 2 score was 38. U's total over the three tests was 120. Z scored the same in Test 3 as in Test 1.", work, [
        item("What was W's total score over the three tests?", totals[2], "W scored 42 + 41 + 39 = 122."),
        item("Which student had the highest total?", top, "Totals: U 120, V 118, W 122, X 99, Y 116, Z 121. W is highest.", ["Z", "U", "V"]),
        item("What was the average Test 3 score of the six students?", int(avg3), "Test 3 scores 40, 44, 39, 33, 40 and 38 total 234, an average of 39."),
        item("A student qualifies if every one of his or her three scores is at least 35. How many students qualify?", qualify, "X (30) and Y (29) fall short; U, V, W and Z qualify."),
        item("In how many of the three tests did U score above that test's average?", u_above,
             "U scored 42 against 39, 38 against 38 and 40 against 39: above average in two tests.", ["0", "1", "3"])
    ], "Linear recovery of three cells", 1)

    # 08/2: families, floors and pets.
    fam, pets = "ABCDI", ["cat", "dog", "fish", "parrot", "rabbit"]
    homes = []
    for floors in permutations(range(1, 6)):
        F = dict(zip(fam, floors))
        for owned in permutations(pets):
            P = dict(zip(fam, owned)); pf = {P[f]: F[f] for f in fam}
            if F["B"] > F["D"] and pf["parrot"] == 3 and F["A"] == pf["dog"] + 1 and P["C"] == "fish" and F["C"] not in (1, 5) \
                    and F["I"] != 5 and abs(pf["cat"] - pf["dog"]) != 1:
                homes.append((F, P))
    assert len(homes) == 7
    never_three = [f for f in fam if all(F[f] != 3 for F, _ in homes)]
    assert never_three == ["C"]
    a_on_two = sum(1 for F, _ in homes if F["A"] == 2)
    bose_if = unique(F["B"] for F, P in homes if {P[f]: F[f] for f in fam}["cat"] == 1 and F["I"] == 4)
    must = [s for s, test in (("Chawla lives on a lower floor than Bose", lambda F, P: F["C"] < F["B"]),
                              ("Arora lives on a higher floor than Iyer", lambda F, P: F["A"] > F["I"]),
                              ("Das lives on floor 1", lambda F, P: F["D"] == 1),
                              ("The rabbit lives on an even-numbered floor", lambda F, P: {P[f]: F[f] for f in fam}["rabbit"] % 2 == 0))
            if all(test(F, P) for F, P in homes)]
    assert must == ["Chawla lives on a lower floor than Bose"]
    full = {"A": "Arora", "B": "Bose", "C": "Chawla", "D": "Das", "I": "Iyer"}
    rows = [[" / ".join(f"{full[f]} ({P[f]})" for f in sorted(F, key=F.get))] for F, P in homes]
    work = "The parrot is on floor 3, so Chawla (fish, not on floors 1 or 5) is on floor 2 or 4. Arora sits directly above the dog, the cat is not next to the dog, Bose is above Das and Iyer is not on top. Checking all 14,400 floor-and-pet assignments leaves seven (floor 1 to floor 5):\n" + "\n".join(r[0] for r in rows)
    add(8, 2, "Five families, five floors", "LR · floors and attributes",
        "Five families, the Aroras, Boses, Chawlas, Dases and Iyers, live on floors 1 to 5 of a building, one family per floor. Each family keeps exactly one pet: a cat, a dog, a fish, a parrot or a rabbit, all different.\nThe Boses live on a higher floor than the Dases.\nThe family with the parrot lives on floor 3.\nThe Aroras live on the floor immediately above the family with the dog.\nThe Chawlas keep the fish and live on neither floor 1 nor floor 5.\nThe Iyers do not live on floor 5.\nThe cat and the dog are not on adjacent floors.", work, [
        item("How many different assignments of floors and pets are possible?", len(homes), "Seven assignments satisfy every condition."),
        item("Which family can never live on floor 3?", "Chawla", "Floor 3 holds the parrot, but the Chawlas keep the fish. Every other family appears on floor 3 in some assignment.", ["Arora", "Bose", "Das"]),
        item("In how many of the possible assignments do the Aroras live on floor 2?", a_on_two, "Two assignments place the Aroras on floor 2."),
        item("If the cat is on floor 1 and the Iyers live on floor 4, on which floor do the Boses live?", bose_if, "Only Das (cat), Chawla, Bose, Iyer, Arora fits, so the Boses are on floor 3."),
        item("Which of the following must be true?", "Chawla lives on a lower floor than Bose",
             "In all seven assignments the Chawlas are below the Boses; each other statement fails in some assignment.", ["Arora lives on a higher floor than Iyer", "Das lives on floor 1", "The rabbit lives on an even-numbered floor"])
    ], 14400, len(homes))

    # 08/3: a four-team league recovered from points.
    teams, games = "ABCD", list(combinations("ABCD", 2))
    leagues = []
    for result in product((0, 1, 2), repeat=6):
        pts = Counter()
        for (a, b), o in zip(games, result):
            if o == 0: pts[a] += 3
            elif o == 2: pts[b] += 3
            else: pts[a] += 1; pts[b] += 1
        if (pts["A"], pts["B"], pts["C"], pts["D"]) == (7, 5, 3, 1):
            leagues.append(dict(zip(games, result)))
    assert len(leagues) == 1
    L = leagues[0]
    draws = sum(1 for o in L.values() if o == 1)
    bc = {0: "B won", 1: "Drawn", 2: "C won"}[L[("B", "C")]]
    d_losses = sum(1 for (a, b), o in L.items() if ("D" == a and o == 2) or ("D" == b and o == 0))
    winless = [t for t in teams if all(not ((a == t and o == 0) or (b == t and o == 2)) for (a, b), o in L.items())]
    assert winless == ["D"]
    work = "Six matches give 18 points when every match is decisive and one point fewer for each draw. The points total 16, so exactly two matches were drawn. Checking all 729 result tables leaves one: A drew with B, A beat C, A beat D, B beat C, B drew with D and C beat D."
    add(8, 3, "A four-team league", "LR · results from points",
        "Four teams A, B, C and D played a league in which every team played every other team exactly once. A win earned 3 points, a draw 1 point each and a loss 0 points. The final points were A 7, B 5, C 3 and D 1.", work, [
        item("How many matches ended in a draw?", draws, "16 points from 6 matches means 18 − 16 = 2 draws."),
        item("What was the result of the match between B and C?", bc, "B's 5 points must be one win and two draws; the only consistent table has B beating C.", ["C won", "Drawn", "Cannot be determined"]),
        item("How many matches did D lose?", d_losses, "D drew with B and lost to A and C."),
        item("Which team did not win any match?", "D", "D's single point came from a draw; every other team won at least once.", ["C", "B", "Every team won at least one match"])
    ], 729, 1)

    # 08/4: choosing projects under a budget.
    projects = {"P1": (30, 9), "P2": (25, 8), "P3": (40, 13), "P4": (20, 5), "P5": (35, 11), "P6": (15, 4)}
    def best(budget, need_p4=True):
        top, picks = -1, []
        for r in range(1, 5):
            for combo in combinations(projects, r):
                if "P1" in combo and "P2" in combo: continue
                if need_p4 and "P3" in combo and "P4" not in combo: continue
                cost = sum(projects[p][0] for p in combo); ret = sum(projects[p][1] for p in combo)
                if cost <= budget:
                    if ret > top: top, picks = ret, [combo]
                    elif ret == top: picks.append(combo)
        return top, picks
    top100, picks100 = best(100)
    assert len(picks100) == 1
    missing = [p for p in projects if p not in picks100[0]]
    assert "P5" in missing and all(p in picks100[0] for p in ("P2", "P3", "P4"))
    top120, picks120 = best(120)
    top_free, picks_free = best(100, need_p4=False)
    assert len(picks120) == 1 and len(picks_free) == 1
    describe = lambda combo: " + ".join(combo) + f" (cost {sum(projects[p][0] for p in combo)}, return {sum(projects[p][1] for p in combo)})"
    work = "Enumerate every portfolio of one to four projects that respects the rules and the budget. Within ₹100 lakh the best is P2 + P3 + P4 + P6: cost 25 + 40 + 20 + 15 = 100, return 8 + 13 + 5 + 4 = 30.\n" + table(["Project", "Cost (₹ lakh)", "Return (₹ lakh)"], [(p, c, r) for p, (c, r) in projects.items()])
    add(8, 4, "Choosing projects", "DI · selection under constraints",
        "A firm can fund some of six projects. Each project is either funded in full or not at all.\n\n" + table(["Project", "Cost (₹ lakh)", "Annual return (₹ lakh)"], [(p, c, r) for p, (c, r) in projects.items()]) + "\n\nRules: the total cost may not exceed ₹100 lakh; at most four projects may be funded; P1 and P2 cannot both be funded; if P3 is funded, P4 must also be funded.", work, [
        item("What is the largest possible total annual return, in ₹ lakh?", top100, "The best portfolio, P2 + P3 + P4 + P6, returns ₹30 lakh."),
        item("Which project is not funded in the portfolio with the largest return?", "P5", "The best portfolio is P2, P3, P4 and P6, so P5 (and P1) are left out.", ["P2", "P3", "P4"]),
        item("If the budget limit rises to ₹120 lakh with all other rules unchanged, what is the largest possible total annual return, in ₹ lakh?", top120, "With ₹120 lakh the best portfolio is " + describe(picks120[0]) + "."),
        item("If P3 may be funded without P4 (other rules and the ₹100 lakh limit unchanged), what is the largest possible total annual return, in ₹ lakh?", top_free, "Without the P3–P4 rule the best portfolio within ₹100 lakh is " + describe(picks_free[0]) + ".")
    ], "All portfolios of at most four projects", 1, True)

    # 08/5: a painted cube cut into unit cubes.
    n = 5
    cells = list(product(range(n), repeat=3))
    def colours(x, y, z):
        c = set()
        if z in (0, n - 1): c.add("red")
        if y in (0, n - 1): c.add("blue")
        if x in (0, n - 1): c.add("green")
        return c
    unpainted = sum(1 for c in cells if not colours(*c))
    two = sum(1 for c in cells if len(colours(*c)) == 2)
    red_green = sum(1 for c in cells if colours(*c) == {"red", "green"})
    some_red = sum(1 for c in cells if "red" in colours(*c))
    work = "Label each unit cube by its position (x, y, z) from 1 to 5. A cube shows red if it lies in the top or bottom layer, blue if in the front or back layer and green if in the left or right layer. Opposite faces share a colour, so a cube can show at most three colours.\nUnpainted cubes form the inner 3 × 3 × 3 block: 27. Cubes on an edge but not a corner show two colours: 12 edges × 3 = 36."
    add(8, 5, "A painted cube", "LR · spatial counting",
        "A solid wooden cube is painted on all six faces: the top and bottom faces red, the front and back faces blue, and the left and right faces green. It is then cut into 125 identical small cubes by cuts parallel to its faces (a 5 × 5 × 5 arrangement).", work, [
        item("How many small cubes have no paint on them?", unpainted, "The inner 3 × 3 × 3 block of 27 cubes has no painted face."),
        item("How many small cubes show exactly two different colours?", two, "Edge cubes other than corners: 12 edges with 3 such cubes each, 36 in all."),
        item("How many small cubes show red and green but not blue?", red_green, "These lie on the 4 edges where a red face meets a green face, 3 cubes per edge: 12."),
        item("How many small cubes have at least one red face?", some_red, "The top and bottom layers hold 25 cubes each: 50.")
    ], n ** 3, n ** 3)


def max_flow(capacity, source, sink):
    flow = {e: 0 for e in capacity}
    nodes = {a for a, _ in capacity} | {b for _, b in capacity}
    total = 0
    while True:
        parent, queue = {source: None}, [source]
        while queue and sink not in parent:
            u = queue.pop(0)
            for v in nodes:
                if v in parent:
                    continue
                forward = capacity.get((u, v), 0) - flow.get((u, v), 0)
                backward = flow.get((v, u), 0)
                if forward > 0 or backward > 0:
                    parent[v] = u
                    queue.append(v)
        if sink not in parent:
            return total
        path, v = [], sink
        while parent[v] is not None:
            path.append((parent[v], v)); v = parent[v]
        push = min(capacity.get(e, 0) - flow.get(e, 0) if capacity.get(e, 0) - flow.get(e, 0) > 0 else flow.get((e[1], e[0]), 0) for e in path)
        for u, v in path:
            if capacity.get((u, v), 0) - flow.get((u, v), 0) >= push and (u, v) in capacity:
                flow[(u, v)] += push
            else:
                flow[(v, u)] -= push
        total += push


def batch_09():
    # 09/1: six meetings in two rooms.
    meetings, cells = "ABCDEF", [(r, s) for r in (1, 2) for s in range(4)]
    plans = []
    for assign in permutations(cells, 6):
        m = dict(zip(meetings, assign)); slot = {k: v[1] for k, v in m.items()}; room = {k: v[0] for k, v in m.items()}
        if slot["A"] != slot["B"] and slot["C"] < slot["D"] and room["E"] == 2 and slot["F"] == 3 and (1, 2) not in assign \
                and slot["B"] > slot["E"] and room["A"] == room["C"] and slot["D"] != slot["F"] and (2, 1) not in assign:
            plans.append(m)
    assert len(plans) == 6
    hour = lambda s: ["9 a.m.", "10 a.m.", "11 a.m.", "12 noon"][s]
    always_nine = [k for k in meetings if all(p[k][1] == 0 for p in plans)]
    assert always_nine == ["E"]
    b_noon = sum(1 for p in plans if p["B"][1] == 3)
    b_where = unique(f"Room {p['B'][0]} at {hour(p['B'][1])}" for p in plans if p["A"][1] == 3 and p["D"][1] == 1)
    never = [s for s, test in (("D is held at 9 a.m.", lambda p: p["D"][1] == 0), ("C is held at 10 a.m.", lambda p: p["C"][1] == 1),
                               ("B is held at 10 a.m.", lambda p: p["B"][1] == 1), ("A is held at 12 noon", lambda p: p["A"][1] == 3))
             if not any(test(p) for p in plans)]
    assert never == ["D is held at 9 a.m."]
    work = "E must be in Room 2 and before B; F is at noon; Room 1 is closed at 11 and Room 2 at 10. With A and C sharing a room and C before D, six schedules remain:\n" + table(["Schedule", "A", "B", "C", "D", "E", "F"], [[i + 1] + [f"R{p[k][0]} {hour(p[k][1])}" for k in meetings] for i, p in enumerate(plans)])
    add(9, 1, "Meetings in two rooms", "LR · scheduling",
        "Six one-hour meetings A, B, C, D, E and F are held in two rooms, Room 1 and Room 2, on one morning. Each meeting starts at 9 a.m., 10 a.m., 11 a.m. or 12 noon, and a room can host only one meeting at a time.\nRoom 1 is not available from 11 a.m. to 12 noon, and Room 2 is not available from 10 a.m. to 11 a.m.\nA and B have the same chairperson, so they are not held at the same time.\nC is held earlier than D, and D is not held at the same time as F.\nE is held in Room 2, and B is held later than E.\nF starts at 12 noon.\nA and C are held in the same room.", work, [
        item("How many different schedules (rooms and times for all six meetings) are possible?", len(plans), "Six schedules satisfy every condition."),
        item("Which meeting is held at 9 a.m. in every possible schedule?", "E", "E is in Room 2 at 9 a.m. in all six schedules.", ["C", "A", "D"]),
        item("In how many of the possible schedules is B held at 12 noon?", b_noon, "Schedules 1 to 4 hold B at noon."),
        item("If A is held at 12 noon and D at 10 a.m., where and when is B held?", b_where, "Only schedule 6 fits, with B in Room 2 at 11 a.m.", ["Room 1 at 10 a.m.", "Room 2 at 12 noon", "Room 1 at 12 noon"]),
        item("Which of the following can never happen?", "D is held at 9 a.m.", "C must come before D, so D cannot take the first hour; each other option occurs in some schedule.", ["C is held at 10 a.m.", "B is held at 10 a.m.", "A is held at 12 noon"])
    ], "8P6 = 20,160 placements", len(plans))

    # 09/2: three car models over three months.
    models, jan = ["X", "Y", "Z"], [400, 350, 250]
    growth = [[25, -20, 20], [-10, 25, 40]]
    feb = [jan[i] * (100 + growth[0][i]) // 100 for i in range(3)]
    mar = [feb[i] * (100 + growth[1][i]) // 100 for i in range(3)]
    assert all(jan[i] * (100 + growth[0][i]) % 100 == 0 and feb[i] * (100 + growth[1][i]) % 100 == 0 for i in range(3))
    top_mar = models[max(range(3), key=lambda i: mar[i])]
    assert sorted(mar)[-1] > sorted(mar)[-2]
    rise = sum(mar) - sum(jan)
    xy_gap = sum((jan[0], feb[0], mar[0])) - sum((jan[1], feb[1], mar[1]))
    shares = [m[2] / sum(m) for m in (jan, feb, mar)]
    best_month = ["January", "February", "March"][max(range(3), key=lambda i: shares[i])]
    work = "Apply each month's change to the previous month's sales.\n" + table(["Model", "Jan", "Feb", "Mar"], [(models[i], jan[i], feb[i], mar[i]) for i in range(3)]) + f"\nTotals: {sum(jan)}, {sum(feb)}, {sum(mar)}."
    add(9, 2, "Sales of three car models", "DI · month-on-month change",
        "A dealer sells three car models X, Y and Z. In January it sold 400 X, 350 Y and 250 Z cars. The table shows the percentage change in each model's sales over the previous month.\n\n" + table(["Model", "February change", "March change"], [(models[i], f"{growth[0][i]:+d}%", f"{growth[1][i]:+d}%") for i in range(3)]), work, [
        item("How many cars did the dealer sell in March?", sum(mar), "450 + 350 + 420 = 1,220 cars."),
        item("Which model sold the most cars in March?", top_mar, "March sales: X 450, Y 350, Z 420.", ["Y", "Z", "X and Z sold equal numbers"]),
        item("By how many cars did total monthly sales rise from January to March?", rise, "1,220 − 1,000 = 220."),
        item("Over the three months together, how many more X cars than Y cars were sold?", xy_gap, "X sold 400 + 500 + 450 = 1,350 and Y sold 350 + 280 + 350 = 980: a difference of 370."),
        item("In which month was model Z's share of the dealer's total sales the largest?", best_month, "Z's share was 25% in January, 300/1,080 ≈ 27.8% in February and 420/1,220 ≈ 34.4% in March.", ["January", "February", "It was the same in all three months"])
    ], "Direct computation", 1)

    # 09/3: preferential ballots and an elimination count.
    ballots = {"ABCD": 34, "BCAD": 24, "CBAD": 20, "DCBA": 14, "BACD": 8}
    def runoff(groups):
        alive, rounds = set("ABCD"), []
        while True:
            tally = Counter()
            for order, n in groups.items():
                tally[next(c for c in order if c in alive)] += n
            rounds.append(dict(tally))
            leader = max(tally, key=tally.get)
            if tally[leader] * 2 > sum(groups.values()):
                return leader, tally[leader], rounds
            loser = min(sorted(alive), key=lambda c: tally.get(c, 0))
            alive.discard(loser)
    winner, final_votes, rounds = runoff(ballots)
    points = Counter()
    for order, n in ballots.items():
        for rank, c in enumerate(order):
            points[c] += n * (3 - rank)
    top_points = max(points.values())
    changed = dict(ballots); changed["DBCA"] = changed.pop("DCBA")
    new_winner, _, _ = runoff(changed)
    work = "Count first preferences, remove the weakest candidate, pass each removed ballot to its next remaining preference and repeat until someone has a majority (over 50) of the 100 votes.\n" + "\n".join(f"Round {i + 1}: " + ", ".join(f"{c} {v}" for c, v in sorted(r.items())) for i, r in enumerate(rounds)) + f"\nPoints (3, 2, 1, 0): " + ", ".join(f"{c} {points[c]}" for c in "ABCD") + "."
    add(9, 3, "A preferential vote", "LR · ranked ballots",
        "One hundred members elected a chairperson from candidates A, B, C and D. Each member ranked all four candidates. Identical rankings are grouped below (first preference on the left).\n\n" + table(["Ranking", "Members"], [(" > ".join(o), n) for o, n in ballots.items()]) + "\n\nCounting rule: if a candidate has more than half of the first preferences, that candidate wins. Otherwise the candidate with the fewest votes is eliminated, and each of that candidate's ballots counts for its highest-ranked remaining candidate; this repeats until someone has more than half.", work, [
        item("How many votes does the winner have in the final round of counting?", final_votes, "In the last round C has 58 votes against A's 42."),
        item("Who wins under the counting rule?", winner, "D is eliminated first (C rises to 34), then B (32); B's ballots split 24 to C and 8 to A, so C wins 58–42.", ["A", "B", "D"]),
        item("Under a different rule, each ballot gives 3 points to its first choice, 2 to its second, 1 to its third and 0 to its fourth. What is the highest points total any candidate receives?", top_points, "B receives 96 + 108 + 14 = 218 points, the most."),
        item("If the 14 members who ranked D first had instead ranked the candidates D > B > C > A, who would win under the original counting rule?", new_winner, "D is still eliminated first, but those ballots now go to B (46). C (20) is eliminated next and C's ballots go to B, giving B 66 votes.", ["A", "C", "No candidate would reach a majority"])
    ], "Exact recount", 1)

    # 09/4: people, professions and cities.
    people = ["Anil", "Bina", "Chitra", "Dev", "Esha"]
    profs = ["doctor", "engineer", "lawyer", "pilot", "teacher"]
    cities = ["Agra", "Bhopal", "Chennai", "Delhi", "Pune"]
    matches = []
    for pr in permutations(profs):
        P = dict(zip(people, pr))
        if P["Chitra"] != "teacher" or P["Anil"] in ("pilot", "teacher") or P["Dev"] == "doctor" or P["Bina"] == "lawyer":
            continue
        for ci in permutations(cities):
            C = dict(zip(people, ci)); by = {P[x]: C[x] for x in people}
            if by["doctor"] == "Delhi" and by["engineer"] == "Bhopal" and C["Anil"] != "Agra" and C["Bina"] == "Chennai" and C["Esha"] != "Pune" and C["Dev"] != "Agra":
                matches.append((P, C))
    assert len(matches) == 4
    bina = unique(P["Bina"] for P, _ in matches)
    esha_delhi = sum(1 for _, C in matches if C["Esha"] == "Delhi")
    dev_if = unique(P["Dev"] for P, C in matches if C["Chitra"] == "Pune")
    work = "Chitra is the teacher. The doctor lives in Delhi and the engineer in Bhopal, while Bina lives in Chennai, so Bina is neither of those and not the lawyer: Bina is the pilot. Checking the remaining cases gives four assignments:\n" + table(["Anil", "Bina", "Chitra", "Dev", "Esha"], [[f"{P[x]}, {C[x]}" for x in people] for P, C in matches])
    add(9, 4, "Professions and cities", "LR · matching",
        "Anil, Bina, Chitra, Dev and Esha are a doctor, an engineer, a lawyer, a pilot and a teacher, in some order. They live in Agra, Bhopal, Chennai, Delhi and Pune, one person per city.\nThe doctor lives in Delhi and the engineer lives in Bhopal.\nChitra is the teacher.\nAnil is neither the pilot nor the teacher, and does not live in Agra.\nBina lives in Chennai and is not the lawyer.\nDev is not the doctor and does not live in Agra.\nEsha does not live in Pune.", work, [
        item("How many complete assignments of professions and cities are possible?", len(matches), "Four assignments remain."),
        item("What is Bina's profession?", bina, "Chennai rules out doctor and engineer, and Bina is not the lawyer or the teacher.", ["doctor", "engineer", "lawyer"]),
        item("In how many of the possible assignments does Esha live in Delhi?", esha_delhi, "Esha is the doctor in Delhi in two of the four assignments."),
        item("If Chitra lives in Pune, what is Dev's profession?", dev_if, "Only the assignment with Dev as the engineer in Bhopal and Esha as the lawyer in Agra has Chitra in Pune.", ["lawyer", "doctor", "pilot"])
    ], 14400, len(matches))

    # 09/5: maximum flow through a pipe network.
    pipes = {("S", "A"): 30, ("S", "B"): 25, ("A", "B"): 10, ("A", "C"): 20, ("B", "C"): 10, ("B", "D"): 25,
             ("C", "T"): 30, ("D", "C"): 5, ("D", "T"): 20}
    best = max_flow(pipes, "S", "T")
    def with_cap(edge, value):
        changed = dict(pipes); changed[edge] = value
        return max_flow(changed, "S", "T")
    raise_ten = [e for e in (("D", "T"), ("A", "C"), ("S", "A"), ("B", "D")) if with_cap(e, pipes[e] + 10) > best]
    assert with_cap(("D", "T"), 30) == 55
    shut_ac = with_cap(("A", "C"), 0)
    min_cut_pipes = min(r for r in range(1, 10) if any(max_flow({e: (0 if e in cut else c) for e, c in pipes.items()}, "S", "T") == 0 for cut in combinations(pipes, r)))
    assert raise_ten == [("D", "T")]
    work = f"Push flow along paths with spare capacity until none remains. The largest flow is {best} litres per minute: S→A→C→T carries 20, S→A→B→C→T 10 and S→B→D→T 20. The two pipes into T (C→T 30, D→T 20) can carry only 50 in total, so no larger flow exists."
    add(9, 5, "Pipes between tanks", "LR · network flow",
        "Water flows from tank S to tank T through one-way pipes. The table gives each pipe's maximum flow in litres per minute. Water is not stored or lost at the intermediate junctions A, B, C and D.\n\n" + table(["Pipe", "Capacity (litres/min)"], [(f"{a} → {b}", c) for (a, b), c in pipes.items()]), work, [
        item("What is the maximum flow, in litres per minute, from S to T?", best, "Flows S→A→C→T 20, S→A→B→C→T 10, S→B→D→T 20 reach the two pipes into T at full capacity: 50."),
        item("Raising the capacity of which one of these pipes by 10 litres per minute increases the maximum flow?", "D → T",
             "With D → T at 30 the two pipes into T can take 60, and the limit becomes the two pipes out of S (30 + 25 = 55): the maximum rises to 55. Raising A → C, S → A or B → D leaves both pipes into T full at 50.", ["A → C", "S → A", "B → D"]),
        item("If pipe A → C is shut, what is the maximum flow, in litres per minute, from S to T?", shut_ac, "Water from A must then pass through A → B (10). Together with S → B (25), at most 35 reaches B, and B can deliver it via C and D: 35."),
        item("What is the smallest number of pipes that must be shut to stop all flow from S to T?", min_cut_pipes, "Shutting C → T and D → T cuts every route; no single pipe does.")
    ], "Augmenting-path search for each variant", 1)


def batch_10():
    # 10/1: a bus timetable with transfers.
    route1 = [7 * 60 + 20 * k for k in range(6)]          # A departures 7:00 to 8:40
    route2 = [7 * 60 + 10 + 25 * k for k in range(8)]     # B departures to D
    route3 = [7 * 60 + 30, 8 * 60 + 15, 9 * 60]           # C departures to D
    def arrive(dep):
        at_b, at_c = dep + 25, dep + 40
        via_b = min((t for t in route2 if t >= at_b), default=None)
        via_c = min((t for t in route3 if t >= at_c), default=None)
        options = []
        if via_b is not None: options.append((via_b + 30, "B"))
        if via_c is not None: options.append((via_c + 12, "C"))
        return min(options)
    clock = lambda m: f"{m // 60}:{m % 60:02d}"
    first = arrive(7 * 60 + 20)
    latest_by_830 = max(d for d in route1 if arrive(d)[0] <= 8 * 60 + 30)
    wait_c = min(t for t in route3 if t >= 7 * 60 + 40) - (7 * 60 + 40)
    before_nine = sum(1 for d in route1 if d <= 8 * 60 and arrive(d)[0] < 9 * 60)
    via_for_740 = arrive(7 * 60 + 40)[1]
    work = "For each departure from A, compare reaching D by changing at B (next Route 2 bus) with continuing to C (next Route 3 bus).\n" + table(["Leave A", "Reach B", "Reach C", "Best arrival at D", "Change at"], [(clock(d), clock(d + 25), clock(d + 40), clock(arrive(d)[0]), arrive(d)[1]) for d in route1])
    add(10, 1, "Changing buses", "DI · timetable and transfers",
        "Three bus routes serve towns A, B, C and D.\nRoute 1 runs A → B → C. Buses leave A every 20 minutes from 7:00 a.m. to 8:40 a.m.; they take 25 minutes from A to B and 15 more minutes from B to C.\nRoute 2 runs B → D. Buses leave B at 7:10 a.m. and then every 25 minutes; the trip takes 30 minutes.\nRoute 3 runs C → D. Buses leave C at 7:30, 8:15 and 9:00 a.m.; the trip takes 12 minutes.\nA passenger can board any bus that leaves a town at or after the time the passenger reaches it.", work, [
        item("A passenger leaves A on the 7:20 a.m. bus. How many minutes after 7:00 a.m. is the earliest time the passenger can reach D?", first[0] - 7 * 60, "Changing at C: reach C at 8:00, leave at 8:15, reach D at 8:27, which is 87 minutes after 7:00. Changing at B gives 8:30."),
        item("What is the latest departure from A that still reaches D by 8:30 a.m.?", clock(latest_by_830), "The 7:20 bus reaches D at 8:27; the 7:40 bus cannot reach D before 8:55.", ["7:00", "7:40", "8:00"]),
        item("A passenger on the 7:00 a.m. bus from A stays on to C. How many minutes must the passenger wait at C for a Route 3 bus?", wait_c, "The bus reaches C at 7:40 and the next Route 3 bus leaves at 8:15: a wait of 35 minutes."),
        item("How many of the buses leaving A at or before 8:00 a.m. allow a passenger to reach D before 9:00 a.m.?", before_nine, "Best arrivals at D: 7:00 bus 8:05 (via B), 7:20 bus 8:27 (via C), 7:40 bus 8:55 (via B) and 8:00 bus 8:55 (via B, catching the 8:25 at B). All four arrive before 9:00."),
        item("For a passenger who leaves A at 7:40 a.m. and wants the earliest arrival at D, where should the passenger change buses?", "At B", "From the 7:40 bus, changing at B (leave 8:25) reaches D at 8:55; changing at C (leave 9:00) reaches D at 9:12.", ["At C", "Either B or C; both arrive together", "No change is needed"])
    ], "Every departure and connection", len(route1))

    # 10/2: electricity bills under a slab tariff.
    homes = {"H1": 80, "H2": 150, "H3": 210, "H4": 260, "H5": 120}
    def bill(units, second=6):
        return 50 + 4 * min(units, 100) + second * max(0, min(units, 200) - 100) + 8 * max(0, units - 200)
    bills = {h: bill(u) for h, u in homes.items()}
    closest = min(bills, key=lambda h: abs(bills[h] - 1000))
    total = sum(bills.values())
    rise = sum(bill(u, 7) for u in homes.values()) - total
    per_unit = max(homes, key=lambda h: bills[h] / homes[h])
    work = "Bill = ₹50 fixed + ₹4 per unit for the first 100 units + ₹6 per unit for units 101 to 200 + ₹8 per unit above 200.\n" + table(["Household", "Units", "Bill (₹)", "₹ per unit"], [(h, u, bills[h], round(bills[h] / u, 2)) for h, u in homes.items()])
    add(10, 2, "Electricity bills", "DI · slab tariff",
        "A town charges for electricity as follows each month: a fixed charge of ₹50, plus ₹4 per unit for the first 100 units, ₹6 per unit for the next 100 units (units 101 to 200) and ₹8 per unit for every unit above 200. Five households used the following numbers of units last month.\n\n" + table(["Household", "Units used"], homes.items()), work, [
        item("What was H4's bill, in rupees?", bills["H4"], "50 + 400 + 600 + 60 × 8 = ₹1,530."),
        item("Whose bill was closest to ₹1,000?", closest, "Bills were 370, 750, 1,130, 1,530 and 570; H3's ₹1,130 is closest.", ["H2", "H4", "H5"]),
        item("What was the total of the five bills, in rupees?", total, "370 + 750 + 1,130 + 1,530 + 570 = ₹4,350."),
        item("If the rate for units 101 to 200 rises from ₹6 to ₹7, by how many rupees does the total of the five bills rise?", rise, "Units in that slab: 50 + 100 + 100 + 20 = 270, each ₹1 dearer."),
        item("Which household paid the most per unit used, counting the fixed charge?", per_unit, "Per-unit amounts: H1 4.63, H2 5.00, H3 5.38, H4 5.88, H5 4.75.", ["H3", "H1", "H2"])
    ], "Direct computation", 1)

    # 10/3: archery totals with six arrows.
    rings = (10, 7, 5, 3)
    def ways(total, arrows=6, every_ring=False):
        out = []
        for a, b, c, d in product(range(arrows + 1), repeat=4):
            if a + b + c + d <= arrows and 10 * a + 7 * b + 5 * c + 3 * d == total and (not every_ring or min(a, b, c, d) >= 1):
                out.append((a, b, c, d, arrows - a - b - c - d))
        return out
    forty = ways(40)
    impossible = [t for t in (59, 52, 48, 44) if not ways(t)]
    assert impossible == [59]
    raju = ways(42, every_ring=True)
    assert len(raju) == 1
    tens = unique(w[0] for w in raju)
    max_with_miss = max(10 * a + 7 * b + 5 * c + 3 * d for a, b, c, d in product(range(7), repeat=4) if a + b + c + d == 5)
    work = "Write a, b, c and d for the arrows in the 10, 7, 5 and 3 rings; misses are the rest of the six arrows. Totals are checked over all such splits.\nWays to score 40: " + "; ".join(f"{a}×10 {b}×7 {c}×5 {d}×3 {m} miss" for a, b, c, d, m in forty)
    add(10, 3, "Archery totals", "LR · scoring combinations",
        "A target has four rings worth 10, 7, 5 and 3 points. An arrow that misses the target scores 0. In a round, an archer shoots exactly six arrows, and the score is the sum of the six arrows. Two rounds are considered the same if the same number of arrows land in each ring.", work, [
        item("In how many different ways can an archer score exactly 40 in a round?", len(forty), "Enumerating every split of six arrows gives the listed ways."),
        item("Which of these round totals is impossible?", "59", "The top two totals are 60 (six 10s) and 57 (five 10s and a 7); 59 cannot be reached. 52, 48 and 44 are all possible.", ["52", "48", "44"]),
        item("Raju scored 42 in a round and hit each of the four rings at least once. How many of his arrows hit the 10 ring?", tens, "One arrow in each ring scores 10 + 7 + 5 + 3 = 25 with four arrows. The other two arrows must add 17, and only 10 + 7 does that. So two arrows hit the 10 ring (and two the 7 ring)."),
        item("What is the highest possible score in a round in which exactly one arrow misses?", max_with_miss, "Five arrows in the 10 ring score 50.")
    ], "All splits of six arrows", len(forty))

    # 10/4: committee selection with conditions.
    men, women = ["M1", "M2", "M3", "M4", "M5"], ["W1", "W2", "W3", "W4"]
    committees = []
    for combo in combinations(men + women, 5):
        s = set(combo)
        if sum(1 for x in s if x.startswith("W")) < 2: continue
        if {"M1", "W1"} <= s: continue
        if "M2" in s and "W2" not in s: continue
        if ("M3" in s) != ("M4" in s): continue
        committees.append(s)
    with_m2 = sum(1 for s in committees if "M2" in s)
    all_women = sum(1 for s in committees if sum(1 for x in s if x.startswith("W")) == 4)
    three_men = [s for s in committees if sum(1 for x in s if x.startswith("M")) == 3]
    work = f"Enumerate all 126 five-person groups from the nine people and keep those meeting every rule: {len(committees)} committees."
    add(10, 4, "Choosing a committee", "LR · selection with conditions",
        "A committee of five is to be chosen from five men M1, M2, M3, M4 and M5 and four women W1, W2, W3 and W4.\nThe committee must include at least two women.\nM1 and W1 cannot both be on the committee.\nIf M2 is on the committee, W2 must also be on it.\nM3 and M4 are either both on the committee or both off it.", work, [
        item("How many different committees can be formed?", len(committees), f"Checking all 126 groups leaves {len(committees)}."),
        item("How many of the possible committees include M2?", with_m2, f"{with_m2} of the committees include M2 (and therefore W2)."),
        item("How many of the possible committees include all four women?", all_women, "With all four women, the fifth member must be a man who is not M1 (W1 is present), not M3 or M4 (they come as a pair), so M2 or M5: 2 committees."),
        item("How many of the possible committees have exactly three men?", len(three_men), f"Three men means M3 and M4 together with one of M1, M2 or M5, or else M1, M2 and M5; adding two women under the other rules gives {len(three_men)} committees.")
    ], 126, len(committees))

    # 10/5: magic squares with extra conditions.
    squares = []
    for perm in permutations(range(1, 10)):
        g = [perm[0:3], perm[3:6], perm[6:9]]
        lines = [sum(r) for r in g] + [sum(g[r][c] for r in range(3)) for c in range(3)] + [g[0][0] + g[1][1] + g[2][2], g[0][2] + g[1][1] + g[2][0]]
        if all(v == 15 for v in lines):
            squares.append(g)
    assert len(squares) == 8
    centre = unique(g[1][1] for g in squares)
    br_if_tl8 = unique(g[2][2] for g in squares if g[0][0] == 8 and g[0][1] == 1)
    corner_sum = unique(g[0][0] + g[0][2] + g[2][0] + g[2][2] for g in squares)
    work = "Every row, column and diagonal of a 3 × 3 square using 1 to 9 must total 15 (the full total 45 split into three rows). Checking all 362,880 fillings leaves the eight rotations and reflections of one square; the centre is always 5."
    add(10, 5, "A number square", "LR · grid with sums",
        "The numbers 1 to 9 are written in a 3 × 3 grid, one number per cell, so that the three numbers in every row, every column and each of the two diagonals add up to the same total.", work, [
        item("How many such grids are possible?", len(squares), "There are eight: one square and its rotations and reflections."),
        item("Which number is always in the centre cell?", str(centre), "The four lines through the centre add to 60 and include every other cell once and the centre four times: 45 + 3 × centre = 60, so the centre is 5.", ["1", "9", "4"]),
        item("If the top-left cell holds 8 and the top-middle cell holds 1, what number is in the bottom-right cell?", br_if_tl8, "That fixes the square 8 1 6 / 3 5 7 / 4 9 2, so the bottom-right cell holds 2."),
        item("What is the sum of the four corner cells?", str(corner_sum), "The corners are always the four even numbers 2, 4, 6 and 8, which total 20.", ["16", "24", "18"])
    ], 362880, len(squares))


def build():
    for batch in (batch_06, batch_07, batch_08, batch_09, batch_10):
        batch()
    for paper, questions in BANK.items():
        assert len(questions) == 22, (paper, len(questions))
        assert Counter(q["type"] for q in questions) == {"TITA": 11, "MCQ": 11}, paper
        assert [sum(q["groupId"] == f"DL{g}" for q in questions) for g in range(1, 6)] == [5, 5, 4, 4, 4], paper
        assert all(re.fullmatch(r"\d+", q["answer"]) for q in questions if q["type"] == "TITA"), paper
    return BANK


def render(paper):
    body = json.dumps(BANK[paper], ensure_ascii=False, indent=2)
    return f"/* Original CAT-style DILR practice for Paper {paper:02}; solved by tests/dilr-series-06-10.py. Not an actual exam paper. */\n(() => {{\nwindow.CAT2026_DILR = {body};\n}})();\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--emit", type=int)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    bank = build()
    if args.emit is not None:
        print(json.dumps(bank[args.emit], ensure_ascii=False, indent=2))
        return
    for paper in sorted(bank):
        file = ROOT / "papers" / f"paper-{paper:02}-dilr.js"
        if args.write:
            file.write_text(render(paper), encoding="utf-8")
        text = file.read_text(encoding="utf-8")
        match = re.search(r"window\.CAT2026_DILR\s*=\s*(\[.*\]);\s*\}\)\(\);", text, re.S)
        assert match, f"Cannot locate array in {file}"
        assert json.loads(match.group(1)) == bank[paper], f"Data or key differs from recomputed constraints: Paper {paper:02}"
    print(json.dumps({"status": "passed", "papers": sorted(bank), "questions": 22 * len(bank),
                      "TITA": 11 * len(bank), "MCQ": 11 * len(bank), "proofs": PROOFS}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
